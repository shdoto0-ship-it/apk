CREATE TABLE public.profiles (
 id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 name text NOT NULL DEFAULT '', grade smallint NOT NULL DEFAULT 9 CHECK (grade IN (9,10)), birth date,
 profile jsonb, settings jsonb NOT NULL DEFAULT '{}'::jsonb,
 bp jsonb NOT NULL DEFAULT '[]'::jsonb, sleep jsonb NOT NULL DEFAULT '[]'::jsonb,
 events jsonb NOT NULL DEFAULT '[]'::jsonb, points jsonb NOT NULL DEFAULT '{}'::jsonb
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY profiles_read_own ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE TABLE public.activity_daily (
 user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 day date NOT NULL, walk bigint NOT NULL DEFAULT 0, jumps bigint NOT NULL DEFAULT 0,
 bike_km double precision NOT NULL DEFAULT 0, active_min integer NOT NULL DEFAULT 0,
 bonus bigint NOT NULL DEFAULT 0, goal_at text, PRIMARY KEY(user_id,day)
);
GRANT SELECT ON public.activity_daily TO authenticated;
GRANT ALL ON public.activity_daily TO service_role;
ALTER TABLE public.activity_daily ENABLE ROW LEVEL SECURITY;
CREATE POLICY activity_read_own ON public.activity_daily FOR SELECT TO authenticated USING (user_id=auth.uid());
CREATE TABLE public.activity_operations (
 user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 operation_id uuid NOT NULL, PRIMARY KEY(user_id,operation_id)
);
GRANT SELECT ON public.activity_operations TO authenticated;
GRANT ALL ON public.activity_operations TO service_role;
ALTER TABLE public.activity_operations ENABLE ROW LEVEL SECURITY;
CREATE POLICY operations_read_own ON public.activity_operations FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE TABLE public.competition_updates (
 user_id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.competition_updates TO authenticated;
GRANT ALL ON public.competition_updates TO service_role;
ALTER TABLE public.competition_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY competition_notifications ON public.competition_updates FOR SELECT TO authenticated USING(true);
CREATE FUNCTION public.create_student_profile() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 INSERT INTO public.profiles(id,name,grade,birth) VALUES(NEW.id, left(coalesce(NEW.raw_user_meta_data->>'name',''),120), CASE WHEN NEW.raw_user_meta_data->>'grade'='10' THEN 10 ELSE 9 END, nullif(NEW.raw_user_meta_data->>'birth','')::date);
 INSERT INTO public.competition_updates(user_id) VALUES(NEW.id);
 RETURN NEW;
END; $$;
CREATE TRIGGER student_signup AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.create_student_profile();
CREATE FUNCTION public.notify_competition() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 INSERT INTO public.competition_updates(user_id) VALUES(CASE WHEN TG_TABLE_NAME='profiles' THEN NEW.id ELSE NEW.user_id END)
 ON CONFLICT(user_id) DO UPDATE SET updated_at=clock_timestamp();
 RETURN NEW;
END; $$;
CREATE TRIGGER profile_competition AFTER UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.notify_competition();
CREATE TRIGGER activity_competition AFTER INSERT OR UPDATE ON public.activity_daily FOR EACH ROW EXECUTE FUNCTION public.notify_competition();
CREATE FUNCTION public.record_activity(operation_id uuid, activity_day date, delta jsonb) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE who uuid := auth.uid(); w bigint := coalesce((delta->>'walk')::bigint,0); j bigint := coalesce((delta->>'jumps')::bigint,0); b double precision := coalesce((delta->>'bikeKm')::double precision,0); m integer := coalesce((delta->>'activeMin')::integer,0); extra bigint := coalesce((delta->>'bonus')::bigint,0); applied integer;
BEGIN
 IF who IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
 IF w<0 OR w>100000 OR j<0 OR j>100000 OR b<0 OR b>1000 OR b='NaN'::float8 OR m<0 OR m>1440 OR extra<0 OR extra>1500 THEN RAISE EXCEPTION 'Invalid activity'; END IF;
 IF activity_day > current_date+1 OR activity_day < current_date-3660 THEN RAISE EXCEPTION 'Invalid date'; END IF;
 INSERT INTO public.activity_operations(user_id,operation_id) VALUES(who,operation_id) ON CONFLICT DO NOTHING;
 GET DIAGNOSTICS applied=ROW_COUNT;
 IF applied=0 THEN RETURN; END IF;
 INSERT INTO public.activity_daily(user_id,day,walk,jumps,bike_km,active_min,bonus) VALUES(who,activity_day,w,j,b,m,extra)
 ON CONFLICT(user_id,day) DO UPDATE SET walk=activity_daily.walk+w,jumps=activity_daily.jumps+j,bike_km=activity_daily.bike_km+b,active_min=activity_daily.active_min+m,bonus=activity_daily.bonus+extra;
 UPDATE public.activity_daily d SET goal_at=to_char(now() AT TIME ZONE 'America/Bogota','HH24:MI')
 WHERE d.user_id=who AND d.day=activity_day AND d.goal_at IS NULL AND round((d.walk+d.jumps*2+d.bike_km*435+d.bonus)::numeric)>=coalesce((SELECT (profile->>'goalSteps')::integer FROM public.profiles WHERE id=who),6000);
END; $$;
REVOKE ALL ON FUNCTION public.record_activity(uuid,date,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_activity(uuid,date,jsonb) TO authenticated;
CREATE FUNCTION public.get_competition() RETURNS TABLE(id uuid,name text,grade smallint,steps bigint,streak integer) LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 WITH daily AS (SELECT d.user_id,d.day,round((d.walk+d.jumps*2+d.bike_km*435+d.bonus)::numeric)::bigint AS total FROM public.activity_daily d),
 goals AS (SELECT p.id,coalesce((p.profile->>'goalSteps')::integer,6000) goal FROM public.profiles p),
 streaks AS (SELECT g.id, (CASE WHEN EXISTS(SELECT 1 FROM daily d WHERE d.user_id=g.id AND d.day=(now() AT TIME ZONE 'America/Bogota')::date AND d.total>=g.goal) THEN 1 ELSE 0 END + coalesce((SELECT min(n)-1 FROM generate_series(1,3661) n WHERE NOT EXISTS(SELECT 1 FROM daily d WHERE d.user_id=g.id AND d.day=(now() AT TIME ZONE 'America/Bogota')::date-n AND d.total>=g.goal)),0))::integer AS count FROM goals g)
 SELECT p.id,p.name,p.grade,coalesce(sum(d.total),0)::bigint,s.count FROM public.profiles p JOIN auth.users u ON u.id=p.id AND u.email_confirmed_at IS NOT NULL LEFT JOIN daily d ON d.user_id=p.id JOIN streaks s ON s.id=p.id WHERE auth.uid() IS NOT NULL GROUP BY p.id,p.name,p.grade,s.count ORDER BY coalesce(sum(d.total),0) DESC,p.id;
$$;
REVOKE ALL ON FUNCTION public.get_competition() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.get_competition() TO authenticated;
ALTER PUBLICATION supabase_realtime ADD TABLE public.competition_updates;
ALTER PUBLICATION supabase_realtime ADD TABLE public.activity_daily;
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
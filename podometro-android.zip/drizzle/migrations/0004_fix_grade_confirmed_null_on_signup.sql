CREATE OR REPLACE FUNCTION public.create_student_profile()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
 -- raw_user_meta_data has no 'grade' for social sign-ins, and NULL IN (...) is NULL, not false:
 -- coalesce so the NOT NULL column always gets a boolean and signup is never blocked.
 INSERT INTO public.profiles(id,name,grade,birth,grade_confirmed) VALUES(
   NEW.id,
   left(coalesce(NEW.raw_user_meta_data->>'name',''),120),
   CASE WHEN NEW.raw_user_meta_data->>'grade'='10' THEN 10 ELSE 9 END,
   nullif(NEW.raw_user_meta_data->>'birth','')::date,
   coalesce(NEW.raw_user_meta_data->>'grade' IN ('9','10'), false)
 );
 INSERT INTO public.competition_updates(user_id) VALUES(NEW.id);
 RETURN NEW;
END; $function$;
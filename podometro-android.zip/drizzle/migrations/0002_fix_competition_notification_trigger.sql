CREATE OR REPLACE FUNCTION public.notify_competition() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE who uuid;
BEGIN
 who := coalesce((to_jsonb(NEW)->>'user_id')::uuid,(to_jsonb(NEW)->>'id')::uuid);
 INSERT INTO public.competition_updates(user_id) VALUES(who)
 ON CONFLICT(user_id) DO UPDATE SET updated_at=clock_timestamp();
 RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION public.notify_competition() FROM PUBLIC,anon,authenticated;
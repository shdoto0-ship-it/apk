REVOKE ALL ON FUNCTION public.create_student_profile() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_competition() FROM PUBLIC, anon, authenticated;
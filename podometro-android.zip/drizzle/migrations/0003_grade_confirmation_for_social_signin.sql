ALTER TABLE public.profiles ADD COLUMN grade_confirmed boolean NOT NULL DEFAULT false;
COMMENT ON COLUMN public.profiles.grade_confirmed IS 'True when the student chose their own grade: email signups do it in the signup form, social sign-ins confirm it in the profile wizard.';

CREATE OR REPLACE FUNCTION public.create_student_profile()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
 INSERT INTO public.profiles(id,name,grade,birth,grade_confirmed) VALUES(
   NEW.id,
   left(coalesce(NEW.raw_user_meta_data->>'name',''),120),
   CASE WHEN NEW.raw_user_meta_data->>'grade'='10' THEN 10 ELSE 9 END,
   nullif(NEW.raw_user_meta_data->>'birth','')::date,
   NEW.raw_user_meta_data->>'grade' IN ('9','10')
 );
 INSERT INTO public.competition_updates(user_id) VALUES(NEW.id);
 RETURN NEW;
END; $function$;
// Después de compilar: Capacitor espera www/index.html.
import { existsSync, renameSync, copyFileSync } from "node:fs";

if (!existsSync("www/native.html")) {
  console.error("No se encontró www/native.html. ¿Falló la compilación (vite build --config vite.native.config.ts)?");
  process.exit(1);
}
renameSync("www/native.html", "www/index.html");
// Rutas internas (/inicio, /entrenar…) sin extensión: el WebView ya cae a index.html; copia de respaldo.
copyFileSync("www/index.html", "www/200.html");
console.log("www/index.html listo.");

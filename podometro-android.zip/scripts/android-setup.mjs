// Arma el proyecto Android: lo crea con Capacitor si falta, copia el código nativo
// de native/android (contador de pasos, widgets, plugin), ajusta el manifiesto y sincroniza.
// Es seguro ejecutarlo varias veces.
import { execSync } from "node:child_process";
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const run = (cmd) => execSync(cmd, { stdio: "inherit" });
const config = JSON.parse(readFileSync("capacitor.config.json", "utf8"));
const appId = config.appId;
const pkgPath = appId.replace(/\./g, "/");
const MARK = "<!-- podometro-native -->";

if (!existsSync("www/index.html")) {
  console.error("Falta www/index.html. Primero ejecuta: npm run build:native");
  process.exit(1);
}

if (!existsSync("android")) {
  console.log("→ Creando proyecto Android con Capacitor…");
  run("npx cap add android");
}

const main = "android/app/src/main";

// 1) Código Java (se reemplaza __APP_ID__ por el id real de la app).
const javaOut = join(main, "java", pkgPath);
mkdirSync(javaOut, { recursive: true });
for (const f of readdirSync("native/android/java")) {
  const text = readFileSync(join("native/android/java", f), "utf8").replaceAll("__APP_ID__", appId);
  writeFileSync(join(javaOut, f), text);
}

// 2) Recursos (layouts, widgets, iconos, textos).
cpSync("native/android/res", join(main, "res"), { recursive: true, force: true });

// 3) Manifiesto: permisos, servicio y widgets.
const manifestPath = join(main, "AndroidManifest.xml");
let manifest = readFileSync(manifestPath, "utf8");
if (!manifest.includes(MARK)) {
  const permissions = `
    ${MARK}
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_HEALTH" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />
    <uses-feature android:name="android.hardware.sensor.stepcounter" android:required="false" />
`;
  const components = `
        ${MARK}
        <service
            android:name=".StepService"
            android:exported="false"
            android:foregroundServiceType="health" />

        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>

        <receiver
            android:name=".SmallWidgetProvider"
            android:exported="true"
            android:label="@string/podometro_widget_small_label">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
                <action android:name="android.intent.action.DATE_CHANGED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_small_info" />
        </receiver>

        <receiver
            android:name=".MediumWidgetProvider"
            android:exported="true"
            android:label="@string/podometro_widget_medium_label">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
                <action android:name="android.intent.action.DATE_CHANGED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_medium_info" />
        </receiver>
    `;
  if (!manifest.includes("</application>") || !manifest.includes("</manifest>")) {
    console.error("El AndroidManifest.xml no tiene el formato esperado.");
    process.exit(1);
  }
  manifest = manifest.replace("</application>", `${components}</application>`).replace("</manifest>", `${permissions}</manifest>`);
  writeFileSync(manifestPath, manifest);
  console.log("→ Manifiesto actualizado.");
}

// 4) targetSdk 34: evita el modo "borde a borde" obligatorio de Android 15 que tapa la barra superior.
//    (Para publicar en Google Play súbelo a 35 o más y ajusta los márgenes.)
const vars = "android/variables.gradle";
if (existsSync(vars)) {
  const text = readFileSync(vars, "utf8");
  const next = text.replace(/targetSdkVersion\s*=\s*\d+/, "targetSdkVersion = 34");
  if (next !== text) writeFileSync(vars, next);
}

// 5) Pantalla de arranque del color de la app (en lugar de blanco).
const styles = join(main, "res/values/styles.xml");
if (existsSync(styles)) {
  const text = readFileSync(styles, "utf8");
  const next = text.replaceAll("@drawable/splash", "@color/podometro_bg");
  if (next !== text) writeFileSync(styles, next);
}

// 6) Copia la web empaquetada dentro del proyecto.
run("npx cap sync android");
console.log("\nProyecto Android listo en ./android");
console.log("APK de prueba:  cd android && ./gradlew assembleDebug");
console.log("Resultado:      android/app/build/outputs/apk/debug/app-debug.apk");

# Idioma y unidades

- Aplicar español e inglés a todas las pantallas, botones, formularios, avisos y fechas, conservando los nombres escritos por los estudiantes.
- Convertir las distancias y velocidades en Inicio, Entrenar, Análisis, Perfil, Widgets y Mapa según km o mi.
- Conservar las preferencias existentes y mantener intactos los pasos y las distancias guardadas.
- Verificar el cambio de idioma, el regreso a español y la conversión de unidades con pruebas y un recorrido por la aplicación.

## Detalles técnicos
- Catálogo central de traducciones y un hook conectado al estado de idioma existente; traducción declarativa en React, sin modificar el DOM.
- Conversión central desde kilómetros almacenados a millas solo para presentación.
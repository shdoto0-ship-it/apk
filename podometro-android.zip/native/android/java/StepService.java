package __APP_ID__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Cuenta pasos con el sensor del teléfono aunque la pantalla esté apagada o la app cerrada.
 * Es un servicio en primer plano (tipo "health"): Android exige mostrar la notificación fija.
 */
public class StepService extends Service implements SensorEventListener {
    static final String CHANNEL_ID = "podometro_steps";
    static final int NOTIFICATION_ID = 4711;
    private static final long UI_THROTTLE_MS = 4000;

    private SensorManager sensors;
    private boolean detectorMode = false;
    private long lastUi = 0;

    static boolean hasActivityPermission(Context c) {
        if (Build.VERSION.SDK_INT < 29) return true;
        return ContextCompat.checkSelfPermission(c, android.Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    /** "counter", "detector" o "none". */
    static String sensorKind(Context c) {
        SensorManager sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return "none";
        if (sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null) return "counter";
        if (sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null) return "detector";
        return "none";
    }

    /** Arranca el servicio sin lanzar excepciones (puede fallar en segundo plano o sin permiso). */
    static boolean startSafely(Context c) {
        if (!hasActivityPermission(c)) return false;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, StepService.class));
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, StepService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sensors = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
        } catch (RuntimeException e) {
            // Sin permiso de actividad física o sin permiso para estar en primer plano.
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!registerSensor()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        WidgetUpdater.updateAll(this);
        return START_STICKY;
    }

    private boolean registerSensor() {
        if (sensors == null) return false;
        sensors.unregisterListener(this);
        Sensor s = sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        detectorMode = false;
        if (s == null) {
            s = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            detectorMode = true;
        }
        if (s == null) return false;
        return sensors.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (detectorMode) {
            StepStore.onDetectorStep(this);
        } else if (event.values.length > 0) {
            StepStore.onRawCounter(this, event.values[0]);
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastUi >= UI_THROTTLE_MS) {
            lastUi = now;
            refreshUi();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void refreshUi() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
        } catch (RuntimeException ignored) { }
        WidgetUpdater.updateAll(this);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        StepStore.Totals t = StepStore.totals(this);
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, t.en ? "Step counting" : "Conteo de pasos", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription(t.en ? "Keeps counting your steps with the screen off" : "Sigue contando tus pasos con la pantalla apagada");
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        StepStore.Totals t = StepStore.totals(this);
        NumberFormat nf = NumberFormat.getIntegerInstance(Locale.US);
        String title = "Podómetro B.S";
        String text = t.en
                ? nf.format(t.total) + " steps today · goal " + nf.format(t.goal)
                : nf.format(t.total) + " pasos hoy · meta " + nf.format(t.goal);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_steps)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build();
    }

    @Override
    public void onDestroy() {
        if (sensors != null) sensors.unregisterListener(this);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package __APP_ID__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.widget.RemoteViews;

import java.text.NumberFormat;
import java.util.Locale;

/** Dibuja y actualiza los dos widgets con lo último que guardó el servicio y la app. */
final class WidgetUpdater {
    private static final int BG = Color.parseColor("#2A1B1E");
    private static final int TRACK = Color.parseColor("#4A3A3D");
    private static final int PRIMARY = Color.parseColor("#E5453A");
    private static final int SUCCESS = Color.parseColor("#3FD9B8");
    private static final int FOREGROUND = Color.parseColor("#F7F1F2");

    private WidgetUpdater() {}

    static void updateAll(Context c) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(c);
            int[] small = mgr.getAppWidgetIds(new ComponentName(c, SmallWidgetProvider.class));
            int[] medium = mgr.getAppWidgetIds(new ComponentName(c, MediumWidgetProvider.class));
            if (small.length > 0) update(c, mgr, small, false);
            if (medium.length > 0) update(c, mgr, medium, true);
        } catch (RuntimeException ignored) { }
    }

    static void handleClockChange(Context c, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
            updateAll(c);
        }
    }

    static void update(Context c, AppWidgetManager mgr, int[] ids, boolean medium) {
        StepStore.Totals t = StepStore.totals(c);
        RemoteViews views = medium ? buildMedium(c, t) : buildSmall(c, t);
        PendingIntent open = PendingIntent.getActivity(c, medium ? 2 : 1,
                new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, open);
        for (int id : ids) {
            try { mgr.updateAppWidget(id, views); } catch (RuntimeException ignored) { }
        }
    }

    private static String n(long v) {
        return NumberFormat.getIntegerInstance(Locale.US).format(v);
    }

    private static RemoteViews buildSmall(Context c, StepStore.Totals t) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_small);
        float frac = t.goal > 0 ? Math.min(1f, (float) t.total / t.goal) : 0f;
        v.setImageViewBitmap(R.id.widget_ring, ring(220, frac, PRIMARY));
        if (!t.signedIn) {
            v.setTextViewText(R.id.widget_steps, "0");
            v.setTextViewText(R.id.widget_caption, t.en ? "Open the app" : "Abre la app");
        } else {
            v.setTextViewText(R.id.widget_steps, n(t.total));
            v.setTextViewText(R.id.widget_caption, t.en ? "of " + n(t.goal) : "de " + n(t.goal));
        }
        return v;
    }

    private static RemoteViews buildMedium(Context c, StepStore.Totals t) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_medium);
        float frac = t.goal > 0 ? Math.min(1f, (float) t.total / t.goal) : 0f;
        v.setImageViewBitmap(R.id.widget_ring, ring(260, frac, PRIMARY));
        v.setTextViewText(R.id.widget_percent, Math.round(frac * 100) + "%");
        if (!t.signedIn) {
            v.setTextViewText(R.id.widget_title, t.en ? "Open the app to sign in" : "Abre la app para entrar");
            v.setTextViewText(R.id.widget_sub, t.en ? "Steps are counted once you sign in" : "Los pasos se cuentan al iniciar sesión");
            v.setImageViewBitmap(R.id.widget_bars, bars(520, 190, 0f, 0f, "9°", "10°"));
            return v;
        }
        long left = Math.max(0, t.goal - t.total);
        v.setTextViewText(R.id.widget_title, t.en ? "Today · " + n(t.total) + " of " + n(t.goal) : "Hoy · " + n(t.total) + " de " + n(t.goal));
        v.setTextViewText(R.id.widget_sub, left > 0
                ? (t.en ? n(left) + " steps to go" : "Faltan " + n(left) + " pasos")
                : (t.en ? "Goal reached!" : "¡Meta cumplida!"));
        float f9 = Math.min(1f, (float) t.g9 / t.goalGrade);
        float f10 = Math.min(1f, (float) t.g10 / t.goalGrade);
        v.setImageViewBitmap(R.id.widget_bars, bars(520, 190, f9, f10, "9°  " + n(t.g9), "10°  " + n(t.g10)));
        return v;
    }

    private static Bitmap ring(int size, float fraction, int color) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float stroke = size * 0.11f;
        RectF r = new RectF(stroke / 2f, stroke / 2f, size - stroke / 2f, size - stroke / 2f);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(TRACK);
        cv.drawArc(r, 0, 360, false, p);
        if (fraction > 0f) {
            p.setColor(fraction >= 1f ? SUCCESS : color);
            cv.drawArc(r, -90, 360f * fraction, false, p);
        }
        return b;
    }

    /** Dos filas con texto y barra: 9° (claro) y 10° (rojo), proporcionales a los 10 millones. */
    private static Bitmap bars(int w, int h, float f9, float f10, String label9, String label10) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(h * 0.15f);
        float rowH = h / 2f;
        float bh = rowH * 0.26f, radius = bh / 2f;
        String[] labels = { label9, label10 };
        float[] fr = { f9, f10 };
        int[] colors = { FOREGROUND, PRIMARY };
        for (int i = 0; i < 2; i++) {
            float top = i * rowH;
            p.setColor(FOREGROUND);
            cv.drawText(labels[i], 0, top + rowH * 0.40f, p);
            float y = top + rowH * 0.58f;
            p.setColor(TRACK);
            cv.drawRoundRect(new RectF(0, y, w, y + bh), radius, radius, p);
            float fw = Math.max(fr[i] > 0f ? bh : 0f, w * fr[i]);
            if (fw > 0f) {
                p.setColor(colors[i]);
                cv.drawRoundRect(new RectF(0, y, Math.min(w, fw), y + bh), radius, radius, p);
            }
        }
        return b;
    }
}

package __APP_ID__;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

/**
 * Almacén nativo de pasos. Vive en SharedPreferences para que el servicio, los widgets
 * y la app lean lo mismo aunque la app web esté cerrada.
 *
 * Entrega a la app web en dos fases (peek → ack) con números de secuencia, para no perder
 * ni duplicar pasos si el proceso se cierra a la mitad.
 */
final class StepStore {
    private static final String PREFS = "podometro_native";

    private static final String K_LAST_RAW = "lastRaw";
    private static final String K_TODAY_DAY = "todayDay";
    private static final String K_TODAY_COUNT = "todayCount";
    private static final String K_PENDING = "pending";
    private static final String K_CHUNKS = "chunks";
    private static final String K_SEQ = "seq";
    private static final String K_WANTED = "wanted";
    private static final String K_HAS_SNAP = "hasSnap";
    private static final String K_SNAP_DAY = "snapDay";
    private static final String K_SNAP_TOTAL = "snapTotal";
    private static final String K_SNAP_DRAINED = "snapDrained";
    private static final String K_GOAL = "goal";
    private static final String K_G9 = "g9";
    private static final String K_G10 = "g10";
    private static final String K_GOAL_GRADE = "goalGrade";
    private static final String K_LANG = "lang";

    private StepStore() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String dayKey() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    private static void rollDay(SharedPreferences sp, SharedPreferences.Editor ed) {
        String today = dayKey();
        if (!today.equals(sp.getString(K_TODAY_DAY, ""))) {
            ed.putString(K_TODAY_DAY, today);
            ed.putInt(K_TODAY_COUNT, 0);
        }
    }

    private static JSONObject readObj(SharedPreferences sp, String key) {
        try { return new JSONObject(sp.getString(key, "{}")); } catch (JSONException e) { return new JSONObject(); }
    }

    private static JSONArray readArr(SharedPreferences sp, String key) {
        try { return new JSONArray(sp.getString(key, "[]")); } catch (JSONException e) { return new JSONArray(); }
    }

    // ───────── conteo ─────────

    /** TYPE_STEP_COUNTER: acumulado desde el último reinicio del teléfono. */
    static synchronized void onRawCounter(Context c, float value) {
        SharedPreferences sp = p(c);
        float last = sp.getFloat(K_LAST_RAW, -1f);
        long delta;
        if (last < 0f) delta = 0;               // primera lectura: solo se toma como referencia
        else if (value < last) delta = (long) value; // el teléfono se reinició
        else delta = (long) (value - last);
        sp.edit().putFloat(K_LAST_RAW, value).apply();
        if (delta > 0) addSteps(c, delta);
    }

    /** TYPE_STEP_DETECTOR: un evento por paso. */
    static synchronized void onDetectorStep(Context c) {
        addSteps(c, 1);
    }

    private static void addSteps(Context c, long delta) {
        SharedPreferences sp = p(c);
        SharedPreferences.Editor ed = sp.edit();
        rollDay(sp, ed);
        // rollDay solo escribió en el editor: léelo de vuelta con el día correcto.
        String today = dayKey();
        int count = today.equals(sp.getString(K_TODAY_DAY, "")) ? sp.getInt(K_TODAY_COUNT, 0) : 0;
        ed.putInt(K_TODAY_COUNT, count + (int) delta);
        JSONObject pending = readObj(sp, K_PENDING);
        try { pending.put(today, pending.optLong(today, 0) + delta); } catch (JSONException ignored) { }
        ed.putString(K_PENDING, pending.toString());
        ed.apply();
    }

    static synchronized int todayCount(Context c) {
        SharedPreferences sp = p(c);
        return today(sp);
    }

    private static int today(SharedPreferences sp) {
        return dayKey().equals(sp.getString(K_TODAY_DAY, "")) ? sp.getInt(K_TODAY_COUNT, 0) : 0;
    }

    // ───────── entrega a la app web ─────────

    /** Convierte lo pendiente en bloques numerados y devuelve todos los que la app aún no confirma. */
    static synchronized JSONArray peek(Context c) {
        SharedPreferences sp = p(c);
        JSONObject pending = readObj(sp, K_PENDING);
        JSONArray chunks = readArr(sp, K_CHUNKS);
        long seq = sp.getLong(K_SEQ, 0);
        Iterator<String> it = pending.keys();
        while (it.hasNext()) {
            String day = it.next();
            long steps = pending.optLong(day, 0);
            if (steps <= 0) continue;
            seq++;
            try {
                JSONObject o = new JSONObject();
                o.put("seq", seq);
                o.put("day", day);
                o.put("steps", steps);
                chunks.put(o);
            } catch (JSONException ignored) { }
        }
        sp.edit().putString(K_PENDING, "{}").putString(K_CHUNKS, chunks.toString()).putLong(K_SEQ, seq).apply();
        return chunks;
    }

    static synchronized void ack(Context c, long upToSeq) {
        SharedPreferences sp = p(c);
        JSONArray chunks = readArr(sp, K_CHUNKS);
        JSONArray keep = new JSONArray();
        for (int i = 0; i < chunks.length(); i++) {
            JSONObject o = chunks.optJSONObject(i);
            if (o != null && o.optLong("seq", 0) > upToSeq) keep.put(o);
        }
        sp.edit().putString(K_CHUNKS, keep.toString()).apply();
    }

    /** Pasos de hoy que la app web todavía no ha sumado a su total. */
    private static long undrainedToday(SharedPreferences sp) {
        String today = dayKey();
        long sum = readObj(sp, K_PENDING).optLong(today, 0);
        JSONArray chunks = readArr(sp, K_CHUNKS);
        for (int i = 0; i < chunks.length(); i++) {
            JSONObject o = chunks.optJSONObject(i);
            if (o != null && today.equals(o.optString("day"))) sum += o.optLong("steps", 0);
        }
        return sum;
    }

    // ───────── servicio deseado ─────────

    static synchronized void setWanted(Context c, boolean wanted) {
        SharedPreferences sp = p(c);
        SharedPreferences.Editor ed = sp.edit();
        // Al empezar a contar de nuevo, lo caminado mientras no se contaba no se suma.
        if (wanted && !sp.getBoolean(K_WANTED, false)) ed.remove(K_LAST_RAW);
        ed.putBoolean(K_WANTED, wanted).apply();
    }

    static synchronized boolean isWanted(Context c) {
        return p(c).getBoolean(K_WANTED, false);
    }

    /** Al cerrar sesión: nadie cuenta pasos hasta que otra cuenta entre. */
    static synchronized void resetForSignOut(Context c) {
        p(c).edit()
                .putBoolean(K_WANTED, false)
                .remove(K_LAST_RAW)
                .putBoolean(K_HAS_SNAP, false)
                .putString(K_PENDING, "{}")
                .putString(K_CHUNKS, "[]")
                .apply();
    }

    // ───────── datos del widget ─────────

    static synchronized void setSnapshot(Context c, int total, int goal, long g9, long g10, int goalGrade, String lang) {
        SharedPreferences sp = p(c);
        SharedPreferences.Editor ed = sp.edit();
        rollDay(sp, ed);
        ed.apply();
        long drained = Math.max(0, today(sp) - undrainedToday(sp));
        sp.edit()
                .putBoolean(K_HAS_SNAP, true)
                .putString(K_SNAP_DAY, dayKey())
                .putInt(K_SNAP_TOTAL, total)
                .putLong(K_SNAP_DRAINED, drained)
                .putInt(K_GOAL, goal)
                .putLong(K_G9, g9)
                .putLong(K_G10, g10)
                .putInt(K_GOAL_GRADE, goalGrade)
                .putString(K_LANG, lang == null ? "es" : lang)
                .apply();
    }

    static final class Totals {
        int total;
        int goal = 6000;
        long g9;
        long g10;
        int goalGrade = 10_000_000;
        boolean en;
        boolean signedIn;
    }

    static synchronized Totals totals(Context c) {
        SharedPreferences sp = p(c);
        SharedPreferences.Editor ed = sp.edit();
        rollDay(sp, ed);
        ed.apply();
        Totals t = new Totals();
        int steps = today(sp);
        t.signedIn = sp.getBoolean(K_HAS_SNAP, false);
        t.en = "en".equals(sp.getString(K_LANG, "es"));
        if (t.signedIn) {
            t.goal = Math.max(1, sp.getInt(K_GOAL, 6000));
            t.g9 = sp.getLong(K_G9, 0);
            t.g10 = sp.getLong(K_G10, 0);
            t.goalGrade = Math.max(1, sp.getInt(K_GOAL_GRADE, 10_000_000));
            if (dayKey().equals(sp.getString(K_SNAP_DAY, ""))) {
                long sinceSnap = Math.max(0, steps - sp.getLong(K_SNAP_DRAINED, 0));
                t.total = (int) Math.min(Integer.MAX_VALUE, sp.getInt(K_SNAP_TOTAL, 0) + sinceSnap);
            } else {
                t.total = steps;
            }
        } else {
            t.total = steps;
        }
        return t;
    }
}

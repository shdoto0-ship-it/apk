package __APP_ID__;

import android.Manifest;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Puente entre la app web y el contador de pasos nativo, los widgets y los permisos de Android. */
@CapacitorPlugin(
        name = "PodometroNative",
        permissions = {
                @Permission(alias = "activity", strings = { Manifest.permission.ACTIVITY_RECOGNITION }),
                @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
        }
)
public class PodometroPlugin extends Plugin {

    private boolean notificationsGranted() {
        return NotificationManagerCompat.from(getContext()).areNotificationsEnabled();
    }

    private boolean batteryIgnored() {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
    }

    private JSObject permissionState() {
        JSObject o = new JSObject();
        o.put("activityGranted", StepService.hasActivityPermission(getContext()));
        o.put("notificationsGranted", notificationsGranted());
        return o;
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        String kind = StepService.sensorKind(c);
        JSObject o = permissionState();
        o.put("available", !"none".equals(kind));
        o.put("sensor", kind);
        o.put("running", StepStore.isWanted(c));
        o.put("batteryIgnored", batteryIgnored());
        o.put("today", StepStore.todayCount(c));
        call.resolve(o);
    }

    @PluginMethod
    public void requestPerms(PluginCall call) {
        List<String> aliases = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 29 && !StepService.hasActivityPermission(getContext())) aliases.add("activity");
        if (Build.VERSION.SDK_INT >= 33 && !notificationsGranted()) aliases.add("notifications");
        if (aliases.isEmpty()) {
            call.resolve(permissionState());
            return;
        }
        requestPermissionForAliases(aliases.toArray(new String[0]), call, "permsResult");
    }

    @PermissionCallback
    private void permsResult(PluginCall call) {
        call.resolve(permissionState());
    }

    @PluginMethod
    public void start(PluginCall call) {
        Context c = getContext();
        JSObject o = new JSObject();
        if ("none".equals(StepService.sensorKind(c)) || !StepService.hasActivityPermission(c)) {
            o.put("started", false);
            call.resolve(o);
            return;
        }
        StepStore.setWanted(c, true);
        o.put("started", StepService.startSafely(c));
        call.resolve(o);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Context c = getContext();
        StepStore.resetForSignOut(c);
        StepService.stop(c);
        WidgetUpdater.updateAll(c);
        call.resolve();
    }

    @PluginMethod
    public void peek(PluginCall call) {
        Context c = getContext();
        JSONArray chunks = StepStore.peek(c);
        JSArray out = new JSArray();
        for (int i = 0; i < chunks.length(); i++) {
            JSONObject src = chunks.optJSONObject(i);
            if (src == null) continue;
            JSObject o = new JSObject();
            o.put("seq", src.optLong("seq", 0));
            o.put("day", src.optString("day", ""));
            o.put("steps", src.optLong("steps", 0));
            out.put(o);
        }
        JSObject res = new JSObject();
        res.put("chunks", out);
        res.put("today", StepStore.todayCount(c));
        call.resolve(res);
    }

    @PluginMethod
    public void ack(PluginCall call) {
        Double seq = call.getDouble("seq", 0d);
        StepStore.ack(getContext(), seq == null ? 0L : seq.longValue());
        call.resolve();
    }

    @PluginMethod
    public void setSnapshot(PluginCall call) {
        Context c = getContext();
        Double total = call.getDouble("total", 0d);
        Double goal = call.getDouble("goal", 6000d);
        Double g9 = call.getDouble("g9", 0d);
        Double g10 = call.getDouble("g10", 0d);
        Double goalGrade = call.getDouble("goalGrade", 10_000_000d);
        String lang = call.getString("lang", "es");
        StepStore.setSnapshot(c,
                total == null ? 0 : total.intValue(),
                goal == null ? 6000 : goal.intValue(),
                g9 == null ? 0L : g9.longValue(),
                g10 == null ? 0L : g10.longValue(),
                goalGrade == null ? 10_000_000 : goalGrade.intValue(),
                lang);
        WidgetUpdater.updateAll(c);
        call.resolve();
    }

    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        Context c = getContext();
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (RuntimeException e) {
            try {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (RuntimeException ignored) { }
        }
        call.resolve();
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        Context c = getContext();
        boolean medium = "medium".equals(call.getString("size", "small"));
        JSObject res = new JSObject();
        boolean supported = false;
        boolean requested = false;
        if (Build.VERSION.SDK_INT >= 26) {
            AppWidgetManager mgr = AppWidgetManager.getInstance(c);
            supported = mgr.isRequestPinAppWidgetSupported();
            if (supported) {
                ComponentName cn = new ComponentName(c, medium ? MediumWidgetProvider.class : SmallWidgetProvider.class);
                try { requested = mgr.requestPinAppWidget(cn, null, null); } catch (RuntimeException ignored) { }
            }
        }
        res.put("supported", supported);
        res.put("requested", requested);
        call.resolve(res);
    }
}

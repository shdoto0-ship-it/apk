// Algunas librerías leen process.env; en el teléfono no existe.
const g = globalThis as unknown as { process?: { env: Record<string, string | undefined> } };
if (!g.process) g.process = { env: {} };
export {};

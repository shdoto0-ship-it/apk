import { Camera, HeartPulse, RotateCcw, Square, ShieldCheck } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Btn, Ring, Switch } from "@/components/app/ui";
import { useI18n } from "@/lib/i18n";
import {
  estimatePulse,
  fingerPresent,
  PULSE_DURATION_MS,
  pulseGuidance,
  type PulseResult,
  type PulseSample,
} from "@/lib/pulse";

type Phase = "idle" | "opening" | "waiting" | "measuring" | "result" | "error";
export function PulseCamera() {
  const { t } = useI18n();
  const [phase, setPhase] = useState<Phase>("idle");
  const [seconds, setSeconds] = useState(30);
  const [signal, setSignal] = useState(false);
  const [message, setMessage] = useState("");
  const [result, setResult] = useState<PulseResult | null>(null);
  const [light, setLight] = useState(true);
  const [lightNote, setLightNote] = useState("");
  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const frame = useRef(0);
  const watchdog = useRef<ReturnType<typeof setTimeout> | null>(null);
  const run = useRef(0);

  const release = () => {
    run.current++;
    cancelAnimationFrame(frame.current);
    if (watchdog.current) clearTimeout(watchdog.current);
    stream.current?.getTracks().forEach((track) => track.stop());
    stream.current = null;
    if (video.current) video.current.srcObject = null;
  };

  useEffect(() => {
    const hidden = () => {
      if (document.hidden && stream.current) {
        release();
        setPhase("error");
        setMessage("La medición se interrumpió al salir de la pantalla. Vuelve a intentarlo.");
      }
    };
    document.addEventListener("visibilitychange", hidden);
    return () => {
      release();
      document.removeEventListener("visibilitychange", hidden);
    };
  }, []);

  const start = async () => {
    release();
    const id = run.current;
    setPhase("opening");
    setResult(null);
    setSeconds(30);
    setSignal(false);
    setMessage("");
    setLightNote("");
    const fail = (text: string) => {
      if (id !== run.current) return;
      release();
      setMessage(text);
      setPhase("error");
    };
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      fail(
        "Este navegador no permite acceder a la cámara. Abre la app en un navegador actualizado con conexión segura.",
      );
      return;
    }
    try {
      const media = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 320 },
          height: { ideal: 240 },
          frameRate: { ideal: 30 },
        },
      });
      if (id !== run.current) {
        media.getTracks().forEach((t) => t.stop());
        return;
      }
      stream.current = media;
      const track = media.getVideoTracks()[0];
      if (!track || !video.current) {
        fail("No se pudo abrir la cámara. Inténtalo otra vez.");
        return;
      }
      track.addEventListener("ended", () => fail("La cámara se desconectó. Vuelve a intentarlo."), { once: true });
      if (light) {
        try {
          const capabilities = track.getCapabilities?.() as (MediaTrackCapabilities & { torch?: boolean }) | undefined;
          if (!capabilities?.torch) setLightNote("Linterna no disponible. Necesitas buena iluminación.");
          else await track.applyConstraints({ advanced: [{ torch: true } as MediaTrackConstraintSet] });
        } catch {
          setLightNote("No se pudo encender la linterna. Necesitas buena iluminación.");
        }
      }
      if (id !== run.current) return;
      video.current.srcObject = media;
      await video.current.play();
      if (id !== run.current) return;
      const canvas = document.createElement("canvas");
      canvas.width = 32;
      canvas.height = 32;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (!ctx) {
        fail("No se pudo analizar la imagen en este navegador.");
        return;
      }
      setPhase("waiting");
      const opened = performance.now();
      let began: number | null = null,
        stableSince: number | null = null,
        lastTime = -1;
      const samples: PulseSample[] = [];
      watchdog.current = setTimeout(
        () => fail("No se obtuvo una señal continua. Mantén el dedo quieto y prueba otra vez con buena luz."),
        55_000,
      );
      const tick = () => {
        if (id !== run.current) return;
        const v = video.current,
          now = performance.now();
        if (!v) return;
        if (v.readyState >= 2 && v.currentTime !== lastTime) {
          lastTime = v.currentTime;
          const w = v.videoWidth,
            h = v.videoHeight;
          ctx.drawImage(v, w * 0.25, h * 0.25, w * 0.5, h * 0.5, 0, 0, 32, 32);
          const pixels = ctx.getImageData(0, 0, 32, 32).data;
          let red = 0,
            green = 0,
            blue = 0;
          for (let i = 0; i < pixels.length; i += 4) {
            red += pixels[i] ?? 0;
            green += pixels[i + 1] ?? 0;
            blue += pixels[i + 2] ?? 0;
          }
          const sample = { at: now, red: red / 1024, green: green / 1024, blue: blue / 1024 };
          const covered = fingerPresent(sample);
          setSignal(covered);
          if (began === null) {
            if (covered) {
              stableSince ??= now;
              if (now - stableSince >= 1000) {
                began = now;
                setPhase("measuring");
              }
            } else stableSince = null;
          }
          if (began !== null) {
            samples.push(sample);
            setSeconds(Math.max(0, Math.ceil((PULSE_DURATION_MS - (now - began)) / 1000)));
            if (now - began >= PULSE_DURATION_MS) {
              const reading = estimatePulse(samples);
              release();
              if (reading) {
                setResult(reading);
                setPhase("result");
              } else {
                setMessage(
                  "No pudimos obtener una señal fiable. Calienta tus manos y repite con el dedo quieto, sin presionar fuerte y con buena iluminación.",
                );
                setPhase("error");
              }
              return;
            }
          }
        }
        if (began === null && now - opened > 20_000) {
          fail(
            "No se detectó el dedo. Cubre la cámara trasera con la yema, sin presionar fuerte, y prueba con más luz.",
          );
          return;
        }
        frame.current = requestAnimationFrame(tick);
      };
      frame.current = requestAnimationFrame(tick);
    } catch (error) {
      const name = error instanceof DOMException ? error.name : "";
      fail(
        name === "NotAllowedError"
          ? "No se permitió usar la cámara. Habilita el permiso de cámara para esta app en tu navegador y vuelve a intentarlo."
          : name === "NotFoundError"
            ? "No encontramos una cámara en este dispositivo. Usa un teléfono con cámara trasera."
            : name === "NotReadableError"
              ? "La cámara está ocupada. Cierra otras aplicaciones que la usen y vuelve a intentarlo."
              : "No se pudo iniciar la cámara. Comprueba sus permisos y vuelve a intentarlo.",
      );
    }
  };

  const active = phase === "opening" || phase === "waiting" || phase === "measuring";
  return (
    <section className="mt-5 border-y border-border py-5" aria-labelledby="camera-pulse-title">
      <div className="flex items-center gap-3">
        <HeartPulse className="size-6 text-primary" />
        <h2 id="camera-pulse-title" className="text-lg font-bold">
          {t("Ritmo cardiaco con cámara")}
        </h2>
        <span className="ml-auto text-xs text-muted-foreground">30 s</span>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">
        {t("Estimación orientativa del pulso · no mide la presión arterial.")}
      </p>
      {!active && phase !== "result" && (
        <p className="mt-3 text-sm">
          {t("Siéntate y descansa unos minutos. Cubre la cámara trasera con la yema del dedo y mantenlo quieto durante 30 segundos, sin presionar fuerte.")}
        </p>
      )}
      <div className={active ? "mt-4 flex items-center justify-center gap-5" : "hidden"}>
        <video
          ref={video}
          muted
          playsInline
          aria-label={t("Imagen de la cámara para medir el pulso")}
          className="size-28 shrink-0 rounded-full border-2 border-border object-cover"
        />
        <Ring value={30 - seconds} max={30} size={112} stroke={7}>
          <span className="text-3xl font-bold tabular-nums">
            {seconds}
            <span className="ml-1 text-sm font-normal">s</span>
          </span>
        </Ring>
      </div>
      {active && (
        <div className="my-4 text-center" role="status">
          <p className="font-semibold">
            {phase === "opening"
              ? t("Abriendo cámara…")
              : phase === "waiting"
                ? t("Coloca el dedo en la cámara")
                : signal
                  ? t("Mantén el dedo quieto")
                  : t("Señal perdida: cubre la cámara")}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            {phase === "waiting"
              ? t("La cuenta empieza al detectar el dedo.")
              : phase === "measuring"
                ? t("Analizando la señal; aún no hay un resultado.")
                : t("Acepta el permiso de cámara para continuar.")}
          </p>
        </div>
      )}
      {active && lightNote && <p className="mb-3 text-xs text-warning">{t(lightNote)}</p>}
      {result && (
        <div className="mt-4" role="status">
          <p className="text-xs text-muted-foreground">{t("Pulso estimado ·")} {t(result.quality)}</p>
          <p className="my-2 text-5xl font-bold">
            {result.bpm}
            <span className="ml-2 text-base font-normal text-muted-foreground">{t("lpm")}</span>
          </p>
          <p className="text-sm">{t(pulseGuidance(result.bpm))}</p>
        </div>
      )}
      {phase === "error" && (
        <p className="my-4 text-sm text-warning" role="alert">
          {t(message)}
        </p>
      )}
      {!active && (
        <div className="my-4 flex items-center justify-between gap-3">
          <span className="text-sm">{t("Usar linterna si está disponible")}</span>
          <Switch on={light} onChange={setLight} label={t("Usar linterna si está disponible")} />
        </div>
      )}
      <p className="my-3 text-xs text-muted-foreground">
        {t("Si la linterna calienta o molesta, retira el dedo y cancela. La cámara no tiene precisión médica ni detecta arritmias. Si te sientes mal, avisa a un adulto; ante síntomas intensos, pide ayuda urgente.")}
      </p>
      {active ? (
        <Btn
          variant="outline"
          onClick={() => {
            release();
            setPhase("idle");
          }}
        >
          <Square className="size-4" />
          {t("Cancelar medición")}
        </Btn>
      ) : (
        <Btn onClick={start}>
          {phase === "idle" ? <Camera className="size-5" /> : <RotateCcw className="size-5" />}
          {phase === "idle" ? t("Medir pulso · 30 segundos") : t("Volver a medir")}
        </Btn>
      )}
      <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
        <ShieldCheck className="size-4 shrink-0" />
        {t("Las imágenes se analizan aquí, no se guardan ni se envían.")}
      </p>
    </section>
  );
}

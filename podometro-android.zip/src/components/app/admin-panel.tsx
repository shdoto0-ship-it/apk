import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { listStudents, setStudentPassword } from "@/lib/admin.functions";
import { useI18n } from "@/lib/i18n";

type Student = { id: string; email: string; name: string; grade: number | null };

export function AdminPanel() {
  const { t } = useI18n();
  const [isAdmin, setIsAdmin] = useState(false);
  const [list, setList] = useState<Student[] | null>(null);
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const fetchList = useServerFn(listStudents);
  const savePw = useServerFn(setStudentPassword);

  useEffect(() => {
    void supabase.auth.getUser().then(async ({ data: u }) => {
      if (!u.user) return;
      const { data } = await supabase.rpc("has_role", { _user_id: u.user.id, _role: "admin" });
      setIsAdmin(data === true);
    });
  }, []);

  if (!isAdmin) return null;

  const load = async () => {
    try { setList(await fetchList()); } catch (e) { toast.error(t((e as Error).message)); }
  };
  const shown = (list ?? []).filter((s) => (s.name + " " + s.email).toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <p className="mb-2 mt-5 text-sm text-muted-foreground">{t("Administrador")}</p>
      <div className="surface space-y-3 p-4">
        {!list ? (
          <button onClick={load} className="w-full rounded-xl bg-primary px-3 py-2 font-semibold text-primary-foreground">{t("Ver estudiantes registrados")}</button>
        ) : (
          <>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("Buscar nombre o correo")} className="w-full rounded-xl border border-border bg-transparent px-3 py-2 outline-none" />
            <p className="text-xs text-muted-foreground">{list.length} {t("cuentas")}</p>
            <div className="max-h-96 divide-y divide-border overflow-y-auto">
              {shown.map((s) => (
                <div key={s.id} className="py-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0"><b className="block truncate text-sm">{s.name || t("(sin nombre)")}</b><p className="truncate text-xs text-muted-foreground">{s.email}{s.grade ? ` · ${s.grade}°` : ""}</p></div>
                    <button onClick={() => { setEditing(editing === s.id ? null : s.id); setPw(""); }} className="shrink-0 rounded-lg border border-border px-2 py-1 text-xs">{t("Cambiar contraseña")}</button>
                  </div>
                  {editing === s.id && (
                    <form className="mt-2 flex gap-2" onSubmit={async (e) => {
                      e.preventDefault();
                      if (pw.length < 8) { toast.error(t("Mínimo 8 caracteres")); return; }
                      setBusy(true);
                      try { await savePw({ data: { userId: s.id, password: pw } }); toast.success(t("Contraseña cambiada para {name}", { name: s.name || s.email })); setEditing(null); setPw(""); }
                      catch (err) { toast.error(t((err as Error).message)); }
                      setBusy(false);
                    }}>
                      <input value={pw} onChange={(e) => setPw(e.target.value)} placeholder={t("Nueva contraseña")} className="min-w-0 flex-1 rounded-lg border border-border bg-transparent px-2 py-1 text-sm outline-none" />
                      <button disabled={busy} className="rounded-lg bg-primary px-3 py-1 text-sm font-semibold text-primary-foreground">{t("Guardar")}</button>
                    </form>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
}

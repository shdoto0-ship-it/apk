import { BatteryCharging, Footprints, LayoutGrid } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Btn } from "@/components/app/ui";
import { useI18n } from "@/lib/i18n";
import { fmt } from "@/lib/store";
import {
  isNative, nativeStatus, openBatterySettings, pinNativeWidget, requestNativePermissions, startNativeCounting, type NativeStatus,
} from "@/lib/native";

/** Estado del conteo en segundo plano y widgets. Solo aparece dentro de la app de Android. */
export function NativeCard() {
  const { t } = useI18n();
  const [st, setSt] = useState<NativeStatus | null>(null);
  const reload = useCallback(async () => { setSt(await nativeStatus()); }, []);
  useEffect(() => {
    if (!isNative()) return;
    void reload();
    const onVisible = () => { if (document.visibilityState === "visible") void reload(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [reload]);
  if (!isNative() || !st) return null;

  const allow = async () => {
    await requestNativePermissions();
    await startNativeCounting();
    await reload();
  };
  const addWidget = async (size: "small" | "medium") => {
    const r = await pinNativeWidget(size);
    if (!r.supported || !r.requested) toast.message(t("Tu pantalla de inicio no permite agregarlo desde aquí. Mantén presionado un espacio vacío del inicio, elige Widgets y busca Podómetro B.S."));
  };
  const active = st.available && st.activityGranted && st.running;

  return (
    <div className="surface mb-6 p-4">
      <div className="flex items-center gap-3">
        <span className={`grid size-10 place-items-center rounded-xl ${active ? "bg-success" : "bg-warning"} text-background`}><Footprints className="size-5" /></span>
        <div className="min-w-0 flex-1">
          <p className="font-semibold">{t("Conteo con la pantalla apagada")}</p>
          <p className="text-xs text-muted-foreground">
            {!st.available ? t("Este teléfono no tiene sensor de pasos.")
              : !st.activityGranted ? t("Inactivo: falta el permiso de actividad física.")
              : t("Activo: cuenta tus pasos aunque la pantalla esté apagada.")}
          </p>
        </div>
      </div>
      {st.available && <p className="mt-3 text-xs text-muted-foreground">{t("Pasos contados hoy por el teléfono: {n}", { n: fmt(st.today) })}</p>}
      {st.available && !st.activityGranted && <Btn className="mt-3" onClick={allow}>{t("Permitir actividad física")}</Btn>}
      {st.available && st.activityGranted && !st.batteryIgnored && (
        <>
          <p className="mt-3 flex gap-2 text-xs text-muted-foreground"><BatteryCharging className="size-4 shrink-0 text-warning" />{t("Android puede detener el conteo para ahorrar batería. Pon la app en “Sin restricciones” para que no se corte.")}</p>
          <Btn variant="outline" className="mt-2" onClick={async () => { await openBatterySettings(); }}>{t("Quitar ahorro de batería")}</Btn>
        </>
      )}
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Btn variant="outline" onClick={() => void addWidget("small")}><LayoutGrid className="size-4" />{t("Widget pequeño")}</Btn>
        <Btn variant="outline" onClick={() => void addWidget("medium")}><LayoutGrid className="size-4" />{t("Widget mediano")}</Btn>
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import { SCHOOL, pointLatLng, type ExpPoint } from "@/lib/game";
import { useI18n } from "@/lib/i18n";

type Props = {
  points: ExpPoint[];
  doneIds: Set<string>;
  userPos: { lat: number; lng: number } | null;
  onPointClick?: (id: string) => void;
};

/** Carga Maps JavaScript API una sola vez (loading=async + callback + channel). */
let loadPromise: Promise<void> | null = null;
function loadGoogleMaps(): Promise<void> {
  if (loadPromise) return loadPromise;
  loadPromise = new Promise<void>((resolve, reject) => {
    const w = window as unknown as { google?: { maps?: unknown } } & Record<string, unknown>;
    if (w.google?.maps) {
      resolve();
      return;
    }
    const cb = "initPodometroGoogleMap";
    const key = import.meta.env["VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_BROWSER_KEY"];
    const channel = import.meta.env["VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_TRACKING_ID"];
    if (!key) {
      reject(new Error("Falta la clave de Google Maps"));
      return;
    }
    const timer = window.setTimeout(() => reject(new Error("Google Maps no respondió")), 15000);
    w[cb] = () => {
      window.clearTimeout(timer);
      resolve();
    };
    const s = document.createElement("script");
    s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&loading=async&callback=${cb}&channel=${encodeURIComponent(channel ?? "podometro")}`;
    s.async = true;
    s.onerror = () => {
      window.clearTimeout(timer);
      reject(new Error("No se pudo cargar Google Maps"));
    };
    document.head.appendChild(s);
  });
  return loadPromise;
}

export default function GoogleMap({ points, doneIds, userPos, onPointClick }: Props) {
  const divRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<unknown>(null);
  const userRef = useRef<{ dot: unknown; halo: unknown } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { t } = useI18n();
  const clickRef = useRef(onPointClick);
  clickRef.current = onPointClick;

  useEffect(() => {
    let cancelled = false;
    loadGoogleMaps()
      .then(() => {
        if (cancelled || !divRef.current || mapRef.current) return;
        const g = (window as unknown as { google: { maps: any } }).google;
        const map = new g.maps.Map(divRef.current, {
          center: SCHOOL,
          zoom: 18,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
          clickableIcons: false,
        });
        mapRef.current = map;
        // Colegio
        new g.maps.Marker({ map, position: SCHOOL, title: "I.E. Baltazar Salazar" });
        // Puntos experimentales
        for (const p of points) {
          const marker = new g.maps.Marker({
            map,
            position: pointLatLng(p, SCHOOL),
            title: `${p.id}. ${p.name}`,
            label: { text: p.id, color: "#ffffff", fontWeight: "700", fontSize: "12px" },
          });
          marker.addListener("click", () => clickRef.current?.(p.id));
        }
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : "Error al cargar el mapa");
      });
    return () => {
      cancelled = true;
    };
  }, [points]);

  // Punto azul de ubicación del usuario
  useEffect(() => {
    const g = (window as unknown as { google?: { maps: any } }).google;
    if (!mapRef.current || !g || !userPos) return;
    if (!userRef.current) {
      const halo = new g.maps.Circle({
        map: mapRef.current,
        center: userPos,
        radius: 20,
        fillColor: "#1A73E8",
        fillOpacity: 0.18,
        strokeOpacity: 0,
        clickable: false,
      });
      const dot = new g.maps.Marker({
        map: mapRef.current,
        position: userPos,
        clickable: false,
        zIndex: 10,
        icon: {
          path: g.maps.SymbolPath.CIRCLE,
          scale: 7,
          fillColor: "#1A73E8",
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 2.5,
        },
      });
      userRef.current = { dot, halo };
    } else {
      (userRef.current.dot as { setPosition: (p: unknown) => void }).setPosition(userPos);
      (userRef.current.halo as { setCenter: (p: unknown) => void }).setCenter(userPos);
    }
  }, [userPos]);

  return (
    <div className="relative h-80 w-full">
      <div ref={divRef} className="size-full" />
      {error && (
        <div className="absolute inset-0 grid place-items-center bg-muted p-6 text-center text-sm text-muted-foreground">
          {t(error)}{t(". Abre la app en la vista previa publicada para ver el mapa de Google.")}
        </div>
      )}
    </div>
  );
}

import { Link, useNavigate, useRouter, useRouterState } from "@tanstack/react-router";
import { BarChart3, ChevronLeft, Heart, Home, MapPin, Zap } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";

// Icono incluido en la app (public/): se ve también sin internet. El archivo original de 1.6 MB vive en la nube de Lovable.
export const LOGO = "/icon-512.png";

export function Logo({ size = 44, className }: { size?: number; className?: string }) {
  return (
    <img src={LOGO} alt="Podómetro B.S" width={size} height={size}
      className={cn("rounded-[22%] border border-border object-cover", className)} style={{ width: size, height: size }} />
  );
}

/** Contenedor tipo teléfono con protección de sesión opcional. */
export function Screen({ children, nav, guard, className }: { children: ReactNode; nav?: boolean; guard?: boolean; className?: string }) {
  const { s, ready, user, profile } = useStore();
  const navigate = useNavigate();
  useEffect(() => {
    if (!ready || !guard) return;
    if (!user) navigate({ to: "/login" });
    else if (!profile) navigate({ to: "/perfil" });
  }, [ready, guard, user, profile, navigate]);
  if (guard && (!ready || !user || !profile)) return <Shell theme={s.theme}><div className="min-h-screen" /></Shell>;
  return (
    <Shell theme={s.theme}>
      <div className={cn("app-hero flex min-h-screen flex-col px-5 pt-6", nav ? "pb-28" : "pb-8", className)}>{children}</div>
      {nav && <BottomNav />}
    </Shell>
  );
}

function Shell({ children, theme }: { children: ReactNode; theme: string }) {
  return (
    <div className={cn(`theme-${theme}`, "mx-auto min-h-screen w-full max-w-md bg-background text-foreground shadow-2xl relative")}>
      {children}
    </div>
  );
}

export function BackHeader({ title, kicker, right, to }: { title: string; kicker?: string; right?: ReactNode; to?: string }) {
  const router = useRouter();
  const { t } = useI18n();
  return (
    <div className="mb-5 flex items-center gap-3">
      {to !== "" && (
        <button onClick={() => (to ? router.navigate({ to }) : router.history.back())} aria-label={t("Volver")}
          className="grid size-10 shrink-0 place-items-center rounded-full bg-secondary">
          <ChevronLeft className="size-5" />
        </button>
      )}
      <div className="min-w-0 flex-1">
        {kicker && <p className="text-xs text-muted-foreground">{kicker}</p>}
        <h1 className="truncate text-2xl font-bold leading-tight">{title}</h1>
      </div>
      {right}
    </div>
  );
}

const tabs = [
  { to: "/inicio", label: "Inicio", icon: Home },
  { to: "/mapa", label: "Mapa", icon: MapPin },
  { to: "/entrenar", label: "Entrenar", icon: Zap, center: true },
  { to: "/ranking", label: "Ranking", icon: BarChart3 },
  { to: "/salud", label: "Salud", icon: Heart },
] as const;

export function BottomNav() {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const { t: tr } = useI18n();
  const group = (p: string) =>
    p.startsWith("/ranking") || p.startsWith("/logros") ? "/ranking"
    : p.startsWith("/salud") || p.startsWith("/presion") || p.startsWith("/sueno") || p.startsWith("/eventos") ? "/salud"
    : p.startsWith("/punto") ? "/mapa" : p.startsWith("/analisis") ? "/inicio" : p;
  const active = group(path);
  return (
    <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-md -translate-x-1/2 border-t border-border bg-background/95 backdrop-blur">
      <div className="grid grid-cols-5 px-2 pb-4 pt-2">
        {tabs.map((t) => {
          const on = active === t.to;
          const I = t.icon;
          return (
            <Link key={t.to} to={t.to} className={cn("flex flex-col items-center gap-1 text-[11px]", on ? "text-primary" : "text-muted-foreground")}>
              {"center" in t ? (
                <span className="-mt-6 grid size-14 place-items-center rounded-full bg-primary text-primary-foreground glow-primary">
                  <I className="size-6" fill="currentColor" />
                </span>
              ) : (
                <I className="size-6" />
              )}
              <span className={cn("center" in t && "font-semibold text-foreground")}>{tr(t.label)}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function Ring({ value, max, size = 140, stroke = 14, children, segments }: {
  value: number; max: number; size?: number; stroke?: number; children?: ReactNode;
  segments?: { value: number; color: string }[];
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const segs = segments ?? [{ value, color: "var(--primary)" }];
  let offset = 0;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--muted)" strokeWidth={stroke} />
        {segs.map((sg, i) => {
          const frac = Math.min(1, Math.max(0, sg.value / max)) * Math.max(0, 1 - offset);
          const el = (
            <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={sg.color} strokeWidth={stroke}
              strokeLinecap="round" strokeDasharray={`${frac * c} ${c}`} strokeDashoffset={-offset * c}
              style={{ transition: "stroke-dasharray .6s" }} />
          );
          offset += frac;
          return el;
        })}
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)}
      className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", on ? "bg-primary" : "bg-muted")}>
      <span className={cn("absolute top-1 size-5 rounded-full bg-primary-foreground transition-all", on ? "left-6" : "left-1")} />
    </button>
  );
}

export function Btn({ children, variant = "primary", className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "outline" | "ghost" }) {
  return (
    <button {...p}
      className={cn("flex h-14 w-full items-center justify-center gap-2 rounded-2xl text-base font-semibold transition active:scale-[.98] disabled:opacity-40",
        variant === "primary" && "bg-primary text-primary-foreground glow-primary",
        variant === "outline" && "border border-border bg-card",
        variant === "ghost" && "text-muted-foreground",
        className)}>
      {children}
    </button>
  );
}

export function Chip({ on, children, onClick, className }: { on?: boolean; children: ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button onClick={onClick} type="button"
      className={cn("rounded-2xl border px-4 py-3 text-sm font-medium transition",
        on ? "border-primary bg-accent text-foreground" : "border-border bg-card text-muted-foreground", className)}>
      {children}
    </button>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: ReactNode }) {
  return (
    <label className="mb-4 block">
      <span className="mb-1.5 block text-sm text-muted-foreground">{label}</span>
      {children}
      {hint}
    </label>
  );
}
export const inputCls = "h-14 w-full rounded-2xl border border-input bg-card px-4 text-base outline-none placeholder:text-muted-foreground focus:border-primary";

export function Badge({ tone = "success", children }: { tone?: "success" | "warning" | "primary"; children: ReactNode }) {
  return (
    <span className={cn("shrink-0 rounded-full px-3 py-1 text-xs font-semibold text-background",
      tone === "success" && "bg-success", tone === "warning" && "bg-warning", tone === "primary" && "bg-primary text-primary-foreground")}>
      {children}
    </span>
  );
}

export function GradeDot({ g }: { g: 9 | 10 }) {
  return (
    <span className={cn("grid size-7 shrink-0 place-items-center rounded-full text-[11px] font-bold",
      g === 9 ? "bg-grade9 text-background" : "bg-grade10 text-primary-foreground")}>{g}°</span>
  );
}

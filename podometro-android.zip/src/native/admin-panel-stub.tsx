// El panel de administración usa funciones de servidor: solo existe en la versión web.
export function AdminPanel() {
  return null;
}

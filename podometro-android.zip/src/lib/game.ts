import { dayTotal, streak, todayKey, type Day, type State } from "./store";

export type ExpPoint = { id: string; name: string; dx: number; dy: number; title: string; steps: [string, string][]; measure: boolean };

/** Puntos experimentales, ubicados en metros alrededor del primer lugar donde abriste el mapa. */
export const POINTS: ExpPoint[] = [
  { id: "1", name: "Cancha del colegio", dx: 120, dy: 80, title: "¿Cuántos pasos tiene una vuelta?", measure: false,
    steps: [["Cuenta tus pasos al caminar.", "Da una vuelta completa a la cancha."], ["Mira tu contador.", "Anota cuántos pasos sumaste."], ["Calcula.", "¿Cuántas vueltas serían 1 km?"]] },
  { id: "2", name: "Parque central", dx: -200, dy: 150, title: "Caminar vs. trotar", measure: false,
    steps: [["Camina 100 pasos.", "Mide cuánto tiempo te toma."], ["Trota 100 pasos.", "Vuelve a medir el tiempo."], ["Compara.", "¿Cuántas veces más rápido fuiste?"]] },
  { id: "3", name: "Escaleras de la biblioteca", dx: 300, dy: -100, title: "El experimento: ¿qué le pasa a tu pulso?", measure: true,
    steps: [["Mide tu pulso en reposo.", "Quédate quieto 30 segundos y anótalo."], ["Haz 50 saltos.", "La app los cuenta con el sensor de movimiento."], ["Mide el pulso otra vez.", "Compara y mira cuánto subió."]] },
  { id: "4", name: "Tienda escolar", dx: -80, dy: -250, title: "Pasos y calorías", measure: false,
    steps: [["Mira tus calorías de hoy.", "Están en la pantalla de inicio."], ["Compara con un snack.", "Un paquete de papas tiene unas 150 kcal."], ["Calcula.", "¿Cuántos pasos necesitas para gastarlo?"]] },
  { id: "5", name: "Entrada principal", dx: 450, dy: 300, title: "Tu largo de paso", measure: false,
    steps: [["Marca 10 metros.", "Usa baldosas o una cinta."], ["Camínalos normal.", "Cuenta tus pasos."], ["Divide.", "10 entre tus pasos = el largo de tu paso."]] },
];
export const POINT_BONUS = 300;

/** Ubicación fija del mapa: I.E. Baltazar Salazar. */
export const SCHOOL = { lat: 6.0786192, lng: -75.4235874 };
export function anchor(): { lat: number; lng: number } {
  return SCHOOL;
}
export function pointLatLng(p: ExpPoint, a: { lat: number; lng: number }) {
  return { lat: a.lat + p.dy / 111320, lng: a.lng + p.dx / (111320 * Math.cos((a.lat * Math.PI) / 180)) };
}

export function myDays(s: State) { return s.session ? s.days[s.session] ?? {} : {}; }

export function lastNDays(days: Record<string, Day>, n: number) {
  const out: { key: string; date: Date; day: Day | undefined; total: number }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const k = todayKey(d);
    out.push({ key: k, date: d, day: days[k], total: dayTotal(days[k]) });
  }
  return out;
}

export type Achievement = { id: string; t: string; done: boolean; progress?: string | undefined; pct?: number; tone: string; icon: string };

export function achievements(s: State, gradeRank: number): Achievement[] {
  const days = myDays(s);
  const goal = s.session ? s.profiles[s.session]?.goalSteps ?? 6000 : 6000;
  const vals = Object.values(days);
  const total = vals.reduce((a, d) => a + dayTotal(d), 0);
  const jumps = vals.reduce((a, d) => a + d.jumps, 0);
  const bike = vals.reduce((a, d) => a + d.bikeKm, 0);
  const best = Math.max(0, ...vals.map(dayTotal));
  const st = streak(days, goal);
  const goalDays = vals.filter((d) => dayTotal(d) >= goal).length;
  const pts = Object.keys(s.session ? s.points[s.session] ?? {} : {}).length;
  const mk = (id: string, t: string, cur: number, max: number, tone: string, icon: string, unit = ""): Achievement => ({
    id, t, done: cur >= max, pct: Math.min(1, cur / max), progress: cur >= max ? undefined : `${Math.floor(cur)}${unit}/${max}${unit}`, tone, icon,
  });
  return [
    mk("a1", "Primeros 1,000 pasos", total, 1000, "bg-primary", "foot"),
    mk("a2", "Primera meta del día", goalDays, 1, "bg-primary", "check"),
    mk("a3", "Racha de 3 días", st, 3, "bg-warning", "flame"),
    mk("a4", "25,000 pasos en total", total, 25000, "bg-primary", "flag"),
    mk("a5", "Primeros 50 saltos", jumps, 50, "bg-foreground", "jump"),
    mk("a6", "Primeros 5 km en bici", bike, 5, "bg-success", "bike"),
    mk("a7", "Primer punto del mapa", pts, 1, "bg-foreground", "pin"),
    mk("a8", "Racha de 7 días", st, 7, "bg-warning", "flame"),
    mk("a9", "100,000 pasos en total", total, 100000, "bg-primary", "flag"),
    mk("a10", "500 saltos en total", jumps, 500, "bg-foreground", "jump"),
    mk("a11", "50 km en bici", bike, 50, "bg-success", "bike", ""),
    mk("a12", "5 puntos del mapa", pts, 5, "bg-foreground", "pin"),
    mk("a13", "Racha de 30 días", st, 30, "bg-warning", "flame"),
    mk("a14", "10,000 pasos en un día", best, 10000, "bg-primary", "foot"),
    { id: "a15", t: "Entrar al top 10", done: gradeRank > 0 && gradeRank <= 10, tone: "bg-warning", icon: "crown" },
  ];
}

export function rankingList(s: State) {
  const regs = s.users.map((u) => {
    const d = s.days[u.email] ?? {};
    const goal = s.profiles[u.email]?.goalSteps ?? 6000;
    return { name: u.name, grade: u.grade, steps: Object.values(d).reduce((a, x) => a + dayTotal(x), 0), streak: streak(d, goal), me: u.email === s.session };
  });
  return regs.sort((a, b) => b.steps - a.steps);
}
export function myRank(s: State) { return rankingList(s).findIndex((r) => r.me) + 1; }

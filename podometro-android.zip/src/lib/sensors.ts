import { useEffect } from "react";
import { useStore } from "./store";
import { isNative, nativeStepsReady, requestNativePermissions } from "./native";

export const hasMotion = () => typeof window !== "undefined" && "DeviceMotionEvent" in window;

/** iOS exige pedir permiso de movimiento desde un toque del usuario. */
export async function requestMotion(): Promise<boolean> {
  // En la app de Android los pasos los cuenta el sensor del teléfono; no hace falta el permiso de iOS.
  if (isNative()) return nativeStepsReady() || hasMotion();
  const DME = (window as unknown as { DeviceMotionEvent?: { requestPermission?: () => Promise<string> } }).DeviceMotionEvent;
  if (DME?.requestPermission) {
    try { return (await DME.requestPermission()) === "granted"; } catch { return false; }
  }
  return hasMotion();
}
export async function requestNotifications() {
  if (isNative()) return (await requestNativePermissions())?.notificationsGranted ?? false;
  if (typeof Notification === "undefined") return false;
  try { return (await Notification.requestPermission()) === "granted"; } catch { return false; }
}
export function requestLocation(): Promise<boolean> {
  return new Promise((res) => {
    if (!navigator.geolocation) return res(false);
    navigator.geolocation.getCurrentPosition(() => res(true), () => res(false), { timeout: 8000 });
  });
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371, toR = (x: number) => (x * Math.PI) / 180;
  const dLat = toR(b.lat - a.lat), dLng = toR(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toR(a.lat)) * Math.cos(toR(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Solo escucha durante una sesión activa; cada pico se guarda sin búfer pendiente. */
export function useStepCounter(mode: "walk" | "jump" | null) {
  const { user, profile, addToday, s } = useStore();

  useEffect(() => {
    if (!mode || !user || !profile || !hasMotion()) return;
    // En la app de Android caminar lo cuenta el servicio nativo (también con la pantalla apagada).
    if (mode === "walk" && nativeStepsReady()) return;
    let last = 0;
    let above = false;
    const jumpThr = 26 - (s.jumpSens / 100) * 10; // 16..26 m/s²
    const onMotion = (e: DeviceMotionEvent) => {
      if (document.visibilityState === "hidden") return;
      const a = e.accelerationIncludingGravity;
      if (!a || a.x == null || a.y == null || a.z == null) return;
      const mag = Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
      const now = Date.now();
      const thr = mode === "jump" ? jumpThr : 11.8;
      if (mag > thr && !above && now - last > (mode === "jump" ? 350 : 280)) {
        above = true;
        last = now;
        addToday(mode === "jump" ? { jumps: 1 } : { walk: 1 });
      } else if (mag < thr - 1.2) above = false;
    };
    window.addEventListener("devicemotion", onMotion);
    return () => window.removeEventListener("devicemotion", onMotion);
  }, [mode, user?.email, Boolean(profile), addToday, s.jumpSens]);
}

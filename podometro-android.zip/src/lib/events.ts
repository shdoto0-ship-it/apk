import { Activity, Apple, Dumbbell, Heart, Moon, Smile, Zap, type LucideIcon } from "lucide-react";

export const CATEGORIES = ["Energía", "Ejercicios", "Sueño y descanso", "Dieta y hábitos", "Actividad", "Estilo de vida", "Salud y síntomas"];
export const EVENT_ICON: Record<string, LucideIcon> = {
  "Energía": Zap, "Ejercicios": Dumbbell, "Sueño y descanso": Moon, "Dieta y hábitos": Apple,
  "Actividad": Activity, "Estilo de vida": Smile, "Salud y síntomas": Heart,
};

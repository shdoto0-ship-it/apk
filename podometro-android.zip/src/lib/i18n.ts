import { useMemo } from "react";
import { useStore } from "./store";
import { translate, type Lang } from "./translations";

export const KM_TO_MI = 0.621371;
export const M_TO_FT = 3.28084;

/**
 * Idioma y unidades para mostrar en pantalla.
 * Todo lo guardado (pasos, kilómetros, metros) sigue en el sistema métrico: aquí solo se convierte para mostrar.
 */
export function useI18n() {
  const { s } = useStore();
  const lang: Lang = s.lang === "en" ? "en" : "es";
  const mi = s.units === "mi";
  return useMemo(() => ({
    lang,
    locale: lang === "en" ? "en-US" : "es-CO",
    miles: mi,
    t: (text: string, vars?: Record<string, string | number>) => translate(lang, text, vars),
    /** Unidad de distancia larga: km o mi. */
    distUnit: mi ? "mi" : "km",
    speedUnit: mi ? "mph" : "km/h",
    /** Kilómetros guardados → número en la unidad elegida. */
    distNum: (km: number) => (mi ? km * KM_TO_MI : km),
    /** Kilómetros guardados → texto con decimales en la unidad elegida. */
    dist: (km: number, digits = 1) => (mi ? km * KM_TO_MI : km).toFixed(digits),
    /** Distancia corta (metros guardados) → "120 m" o "394 ft". */
    shortDist: (meters: number) => (mi ? `${Math.round(meters * M_TO_FT)} ft` : `${Math.round(meters)} m`),
    /** Pasos por unidad de distancia para bici (435 por km = 700 por milla). */
    stepsPerUnit: (perKm: number) => Math.round(mi ? perKm / KM_TO_MI : perKm),
    /** Iniciales de los días de la semana, domingo primero. */
    dow: lang === "en" ? ["S", "M", "T", "W", "T", "F", "S"] : ["D", "L", "M", "M", "J", "V", "S"],
    grade: (g: 9 | 10) => translate(lang, g === 9 ? "Noveno" : "Décimo"),
  }), [lang, mi]);
}

import { beforeEach, describe, expect, it, vi } from "vitest";

const plugin = vi.hoisted(() => ({ peek: vi.fn(), ack: vi.fn() }));
vi.mock("@capacitor/core", () => ({ Capacitor: { isNativePlatform: () => true }, registerPlugin: () => plugin }));

import { drainNativeSteps } from "./native";

beforeEach(() => {
  localStorage.clear();
  plugin.peek.mockReset();
  plugin.ack.mockReset();
  plugin.ack.mockResolvedValue(undefined);
});

describe("Pasos del servicio nativo", () => {
  it("suma cada bloque una sola vez y lo confirma al teléfono", async () => {
    plugin.peek.mockResolvedValue({ chunks: [{ seq: 1, day: "2026-10-25", steps: 30 }, { seq: 2, day: "2026-10-25", steps: 12 }], today: 42 });
    const apply = vi.fn();
    expect(await drainNativeSteps(apply)).toBe(42);
    expect(apply).toHaveBeenNthCalledWith(1, "2026-10-25", 30);
    expect(apply).toHaveBeenNthCalledWith(2, "2026-10-25", 12);
    expect(plugin.ack).toHaveBeenCalledWith({ seq: 2 });
  });

  it("no duplica pasos si la app se cerró antes de confirmar", async () => {
    plugin.peek.mockResolvedValue({ chunks: [{ seq: 1, day: "2026-10-25", steps: 30 }], today: 30 });
    await drainNativeSteps(vi.fn());
    // El teléfono vuelve a entregar el mismo bloque porque nunca recibió la confirmación.
    const again = vi.fn();
    expect(await drainNativeSteps(again)).toBe(0);
    expect(again).not.toHaveBeenCalled();
    expect(plugin.ack).toHaveBeenLastCalledWith({ seq: 1 });
  });

  it("suma los bloques nuevos y respeta el día de cada uno", async () => {
    plugin.peek.mockResolvedValue({ chunks: [{ seq: 1, day: "2026-10-24", steps: 100 }], today: 0 });
    await drainNativeSteps(vi.fn());
    plugin.peek.mockResolvedValue({ chunks: [{ seq: 2, day: "2026-10-24", steps: 5 }, { seq: 3, day: "2026-10-25", steps: 8 }], today: 8 });
    const apply = vi.fn();
    expect(await drainNativeSteps(apply)).toBe(13);
    expect(apply).toHaveBeenCalledWith("2026-10-24", 5);
    expect(apply).toHaveBeenCalledWith("2026-10-25", 8);
  });
});

import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (error || !data) throw new Error("Solo el administrador puede hacer esto");
}

export const listStudents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const users: { id: string; email: string }[] = [];
    for (let page = 1; page < 50; page++) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw new Error(error.message);
      users.push(...data.users.map((u) => ({ id: u.id, email: u.email ?? "" })));
      if (data.users.length < 1000) break;
    }
    const { data: profiles } = await supabaseAdmin.from("profiles").select("id,name,grade");
    const byId = new Map((profiles ?? []).map((p) => [p.id, p]));
    return users
      .map((u) => ({ ...u, name: byId.get(u.id)?.name ?? "", grade: byId.get(u.id)?.grade ?? null }))
      .sort((a, b) => a.name.localeCompare(b.name));
  });

export const setStudentPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; password: string }) => {
    if (typeof input?.userId !== "string" || !/^[0-9a-f-]{36}$/i.test(input.userId)) throw new Error("Usuario inválido");
    if (typeof input.password !== "string" || input.password.length < 8 || input.password.length > 72) throw new Error("La contraseña necesita entre 8 y 72 caracteres");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, { password: data.password });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

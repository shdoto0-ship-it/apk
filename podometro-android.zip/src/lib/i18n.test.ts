import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { english, translate } from "./translations";
import { KM_TO_MI, M_TO_FT } from "./i18n";

const SRC = join(__dirname, "..");
function sources(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) return name === "ui" || name === "test" ? [] : sources(p);
    return /\.tsx?$/.test(name) && !/\.test\.tsx?$/.test(name) && name !== "translations.ts" ? [p] : [];
  });
}

describe("Idioma", () => {
  it("deja el texto en español cuando el idioma es español o no hay idioma", () => {
    expect(translate("es", "Ajustes")).toBe("Ajustes");
    expect(translate(null, "Ajustes")).toBe("Ajustes");
  });

  it("traduce al inglés y vuelve a español sin perder nada", () => {
    expect(translate("en", "Ajustes")).toBe("Settings");
    expect(translate("es", "Ajustes")).toBe("Ajustes");
  });

  it("rellena los valores variables en los dos idiomas", () => {
    expect(translate("es", "Hola, {name}", { name: "ANA" })).toBe("Hola, ANA");
    expect(translate("en", "Hola, {name}", { name: "ANA" })).toBe("Hello, ANA");
    expect(translate("en", "{n} {u} en bici", { n: "3.1", u: "mi" })).toBe("3.1 mi cycling");
  });

  it("no toca los textos escritos por los estudiantes", () => {
    expect(translate("en", "Corrí en el recreo")).toBe("Corrí en el recreo");
  });

  it("todas las frases de la app tienen traducción al inglés", () => {
    const missing = new Set<string>();
    for (const file of sources(SRC)) {
      const code = readFileSync(file, "utf8");
      for (const m of code.matchAll(/\bt\(\s*"((?:[^"\\\n]|\\.)*)"/g)) {
        const key = JSON.parse(`"${m[1]}"`) as string;
        if (!(key in english)) missing.add(key);
      }
    }
    expect([...missing]).toEqual([]);
  });
});

describe("Unidades", () => {
  it("convierte kilómetros guardados a millas solo para mostrar", () => {
    expect(+(5 * KM_TO_MI).toFixed(1)).toBe(3.1);
    expect(+(10 * KM_TO_MI).toFixed(2)).toBe(6.21);
  });

  it("435 pasos por kilómetro son 700 por milla", () => {
    expect(Math.round(435 / KM_TO_MI)).toBe(700);
  });

  it("50 metros son unos 164 pies", () => {
    expect(Math.round(50 * M_TO_FT)).toBe(164);
  });
});

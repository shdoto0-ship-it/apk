import FFT from "fft.js";

export const PULSE_DURATION_MS = 30_000;
export type PulseSample = { at: number; red: number; green: number; blue: number };
export type PulseResult = { bpm: number; quality: "Señal consistente" };

export function fingerPresent(s: PulseSample) {
  return s.red > 35 && s.red < 253 && s.red > s.green * 1.12 && s.red > s.blue * 1.12;
}

function spectrum(values: number[], rate: number): number | null {
  // Remove illumination/exposure drift with a centered two-second moving mean.
  const radius = Math.round(rate);
  const centered = values.map((v, i) => {
    const part = values.slice(Math.max(0, i - radius), Math.min(values.length, i + radius + 1));
    return v - part.reduce((a, b) => a + b, 0) / part.length;
  });
  const rms = Math.sqrt(centered.reduce((a, v) => a + v * v, 0) / centered.length);
  if (rms < 0.12 || rms > 12) return null;
  const size = 4096;
  const fft = new FFT(size);
  const input = Array<number>(size).fill(0);
  centered.forEach((v, i) => { input[i] = v * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / (centered.length - 1))); });
  const out = fft.createComplexArray();
  fft.realTransform(out, input);
  const low = Math.ceil(0.7 * size / rate), high = Math.floor(3.5 * size / rate);
  const powers: number[] = [];
  let peak = low;
  for (let k = low; k <= high; k++) {
    const power = Number(out[k * 2] ?? 0) ** 2 + Number(out[k * 2 + 1] ?? 0) ** 2;
    powers[k] = power;
    if (power > (powers[peak] ?? 0)) peak = k;
  }
  let total = 0, concentrated = 0, rival = 0;
  for (let k = low; k <= high; k++) {
    const power = powers[k] ?? 0;
    total += power;
    if (Math.abs(k - peak) * rate / size < 0.14) concentrated += power;
    else if (Math.abs(k - peak) * rate / size > 0.22) rival = Math.max(rival, power);
  }
  if (!total || concentrated / total < 0.48 || rival > (powers[peak] ?? 0) * 0.55) return null;
  return peak * rate / size * 60;
}

/** Experimental contact PPG; reject weak/unstable captures rather than guessing. */
export function estimatePulse(samples: PulseSample[]): PulseResult | null {
  if (samples.length < 300) return null;
  const first = samples[0], last = samples.at(-1);
  if (!first || !last || last.at - first.at < PULSE_DURATION_MS - 200) return null;
  if (samples.filter(fingerPresent).length / samples.length < 0.95) return null;
  for (let i = 1; i < samples.length; i++) {
    const current = samples[i], previous = samples[i - 1];
    if (!current || !previous) return null;
    if (current.at <= previous.at || current.at - previous.at > 250) return null;
    if (Math.abs(current.red - previous.red) > 18) return null;
  }
  const rate = 30;
  const values: number[] = [];
  let index = 1;
  for (let at = first.at; at <= last.at; at += 1000 / rate) {
    while (index < samples.length - 1 && (samples[index]?.at ?? Infinity) < at) index++;
    const a = samples[index - 1], b = samples[index];
    if (!a || !b) return null;
    values.push(a.red + (b.red - a.red) * (at - a.at) / (b.at - a.at));
  }
  const bpm = spectrum(values, rate);
  const half = Math.floor(values.length / 2);
  const left = spectrum(values.slice(0, half), rate), right = spectrum(values.slice(half), rate);
  if (bpm === null || left === null || right === null || Math.abs(left - right) > 10 || Math.abs(bpm - left) > 10 || Math.abs(bpm - right) > 10) return null;
  return { bpm: Math.round(bpm), quality: "Señal consistente" };
}

export const pulseGuidance = (bpm: number) => bpm < 60 || bpm > 100
  ? "La estimación está fuera del intervalo habitual de reposo de 60–100 lpm. Puede variar con el ejercicio, el estrés o tu condición física. Descansa y repite; si persiste o te sientes mal, avisa a un adulto y consulta a un profesional."
  : "La estimación está dentro del intervalo habitual de reposo de 60–100 lpm para adolescentes. No confirma que todo esté bien ni descarta problemas de salud.";
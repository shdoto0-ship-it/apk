import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const getUser = vi.hoisted(() => vi.fn());
vi.mock("@/integrations/supabase/client", () => ({ supabase: { auth: { getUser } } }));

import { getAuthUser, readStoredUser } from "./offline-auth";

const KEY = "sb-abc123-auth-token";
const session = { access_token: "x", user: { id: "u1", email: "ana@test.invalid", user_metadata: { name: "ANA PEREZ" } } };

beforeEach(() => {
  vi.stubEnv("VITE_SUPABASE_URL", "https://abc123.supabase.co");
  localStorage.clear();
  getUser.mockReset();
});
afterEach(() => { vi.unstubAllEnvs(); vi.restoreAllMocks(); });

describe("Sesión sin conexión", () => {
  it("lee el usuario guardado en el teléfono", () => {
    localStorage.setItem(KEY, JSON.stringify(session));
    expect(readStoredUser()).toMatchObject({ id: "u1", email: "ana@test.invalid" });
  });

  it("no inventa usuario si no hay sesión guardada", () => {
    expect(readStoredUser()).toBeNull();
  });

  it("sin internet entra con la sesión guardada y no llama al servidor", async () => {
    localStorage.setItem(KEY, JSON.stringify(session));
    vi.spyOn(navigator, "onLine", "get").mockReturnValue(false);
    expect((await getAuthUser())?.email).toBe("ana@test.invalid");
    expect(getUser).not.toHaveBeenCalled();
  });

  it("si la red falla a mitad de camino también usa la sesión guardada", async () => {
    localStorage.setItem(KEY, JSON.stringify(session));
    vi.spyOn(navigator, "onLine", "get").mockReturnValue(true);
    getUser.mockResolvedValue({ data: { user: null }, error: { name: "AuthRetryableFetchError", message: "Failed to fetch", status: 0 } });
    expect((await getAuthUser())?.id).toBe("u1");
  });

  it("con internet y sesión inválida NO deja entrar", async () => {
    localStorage.setItem(KEY, JSON.stringify(session));
    vi.spyOn(navigator, "onLine", "get").mockReturnValue(true);
    getUser.mockResolvedValue({ data: { user: null }, error: { name: "AuthApiError", message: "invalid JWT", status: 401 } });
    expect(await getAuthUser()).toBeNull();
  });
});

import { describe, expect, it } from "vitest";
import { rankingList } from "./game";
import { calculateGradeTotals, emptyDay, type State } from "./store";

const emptyState = (): State => ({
  lang: "es", permsDone: true, users: [], session: null, profiles: {}, days: {},
  bp: {}, sleep: {}, events: {}, points: {}, theme: "vino", units: "km",
  jumpSens: 60, notifications: true, lastSync: null, celebrated: false, gradeConfirmed: false,
});

describe("Competencia sin datos ficticios", () => {
  it("deja Tops vacío sin usuarios registrados", () => {
    expect(rankingList(emptyState())).toEqual([]);
  });

  it("inicia los contadores de 9° y 10° exactamente en cero", () => {
    expect(calculateGradeTotals(emptyState())).toEqual({ 9: 0, 10: 0 });
  });

  it("conserva los participantes registrados y suma solo su actividad", () => {
    const s = emptyState();
    s.users = [
      { name: "Participante A", email: "a@example.test", birth: "", grade: 9 },
      { name: "Participante B", email: "b@example.test", birth: "", grade: 10 },
    ];
    s.session = "a@example.test";
    s.days = {
      "a@example.test": { "2026-10-23": { ...emptyDay(), walk: 120 } },
      "b@example.test": { "2026-10-23": { ...emptyDay(), walk: 80 } },
      "orphan@example.test": { "2026-10-23": { ...emptyDay(), walk: 999999 } },
    };
    expect(calculateGradeTotals(s)).toEqual({ 9: 120, 10: 80 });
    expect(rankingList(s).map(({ name, steps }) => ({ name, steps }))).toEqual([
      { name: "Participante A", steps: 120 }, { name: "Participante B", steps: 80 },
    ]);
  });
});
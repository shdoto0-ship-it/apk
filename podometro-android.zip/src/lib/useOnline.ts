import { useEffect, useState } from "react";

export function useOnline() {
  const [on, setOn] = useState(true);
  useEffect(() => {
    setOn(navigator.onLine);
    const u = () => setOn(true), d = () => setOn(false);
    window.addEventListener("online", u);
    window.addEventListener("offline", d);
    return () => { window.removeEventListener("online", u); window.removeEventListener("offline", d); };
  }, []);
  return on;
}

import { supabase } from "@/integrations/supabase/client";
import type { Json, TablesUpdate } from "@/integrations/supabase/types";
import type { Day, Profile, State } from "./store";

export type RankingEntry = { id: string; name: string; grade: 9 | 10; steps: number; streak: number; me: boolean };
export type ActivityOperation = { id: string; day: string; delta: Partial<Day> };
export type PendingCloud = { operations: ActivityOperation[]; profile: TablesUpdate<"profiles"> };
export const emptyPending = (): PendingCloud => ({ operations: [], profile: {} });
export const asJson = (value: unknown): Json => JSON.parse(JSON.stringify(value)) as Json;

export function mergePendingActivity(days: Record<string, Day>, operations: ActivityOperation[]): Record<string, Day> {
  const result = { ...days };
  for (const op of operations) {
    const day = { walk: 0, jumps: 0, bikeKm: 0, activeMin: 0, bonus: 0, ...result[op.day] };
    for (const key of ["walk", "jumps", "bikeKm", "activeMin", "bonus"] as const) day[key] += op.delta[key] ?? 0;
    result[op.day] = day;
  }
  return result;
}

export async function readCloudAccount(id: string, email: string, pending: PendingCloud): Promise<Partial<State>> {
  const [person, activity] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", id).single(),
    (async () => {
      const rows = [];
      for (let offset = 0; ; offset += 1000) {
        const response = await supabase.from("activity_daily").select("*").eq("user_id", id).order("day", { ascending: true }).range(offset, offset + 999);
        if (response.error) throw response.error;
        rows.push(...response.data);
        if (response.data.length < 1000) return rows;
      }
    })(),
  ]);
  if (person.error) throw person.error;
  const p = { ...person.data, ...pending.profile };
  const settings = p.settings as Partial<Pick<State, "theme" | "lang" | "units" | "jumpSens" | "notifications" | "celebrated">>;
  const days: Record<string, Day> = {};
  for (const d of activity) days[d.day] = { walk: d.walk, jumps: d.jumps, bikeKm: d.bike_km, activeMin: d.active_min, bonus: d.bonus, ...(d.goal_at ? { goalAt: d.goal_at } : {}) };
  // A request may have succeeded before the browser closed. Do not apply acknowledged operations twice.
  const remaining: ActivityOperation[] = [];
  for (let i = 0; i < pending.operations.length; i += 100) {
    const group = pending.operations.slice(i, i + 100);
    const ack = await supabase.from("activity_operations").select("operation_id").eq("user_id", id).in("operation_id", group.map((o) => o.id));
    if (ack.error) throw ack.error;
    const acknowledged = new Set(ack.data.map((o) => o.operation_id));
    remaining.push(...group.filter((o) => !acknowledged.has(o.id)));
  }
  return {
    session: email,
    gradeConfirmed: p.grade_confirmed === true,
    users: [{ email, name: p.name ?? "", birth: p.birth ?? "", grade: p.grade === 10 ? 10 : 9 }],
    profiles: p.profile ? { [email]: p.profile as unknown as Profile } : {},
    days: { [email]: mergePendingActivity(days, remaining) },
    bp: { [email]: p.bp as unknown as State["bp"][string] },
    sleep: { [email]: p.sleep as unknown as State["sleep"][string] },
    events: { [email]: p.events as unknown as State["events"][string] },
    points: { [email]: p.points as unknown as State["points"][string] },
    ...(settings.theme ? { theme: settings.theme } : {}),
    ...(settings.lang ? { lang: settings.lang } : {}),
    ...(settings.units ? { units: settings.units } : {}),
    ...(typeof settings.jumpSens === "number" ? { jumpSens: settings.jumpSens } : {}),
    ...(typeof settings.notifications === "boolean" ? { notifications: settings.notifications } : {}),
    ...(typeof settings.celebrated === "boolean" ? { celebrated: settings.celebrated } : {}),
  };
}

export async function readCompetition(id: string): Promise<RankingEntry[]> {
  const rows: RankingEntry[] = [];
  for (let offset = 0; ; offset += 1000) {
    const { data, error } = await supabase.rpc("get_competition").range(offset, offset + 999);
    if (error) throw error;
    rows.push(...data.map((r) => ({ ...r, grade: (r.grade === 10 ? 10 : 9) as 9 | 10, me: r.id === id })));
    if (data.length < 1000) return rows;
  }
}
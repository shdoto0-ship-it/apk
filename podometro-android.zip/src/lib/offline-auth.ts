/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabase } from "@/integrations/supabase/client";

export type AuthUserLike = { id: string; email?: string | undefined; user_metadata: Record<string, any> };

/** Clave donde Supabase guarda la sesión en el teléfono (sb-<proyecto>-auth-token). */
function sessionKey(): string | null {
  const url = import.meta.env["VITE_SUPABASE_URL"] as string | undefined;
  if (!url) return null;
  try { return `sb-${new URL(url).hostname.split(".")[0]}-auth-token`; } catch { return null; }
}

/** Usuario de la sesión guardada en el dispositivo, sin pedir nada a internet. */
export function readStoredUser(): AuthUserLike | null {
  if (typeof localStorage === "undefined") return null;
  const key = sessionKey();
  if (!key) return null;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const user = parsed?.user ?? parsed?.currentSession?.user;
    if (user?.id && user?.email) return { id: user.id, email: user.email, user_metadata: user.user_metadata ?? {} };
  } catch { /* sesión guardada ilegible */ }
  return null;
}

function isNetworkFailure(error: { name?: string | undefined; message?: string | undefined; status?: number | undefined } | null): boolean {
  if (!error) return false;
  return error.name === "AuthRetryableFetchError" || error.status === 0 || /failed to fetch|network|load failed/i.test(error.message ?? "");
}

/**
 * Usuario actual. Con internet lo valida con el servidor; sin internet (o con la red caída)
 * usa la sesión guardada para que la app abra y siga contando pasos sin conexión.
 */
export async function getAuthUser(): Promise<AuthUserLike | null> {
  const offline = typeof navigator !== "undefined" && navigator.onLine === false;
  if (!offline) {
    try {
      const { data, error } = await supabase.auth.getUser();
      if (data.user) return data.user as AuthUserLike;
      if (!isNetworkFailure(error)) return null;
    } catch { /* red caída: se usa la sesión guardada */ }
  }
  return readStoredUser();
}

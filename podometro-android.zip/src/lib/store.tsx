import { supabase } from "@/integrations/supabase/client";
import { getAuthUser } from "./offline-auth";
import { drainNativeSteps, isNative, pushNativeSnapshot, startNativeCounting, stopNativeCounting } from "./native";
import { asJson, emptyPending, readCloudAccount, readCompetition, type PendingCloud, type RankingEntry } from "./cloud-data";
import { toast } from "sonner";
import { translate } from "./translations";
import { useRouter } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode, type Context } from "react";

export type Grade = 9 | 10;
export type User = { email: string; name: string; birth: string; grade: Grade };
export type Profile = {
  sex: "Mujer" | "Hombre" | "Prefiero no decirlo";
  height: number;
  weight: number;
  goal: string;
  goalSteps: number;
  jumpsOn: boolean;
  bikeOn: boolean;
};
export type Day = { walk: number; jumps: number; bikeKm: number; activeMin: number; goalAt?: string | undefined; bonus: number };
export type BP = { id: string; at: string; sys: number; dia: number; pulse: number; state: string };
export type Sleep = { id: string; date: string; bed: string; wake: string; feel: string; q1?: string; q2?: string; q3?: string };
export type EventItem = { id: string; at: string; text: string; category: string; feel: "Bien" | "Normal" | "Mal"; details?: string };
export type Theme = "vino" | "negro" | "blanco" | "rojo";

export type State = {
  lang: "es" | "en" | null;
  permsDone: boolean;
  users: User[];
  session: string | null;
  profiles: Record<string, Profile>;
  days: Record<string, Record<string, Day>>; // email -> date -> day
  bp: Record<string, BP[]>;
  sleep: Record<string, Sleep[]>;
  events: Record<string, EventItem[]>;
  points: Record<string, Record<string, string>>; // email -> pointId -> date done
  theme: Theme;
  units: "km" | "mi";
  jumpSens: number;
  notifications: boolean;
  lastSync: string | null;
  celebrated: boolean;
  gradeConfirmed: boolean;
};

const KEY = "podometro-cloud-v1";
const initial: State = {
  lang: null, permsDone: false, users: [], session: null, profiles: {}, days: {}, bp: {}, sleep: {}, events: {},
  points: {}, theme: "vino", units: "km", jumpSens: 60, notifications: true, lastSync: null, celebrated: false, gradeConfirmed: false,
};

// Sin cifras de ejemplo: solo se suman los registros de usuarios.
export const GRADE_BASE: Record<Grade, number> = { 9: 0, 10: 0 };
export const GRADE_GOAL = 10_000_000;
export const STEPS_PER_JUMP = 2;
export const STEPS_PER_BIKE_KM = 435;

export const todayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const emptyDay = (): Day => ({ walk: 0, jumps: 0, bikeKm: 0, activeMin: 0, bonus: 0 });
export const dayTotal = (d?: Day) => (d ? Math.round(d.walk + d.jumps * STEPS_PER_JUMP + d.bikeKm * STEPS_PER_BIKE_KM + d.bonus) : 0);
export function calculateGradeTotals(s: Pick<State, "users" | "days">): Record<Grade, number> {
  const totals: Record<Grade, number> = { ...GRADE_BASE };
  for (const user of s.users) {
    totals[user.grade] += Object.values(s.days[user.email] ?? {}).reduce((sum, day) => sum + dayTotal(day), 0);
  }
  return totals;
}
export const ageFrom = (birth: string) => {
  if (!birth) return 0;
  const b = new Date(birth), n = new Date();
  let a = n.getFullYear() - b.getFullYear();
  if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
  return Math.max(0, a);
};
export const stripAccents = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z ]/g, "").toUpperCase();
export const kmFor = (steps: number, heightCm = 165) => (steps * heightCm * 0.415) / 100000;
export const kcalFor = (steps: number, weightKg = 58) => Math.round(steps * 0.04 * (weightKg / 60));
export const fmt = (n: number) => Math.round(n).toLocaleString("en-US");
export const uid = () => Math.random().toString(36).slice(2, 10);

type Ctx = {
  s: State;
  ready: boolean;
  gradeConfirmed: boolean;
  set: (fn: (s: State) => Partial<State>) => void;
  user: User | null;
  profile: Profile | null;
  today: Day;
  addToday: (patch: Partial<Day>, day?: string) => void;
  myTotal: number;
  gradeTotals: Record<Grade, number>;
  ranking: RankingEntry[];
  syncStatus: "saved" | "pending" | "error";
  sync: () => Promise<void>;
  signOut: () => Promise<void>;
  setGrade: (grade: Grade) => void;
};
// Se guarda en globalThis para que la recarga en caliente no cree un contexto distinto
const g = globalThis as unknown as { __pbsCtx?: Context<Ctx | null> };
const C = (g.__pbsCtx ??= createContext<Ctx | null>(null));

export function StoreProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [s, setS] = useState<State>(initial);
  const [ready, setReady] = useState(false);
  const [ranking, setRanking] = useState<RankingEntry[]>([]);
  const [syncStatus, setSyncStatus] = useState<"saved" | "pending" | "error">("saved");
  const current = useRef(initial);
  const identity = useRef<{ id: string; email: string } | null>(null);
  const pending = useRef<PendingCloud>(emptyPending());
  const syncing = useRef(false);
  const revision = useRef(0);
  const alive = useRef(true);
  const commit = useCallback((next: State) => {
    current.current = next;
    setS(next);
    const who = identity.current;
    if (who) localStorage.setItem(`${KEY}:${who.id}`, JSON.stringify(next));
  }, []);
  const persistQueue = useCallback(() => {
    const who = identity.current;
    if (who) localStorage.setItem(`${KEY}:pending:${who.id}`, JSON.stringify(pending.current));
  }, []);
  const refresh = useCallback(async () => {
    const who = identity.current;
    if (!who) return;
    const version = revision.current;
    const [account, rows] = await Promise.all([readCloudAccount(who.id, who.email, pending.current), readCompetition(who.id)]);
    if (!alive.current || identity.current?.id !== who.id || version !== revision.current) return;
    commit({ ...current.current, ...account });
    setRanking(rows);
  }, [commit]);
  const sync = useCallback(async () => {
    const who = identity.current;
    if (!who || syncing.current || !navigator.onLine) return;
    syncing.current = true;
    try {
      while (identity.current?.id === who.id && pending.current.operations.length) {
        const op = pending.current.operations[0];
        if (!op) break;
        const { error } = await supabase.rpc("record_activity", { operation_id: op.id, activity_day: op.day, delta: asJson(op.delta) });
        if (error) throw error;
        if (identity.current?.id !== who.id) return;
        pending.current.operations = pending.current.operations.filter((o) => o.id !== op.id);
        persistQueue();
      }
      const patch = { ...pending.current.profile };
      if (Object.keys(patch).length) {
        const { error } = await supabase.from("profiles").update(patch).eq("id", who.id);
        if (error) throw error;
        if (identity.current?.id !== who.id) return;
        for (const key of Object.keys(patch) as (keyof typeof patch)[]) {
          if (JSON.stringify(pending.current.profile[key]) === JSON.stringify(patch[key])) delete pending.current.profile[key];
        }
        persistQueue();
      }
      if (identity.current?.id !== who.id) return;
      const isPending = pending.current.operations.length > 0 || Object.keys(pending.current.profile).length > 0;
      setSyncStatus(isPending ? "pending" : "saved");
      if (!isPending) commit({ ...current.current, lastSync: new Date().toISOString() });
      await refresh();
    } catch {
      if (identity.current?.id === who.id) setSyncStatus("error");
    } finally { syncing.current = false; }
  }, [commit, persistQueue, refresh]);

  useEffect(() => {
    alive.current = true;
    // Do not use old browser accounts or plaintext passwords as credentials.
    const legacy = localStorage.getItem("podometro-bs-v1");
    if (legacy) {
      try {
        const old = JSON.parse(legacy);
        old.users = (old.users ?? []).map(({ password: _password, ...user }: User & { password?: string }) => user);
        old.session = null;
        localStorage.setItem("podometro-bs-v1", JSON.stringify(old));
        commit({ ...initial, theme: old.theme ?? initial.theme, lang: old.lang ?? initial.lang, permsDone: old.permsDone ?? false });
      } catch { /* Ignore malformed legacy cache. */ }
    }
    let generation = 0;
    const hydrate = async () => {
      const ticket = ++generation;
      // Con internet valida la cuenta; sin internet usa la sesión guardada en el teléfono.
      const authUser = await getAuthUser();
      if (!alive.current || ticket !== generation) return;
      if (!authUser?.email) {
        identity.current = null; pending.current = emptyPending();
        commit({ ...initial, theme: current.current.theme, lang: current.current.lang, permsDone: current.current.permsDone });
        setRanking([]); setReady(true); return;
      }
      if (identity.current?.id === authUser.id) return;
      identity.current = { id: authUser.id, email: authUser.email };
      pending.current = emptyPending();
      try { pending.current = JSON.parse(localStorage.getItem(`${KEY}:pending:${authUser.id}`) ?? JSON.stringify(emptyPending())); } catch { /* Ignore invalid queue. */ }
      let cached = initial;
      try { cached = JSON.parse(localStorage.getItem(`${KEY}:${authUser.id}`) ?? JSON.stringify(initial)); } catch { /* Ignore invalid cache. */ }
      commit({ ...initial, ...cached, session: authUser.email, users: [{ email: authUser.email, name: authUser.user_metadata['name'] ?? "", birth: authUser.user_metadata['birth'] ?? "", grade: authUser.user_metadata['grade'] === 10 ? 10 : 9 }] });
      try { await refresh(); } catch { setSyncStatus(navigator.onLine ? "error" : "pending"); }
      if (alive.current && ticket === generation) { setReady(true); void sync(); }
    };
    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") setTimeout(() => {
        void hydrate();
        void router.invalidate();
        if (event !== "SIGNED_OUT") void queryClient.invalidateQueries();
      }, 0);
    });
    void hydrate();
    const onOnline = () => { void sync(); };
    window.addEventListener("online", onOnline);
    const timer = setInterval(() => {
      if (pending.current.operations.length || Object.keys(pending.current.profile).length) void sync();
    }, 1000);
    const channel = supabase.channel("school-competition")
      .on("postgres_changes", { event: "*", schema: "public", table: "competition_updates" }, () => { if (!syncing.current) void refresh().catch(() => setSyncStatus("error")); })
      .subscribe();
    return () => { alive.current = false; generation++; listener.subscription.unsubscribe(); clearInterval(timer); window.removeEventListener("online", onOnline); void supabase.removeChannel(channel); };
  }, [commit, refresh, sync, router, queryClient]);

  const set = useCallback((fn: (s: State) => Partial<State>) => {
    const before = current.current;
    const patch = fn(before);
    const next = { ...before, ...patch };
    const who = identity.current;
    if (who) {
      const update = pending.current.profile;
      if (patch.profiles) update.profile = asJson(next.profiles[who.email] ?? null);
      for (const key of ["bp", "sleep", "events", "points"] as const) if (patch[key]) update[key] = asJson(next[key][who.email] ?? (key === "points" ? {} : []));
      if (["theme", "lang", "units", "jumpSens", "notifications", "celebrated"].some((k) => k in patch)) {
        update.settings = asJson({ theme: next.theme, lang: next.lang, units: next.units, jumpSens: next.jumpSens, notifications: next.notifications, celebrated: next.celebrated });
      }
      revision.current++; persistQueue(); setSyncStatus("pending");
    }
    commit(next);
  }, [commit, persistQueue]);
  // Social sign-ins (Lovable) arrive without a grade: the student picks it in the profile wizard.
  const setGrade = useCallback((grade: Grade) => {
    const who = identity.current;
    const p = current.current;
    if (!who) return;
    pending.current.profile.grade = grade;
    pending.current.profile.grade_confirmed = true;
    revision.current++; persistQueue(); setSyncStatus("pending");
    commit({ ...p, users: p.users.map((u) => (u.email === who.email ? { ...u, grade } : u)), gradeConfirmed: true });
  }, [commit, persistQueue]);
  const addToday = useCallback((patch: Partial<Day>, day?: string) => {
    const who = identity.current;
    const p = current.current;
    if (!who || !p.session) return;
    const k = day ?? todayKey();
    const days = p.days[who.email] ?? {};
    const d = { ...(days[k] ?? emptyDay()) };
    for (const key of ["walk", "jumps", "bikeKm", "activeMin", "bonus"] as const) d[key] += patch[key] ?? 0;
    const goal = p.profiles[who.email]?.goalSteps ?? 6000;
    if (!d.goalAt && k === todayKey() && dayTotal(d) >= goal) d.goalAt = new Date().toTimeString().slice(0, 5);
    pending.current.operations.push({ id: crypto.randomUUID(), day: k, delta: patch });
    revision.current++; persistQueue(); setSyncStatus("pending");
    commit({ ...p, days: { ...p.days, [who.email]: { ...days, [k]: d } } });
  }, [commit, persistQueue]);
  const signOut = useCallback(async () => {
    // Los pasos que contó el teléfono se suman a esta cuenta antes de salir.
    await drainNativeSteps((day, steps) => addToday({ walk: steps }, day));
    await sync();
    const { error } = await supabase.auth.signOut();
    if (error) { toast.error(translate(current.current.lang, "No se pudo cerrar la sesión. Intenta de nuevo.")); throw error; }
    await stopNativeCounting();
    identity.current = null; pending.current = emptyPending(); setRanking([]);
    commit({ ...initial, theme: current.current.theme, lang: current.current.lang, permsDone: current.current.permsDone });
  }, [sync, commit, addToday]);
  const user = s.users.find((u) => u.email === s.session) ?? null;
  const profile = user ? s.profiles[user.email] ?? null : null;
  const myDays = user ? s.days[user.email] ?? {} : {};
  const today = myDays[todayKey()] ?? emptyDay();
  const gradeTotals = useMemo(() => ranking.reduce<Record<Grade, number>>((totals, r) => { totals[r.grade] += r.steps; return totals; }, { 9: 0, 10: 0 }), [ranking]);
  const myTotal = Object.values(myDays).reduce((a, d) => a + dayTotal(d), 0);
  // App de Android: el servicio nativo cuenta pasos aunque la pantalla esté apagada; aquí se suman a la cuenta.
  const nativeUser = user?.email ?? null;
  const nativeActive = Boolean(nativeUser && profile);
  useEffect(() => {
    if (!isNative() || !nativeActive) return;
    let off = false;
    const pull = () => { if (!off) void drainNativeSteps((day, steps) => addToday({ walk: steps }, day)); };
    void startNativeCounting().then(pull);
    const timer = setInterval(pull, 3000);
    const onVisible = () => { if (document.visibilityState === "visible") pull(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => { off = true; clearInterval(timer); document.removeEventListener("visibilitychange", onVisible); };
  }, [nativeActive, nativeUser, addToday]);
  // Datos para los widgets de la pantalla de inicio.
  const todaySteps = dayTotal(today);
  const goalSteps = profile?.goalSteps ?? 6000;
  const grade9 = gradeTotals[9];
  const grade10 = gradeTotals[10];
  const widgetLang = s.lang === "en" ? "en" : "es";
  const [beat, setBeat] = useState(0);
  useEffect(() => {
    if (!isNative() || !nativeActive) return;
    const timer = setInterval(() => setBeat((b) => b + 1), 60_000);
    return () => clearInterval(timer);
  }, [nativeActive]);
  useEffect(() => {
    if (!isNative() || !nativeActive) return;
    const wait = setTimeout(() => {
      void pushNativeSnapshot({ total: todaySteps, goal: goalSteps, g9: grade9, g10: grade10, goalGrade: GRADE_GOAL, lang: widgetLang });
    }, 800);
    return () => clearTimeout(wait);
  }, [nativeActive, todaySteps, goalSteps, grade9, grade10, widgetLang, beat]);
  return <C.Provider value={{ s, ready, gradeConfirmed: s.gradeConfirmed, set, user, profile, today, addToday, myTotal, gradeTotals, ranking, syncStatus, sync, signOut, setGrade }}>{children}</C.Provider>;
}

/** Idioma elegido, o null si no hay StoreProvider (pantallas de error). */
export function useLang(): "es" | "en" | null {
  return useContext(C)?.s.lang ?? null;
}

export function useStore() {
  const c = useContext(C);
  if (!c) throw new Error("StoreProvider missing");
  return c;
}

/** Racha de días consecutivos con meta cumplida (contando hasta ayer, más hoy si ya se cumplió). */
export function streak(days: Record<string, Day>, goal: number) {
  let n = 0;
  const d = new Date();
  if (dayTotal(days[todayKey(d)]) >= goal) n++;
  d.setDate(d.getDate() - 1);
  while (dayTotal(days[todayKey(d)]) >= goal) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

export function bpVerdict(sys: number, dia: number, pulse: number) {
  const p = sys >= 140 || dia >= 90 || sys < 85 || dia < 50 ? 2 : sys >= 125 || dia >= 82 ? 1 : 0;
  const h = pulse > 120 || pulse < 45 ? 2 : pulse > 100 || pulse < 55 ? 1 : 0;
  const lbl = (i: number) => ["Normal", "Elevado", "Revisar con un médico"][i] ?? "Normal";
  return { pressure: lbl(p), pulse: lbl(h), overall: lbl(Math.max(p, h)), level: Math.max(p, h) };
}

export function sleepMinutes(bed: string, wake: string) {
  const [bh = 0, bm = 0] = bed.split(":").map(Number), [wh = 0, wm = 0] = wake.split(":").map(Number);
  let m = wh * 60 + wm - (bh * 60 + bm);
  if (m <= 0) m += 1440;
  return m;
}
export function sleepVerdict(min: number, feel: string) {
  const h = min / 60;
  if (h >= 8 && h <= 10 && feel !== "Poca energía") return { label: "Buen estado", text: "Dormiste lo recomendado para tu edad (8 a 10 horas)." };
  if (h >= 7) return { label: "Normal", text: "Estás cerca de las 8 a 10 horas que se recomiendan a tu edad." };
  return { label: "Poco descanso", text: "Dormiste menos de 7 horas. Intenta acostarte más temprano." };
}

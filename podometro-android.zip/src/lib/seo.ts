export const seo = (title: string, description: string) => () => ({
  meta: [
    { title: `${title} · Podómetro B.S` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} · Podómetro B.S` },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ],
});

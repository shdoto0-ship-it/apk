/**
 * Puente con la app de Android (Capacitor). En el navegador todo esto es inerte:
 * isNative() devuelve false y ninguna función toca el plugin.
 */
import { Capacitor, registerPlugin } from "@capacitor/core";

/** Dirección de la versión web publicada: los correos de confirmación apuntan allí. */
export const WEB_ORIGIN = "https://podometrobsshiro.lovable.app";

export const isNative = () => typeof window !== "undefined" && Capacitor.isNativePlatform();
export const appOrigin = () => (isNative() ? WEB_ORIGIN : window.location.origin);

export type SensorKind = "counter" | "detector" | "none";
export type NativeStatus = {
  available: boolean;
  sensor: SensorKind;
  activityGranted: boolean;
  notificationsGranted: boolean;
  running: boolean;
  batteryIgnored: boolean;
  today: number;
};
type Chunk = { seq: number; day: string; steps: number };
export type Snapshot = { total: number; goal: number; g9: number; g10: number; goalGrade: number; lang: "es" | "en" };

interface PodometroNativePlugin {
  status(): Promise<NativeStatus>;
  requestPerms(): Promise<Pick<NativeStatus, "activityGranted" | "notificationsGranted">>;
  start(): Promise<{ started: boolean }>;
  stop(): Promise<void>;
  peek(): Promise<{ chunks: Chunk[]; today: number }>;
  ack(options: { seq: number }): Promise<void>;
  setSnapshot(options: Snapshot): Promise<void>;
  openBatterySettings(): Promise<void>;
  pinWidget(options: { size: "small" | "medium" }): Promise<{ supported: boolean; requested: boolean }>;
}

const Native = registerPlugin<PodometroNativePlugin>("PodometroNative");

let sensorKind: SensorKind = "none";
/** El teléfono tiene sensor de pasos y la app nativa los cuenta sola (también con pantalla apagada). */
export const nativeStepsReady = () => isNative() && sensorKind !== "none";

export async function nativeStatus(): Promise<NativeStatus | null> {
  if (!isNative()) return null;
  try {
    const st = await Native.status();
    sensorKind = st.sensor;
    return st;
  } catch {
    return null;
  }
}

export async function requestNativePermissions() {
  if (!isNative()) return null;
  try { return await Native.requestPerms(); } catch { return null; }
}

/** Inicia el servicio de conteo si hay sensor y permiso de actividad física. */
export async function startNativeCounting(): Promise<boolean> {
  const st = await nativeStatus();
  if (!st || !st.available || !st.activityGranted) return false;
  try { return (await Native.start()).started; } catch { return false; }
}

/** Cierre de sesión: detiene el conteo y borra lo que usan los widgets. */
export async function stopNativeCounting() {
  if (!isNative()) return;
  try { await Native.stop(); } catch { /* sin plugin: nada que detener */ }
}

const APPLIED_KEY = "podometro-native-applied-seq";
let draining = false;

/**
 * Pasa a la app los pasos que el servicio contó mientras estaba cerrada o con la pantalla apagada.
 * Cada bloque tiene un número; se suma una sola vez aunque el proceso se cierre a mitad.
 */
export async function drainNativeSteps(apply: (day: string, steps: number) => void): Promise<number> {
  if (!isNative() || draining) return 0;
  draining = true;
  try {
    const { chunks } = await Native.peek();
    if (!chunks.length) return 0;
    const applied = Number(localStorage.getItem(APPLIED_KEY) ?? 0) || 0;
    let top = applied;
    let total = 0;
    let highest = 0;
    for (const chunk of chunks) {
      highest = Math.max(highest, chunk.seq);
      if (chunk.seq > applied && chunk.steps > 0) {
        apply(chunk.day, chunk.steps);
        total += chunk.steps;
        top = Math.max(top, chunk.seq);
      }
    }
    if (top > applied) localStorage.setItem(APPLIED_KEY, String(top));
    await Native.ack({ seq: highest });
    return total;
  } catch {
    return 0;
  } finally {
    draining = false;
  }
}

export async function pushNativeSnapshot(snapshot: Snapshot) {
  if (!isNative()) return;
  try { await Native.setSnapshot(snapshot); } catch { /* el widget se actualiza en la próxima */ }
}

export async function openBatterySettings() {
  if (!isNative()) return;
  try { await Native.openBatterySettings(); } catch { /* ajuste no disponible */ }
}

export async function pinNativeWidget(size: "small" | "medium") {
  if (!isNative()) return { supported: false, requested: false };
  try { return await Native.pinWidget({ size }); } catch { return { supported: false, requested: false }; }
}

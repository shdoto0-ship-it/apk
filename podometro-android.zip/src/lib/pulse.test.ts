import { describe, expect, it } from "vitest";
import { estimatePulse, PULSE_DURATION_MS, type PulseSample } from "./pulse";

const recording = (bpm = 72, seconds = 30): PulseSample[] => Array.from({ length: seconds * 30 + 1 }, (_, i) => ({
  at: i * 1000 / 30, red: 170 + 2 * Math.sin(2 * Math.PI * bpm / 60 * i / 30), green: 65, blue: 40,
}));

describe("Camera pulse estimation", () => {
  it("requires the requested 30 seconds", () => {
    expect(PULSE_DURATION_MS).toBe(30_000);
    expect(estimatePulse(recording(72, 29))).toBeNull();
  });
  it.each([48, 72, 96, 144, 180])("estimates a consistent %i bpm signal", (bpm) => {
    expect(estimatePulse(recording(bpm))?.bpm).toBeCloseTo(bpm, 0);
  });
  it("does not invent a pulse from a static image", () => {
    expect(estimatePulse(recording().map((s) => ({ ...s, red: 170 })))).toBeNull();
  });
  it("rejects uncovered cameras", () => {
    expect(estimatePulse(recording().map((s) => ({ ...s, green: 180 })))).toBeNull();
  });
  it("rejects saturated images", () => {
    expect(estimatePulse(recording().map((s) => ({ ...s, red: 255 })))).toBeNull();
  });
  it("rejects interrupted frame delivery", () => {
    expect(estimatePulse(recording().filter((s) => s.at < 10000 || s.at > 11000))).toBeNull();
  });
  it("rejects an inconsistent rhythm between recording halves", () => {
    const a = recording(72), b = recording(120);
    expect(estimatePulse(a.map((s, i) => i < 450 ? s : (b[i] ?? s)))).toBeNull();
  });
});
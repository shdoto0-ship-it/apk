import { describe, it, expect, vi } from "vitest";
import { emptyPending, mergePendingActivity, readCloudAccount, readCompetition } from "./cloud-data";
const rpc = vi.hoisted(() => vi.fn());
const from = vi.hoisted(() => vi.fn());
vi.mock("@/integrations/supabase/client", () => ({ supabase: { rpc, from } }));

// Every Supabase query builder call returns the same awaitable object, so one mock
// covers .select().eq().single(), .range() and .in() without hand-writing each chain.
function queryChain(result: unknown): any {
  const chain: any = new Proxy(function () {}, {
    get: (_t, prop) => (prop === "then" ? (done: (v: unknown) => void) => done(result) : chain),
    apply: () => chain,
  });
  return chain;
}

const cloudProfile = { id: "u1", name: "ANA POO", grade: 9, birth: null, profile: null, settings: {}, bp: [], sleep: [], events: [], points: {} };

describe("Cloud activity persistence", () => {
  it("preserves 120 stored steps and applies 3 pending steps without replacing the stored day", () => {
    const result = mergePendingActivity({ "2026-10-23": { walk: 120, jumps: 0, bikeKm: 0, activeMin: 0, bonus: 0 } }, [{ id: "one", day: "2026-10-23", delta: { walk: 3 } }]);
    expect(result["2026-10-23"]?.walk).toBe(123);
  });
  it("shows only registered cloud participants and identifies the signed-in student", async () => {
    rpc.mockReturnValue({ range: () => Promise.resolve({ data: [{ id: "real", name: "Estudiante", grade: 9, steps: 120, streak: 1 }], error: null }) });
    expect(await readCompetition("real")).toEqual([{ id: "real", name: "Estudiante", grade: 9, steps: 120, streak: 1, me: true }]);
  });
  it("keeps Tops empty when the cloud has no registered participants", async () => {
    rpc.mockReturnValue({ range: () => Promise.resolve({ data: [], error: null }) });
    expect(await readCompetition("real")).toEqual([]);
  });
});

describe("Grade confirmation", () => {
  it("keeps an account unconfirmed while the cloud row says the grade was never chosen", async () => {
    from.mockImplementation((table: string) => queryChain(table === "profiles" ? { data: { ...cloudProfile, grade_confirmed: false }, error: null } : { data: [], error: null }));
    const account = await readCloudAccount("u1", "ana@colegio.edu.co", emptyPending());
    expect(account.gradeConfirmed).toBe(false);
  });
  it("counts the grade as confirmed once the cloud row says the student picked it", async () => {
    from.mockImplementation((table: string) => queryChain(table === "profiles" ? { data: { ...cloudProfile, grade: 10, grade_confirmed: true }, error: null } : { data: [], error: null }));
    const account = await readCloudAccount("u1", "ana@colegio.edu.co", emptyPending());
    expect(account.gradeConfirmed).toBe(true);
    expect(account.users?.[0]).toEqual({ email: "ana@colegio.edu.co", name: "ANA POO", birth: "", grade: 10 });
  });
  it("treats a grade chosen offline as confirmed before it reaches the cloud", async () => {
    from.mockImplementation((table: string) => queryChain(table === "profiles" ? { data: { ...cloudProfile, grade_confirmed: false }, error: null } : { data: [], error: null }));
    const account = await readCloudAccount("u1", "ana@colegio.edu.co", { operations: [], profile: { grade: 10, grade_confirmed: true } });
    expect(account.gradeConfirmed).toBe(true);
    expect(account.users?.[0]?.grade).toBe(10);
  });
});

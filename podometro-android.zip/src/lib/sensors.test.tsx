import { act, renderHook } from "@testing-library/react";
import { beforeEach, afterEach, expect, it, vi } from "vitest";
import { useStepCounter } from "./sensors";

const { addToday } = vi.hoisted(() => ({ addToday: vi.fn() }));
vi.mock("./store", () => ({ useStore: () => ({ user: { email: "sensor@test.invalid" }, profile: {}, addToday, s: { jumpSens: 60 } }) }));
function peak(magnitude: number) {
  const e = new Event("devicemotion");
  Object.defineProperty(e, "accelerationIncludingGravity", { value: { x: magnitude, y: 0, z: 0 } });
  act(() => window.dispatchEvent(e));
}
beforeEach(() => { vi.useFakeTimers(); vi.setSystemTime(10000); vi.stubGlobal("DeviceMotionEvent", class {}); addToday.mockClear(); });
afterEach(() => { vi.useRealTimers(); vi.unstubAllGlobals(); });
it("counts zero steps before Empezar", () => {
  const { unmount } = renderHook(() => useStepCounter(null));
  peak(30); expect(addToday).not.toHaveBeenCalled(); unmount();
});
it("counts one walking step only while active and zero while paused or stopped", () => {
  const { rerender, unmount } = renderHook(({ mode }: { mode: "walk" | null }) => useStepCounter(mode), { initialProps: { mode: "walk" as "walk" | null } });
  peak(15); expect(addToday).toHaveBeenCalledExactlyOnceWith({ walk: 1 });
  rerender({ mode: null }); peak(9); peak(30);
  expect(addToday).toHaveBeenCalledTimes(1);
  rerender({ mode: "walk" }); vi.advanceTimersByTime(400); peak(15);
  expect(addToday).toHaveBeenCalledTimes(2);
  unmount(); vi.advanceTimersByTime(400); peak(9); peak(30);
  expect(addToday).toHaveBeenCalledTimes(2);
});
it("counts one jump and no walking steps during a jump session", () => {
  const { unmount } = renderHook(() => useStepCounter("jump"));
  peak(30); expect(addToday).toHaveBeenCalledExactlyOnceWith({ jumps: 1 }); unmount();
});
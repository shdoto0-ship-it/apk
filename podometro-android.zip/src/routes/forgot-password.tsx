import { createFileRoute } from "@tanstack/react-router";
import { BackHeader, Screen } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { useI18n } from "@/lib/i18n";
export const Route = createFileRoute("/forgot-password")({ head: seo("Recuperar contraseña", "Cómo recuperar tu cuenta de Podómetro B.S."), component: Forgot });
function Forgot() {
  const { t } = useI18n();
  return (
    <Screen>
      <BackHeader title={t("¿Olvidaste tu contraseña?")} to="/login" />
      <div className="space-y-3 rounded-2xl border border-border bg-card p-5 text-card-foreground">
        <p className="font-semibold">{t("Contacta al dueño del proyecto.")}</p>
        <p className="text-muted-foreground">{t("Dile tu nombre completo y el correo con el que te registraste. Él te asignará una contraseña nueva para que vuelvas a entrar.")}</p>
      </div>
    </Screen>
  );
}

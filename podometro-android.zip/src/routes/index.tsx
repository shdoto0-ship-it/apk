import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check, WifiOff } from "lucide-react";
import { useEffect } from "react";
import { Btn, Logo, Screen } from "@/components/app/ui";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Podómetro B.S · Noveno contra Décimo" },
      { name: "description", content: "Cuenta tus pasos y ayuda a tu grado a llegar primero a 10 millones." },
      { property: "og:title", content: "Podómetro B.S · Noveno contra Décimo" },
      { property: "og:description", content: "Cuenta tus pasos y ayuda a tu grado a llegar primero a 10 millones." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Welcome,
});

function Welcome() {
  const { s, ready, set, user, profile, gradeConfirmed } = useStore();
  const navigate = useNavigate();
  const { t } = useI18n();
  useEffect(() => {
    if (!ready) return;
    if (user) navigate({ to: profile && gradeConfirmed ? "/inicio" : "/perfil", replace: true });
  }, [ready, s.lang, user, profile, gradeConfirmed, navigate]);

  const choose = (lang: "es" | "en") => set(() => ({ lang }));
  const next = () => navigate({ to: s.permsDone ? "/login" : "/permisos" });

  return (
    <Screen className="items-center text-center">
      <div className="mt-14 animate-pop">
        <Logo size={150} className="glow-primary" />
      </div>
      <h1 className="mt-8 text-4xl font-extrabold">Podómetro B.S</h1>
      <p className="mt-3 text-muted-foreground">{t("Noveno contra Décimo.")}<br />{t("El primero en llegar a 10 millones de pasos gana.")}</p>
      <div className="mt-auto w-full pt-10">
        <p className="mb-3 text-sm text-muted-foreground">Elige tu idioma · Choose your language</p>
        {([["es", "Español"], ["en", "English"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => choose(k)}
            className={cn("mb-3 flex h-16 w-full items-center gap-4 rounded-2xl border px-4 text-left text-lg font-semibold",
              s.lang === k ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card")}>
            <span className="grid size-9 place-items-center rounded-full bg-background/20 text-xs">{k.toUpperCase()}</span>
            <span className="flex-1">{l}</span>
            {s.lang === k && <Check className="size-5" />}
          </button>
        ))}
        <Btn className="mt-2" disabled={!s.lang} onClick={next}>{t("Continuar")}</Btn>
        <p className="mt-5 flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <WifiOff className="size-4 text-warning" /> {t("Funciona con y sin internet")}
        </p>
      </div>
    </Screen>
  );
}

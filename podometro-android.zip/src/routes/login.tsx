import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, WifiOff } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, Field, inputCls, Logo, Screen } from "@/components/app/ui";
import { useStore } from "@/lib/store";
import { useOnline } from "@/lib/useOnline";
import { useI18n } from "@/lib/i18n";
import { isNative } from "@/lib/native";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Entrar · Podómetro B.S" }, { name: "description", content: "Entra a tu cuenta del Colegio Baltazar Salazar." }, { property: "og:title", content: "Entrar · Podómetro B.S" }, { property: "og:description", content: "Entra a tu cuenta del Colegio Baltazar Salazar." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Login,
});

function Login() {
  const { user, profile, ready, gradeConfirmed } = useStore();
  const navigate = useNavigate();
  const online = useOnline();
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lovableBusy, setLovableBusy] = useState(false);
  useEffect(() => { if (ready && user) navigate({ to: profile && gradeConfirmed ? "/inicio" : "/perfil", replace: true }); }, [ready, user, profile, gradeConfirmed, navigate]);

  const withLovable = async () => {
    setLovableBusy(true);
    const result = await lovable.auth.signInWithOAuth("lovable", { redirect_uri: window.location.origin });
    setLovableBusy(false);
    if (result.error) toast.error(t("No se pudo entrar con Lovable. Inténtalo de nuevo."));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password: pw });
    setBusy(false);
    if (error) return toast.error(t("No se pudo entrar. Revisa el correo, la contraseña y la confirmación de tu cuenta."));
    return undefined;
  };

  return (
    <Screen>
      <BackHeader title="" to="/permisos" right={
        <span className="flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs">
          <span className={`size-2 rounded-full ${online ? "bg-success" : "bg-warning"}`} />{online ? t("En línea") : t("Sin internet")}
        </span>} />
      <div className="flex items-center gap-3">
        <Logo size={52} />
        <div className="text-sm"><p className="text-muted-foreground">Podómetro B.S</p><p className="font-semibold">{t("Colegio Baltazar Salazar")}</p></div>
      </div>
      <h1 className="mt-8 text-3xl font-bold">{t("Entra a tu cuenta")}</h1>
      <p className="mb-6 mt-1 text-sm text-muted-foreground">{t("Tus pasos suman al total de tu grado.")}</p>
      <form onSubmit={submit}>
        <Field label={t("Correo electrónico")}><input className={inputCls} type="email" required placeholder={t("tucorreo@ejemplo.com")} value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <Field label={t("Contraseña")}>
          <div className="relative">
            <input className={inputCls} type={show ? "text" : "password"} required placeholder={t("Tu contraseña")} value={pw} onChange={(e) => setPw(e.target.value)} />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-4 top-4 text-muted-foreground" aria-label={t("Ver contraseña")}>
              {show ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
            </button>
          </div>
        </Field>
        <Link to="/forgot-password" className="mb-4 block w-full text-right text-sm text-primary">{t("¿Olvidaste tu contraseña?")}</Link>
        <Btn type="submit" disabled={busy || !online}>{busy ? t("Entrando…") : t("Entrar")}</Btn>
      </form>
      {/* El inicio con Lovable abre una ventana del navegador: solo existe en la versión web. */}
      {!isNative() && (
        <>
          <div className="my-5 flex items-center gap-3 text-muted-foreground"><span className="h-px flex-1 bg-border" />{t("o")}<span className="h-px flex-1 bg-border" /></div>
          <button type="button" onClick={withLovable} disabled={lovableBusy || !online} className="lovable-auth-button lovable-auth-button--full-width">
            {lovableBusy ? t("Conectando con Lovable…") : t("Iniciar sesión con Lovable")}
          </button>
        </>
      )}
      <Link to="/registro" className="mt-3"><Btn variant="outline">{t("Crear cuenta nueva")}</Btn></Link>
      <div className="surface mt-auto flex gap-3 p-4 text-sm text-muted-foreground">
        <WifiOff className="size-5 shrink-0 text-warning" />
        <p><b className="text-foreground">{t("Tus datos quedan en la nube.")}</b> {isNative() ? t("Solo necesitas internet la primera vez que entras. Después la app abre y cuenta pasos sin conexión; todo se sube al volver la red.") : t("Necesitas internet para entrar. Si se corta durante una sesión abierta, los pasos quedan pendientes y se suben al volver la conexión.")}</p>
      </div>
    </Screen>
  );
}

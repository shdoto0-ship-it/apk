import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { BackHeader, Btn, Field, Screen, inputCls } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { useI18n } from "@/lib/i18n";
export const Route = createFileRoute("/reset-password")({ head: seo("Nueva contraseña", "Cambia la contraseña de tu cuenta de Podómetro B.S."), component: Reset });
function Reset() {
  const { t } = useI18n();
  const [valid, setValid] = useState(false);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    const recovery = new URLSearchParams(window.location.hash.slice(1)).get("type") === "recovery";
    const { data } = supabase.auth.onAuthStateChange((event) => { if (event === "PASSWORD_RECOVERY") setValid(true); });
    if (recovery) void supabase.auth.getUser().then(({ data }) => setValid(Boolean(data.user)));
    return () => data.subscription.unsubscribe();
  }, []);
  return <Screen><BackHeader title={t("Nueva contraseña")} to="/login" />{!valid ? <p className="text-muted-foreground">{t("Abre un enlace de recuperación válido desde tu correo.")}</p> : <form onSubmit={async (e) => { e.preventDefault(); setBusy(true); const { error } = await supabase.auth.updateUser({ password }); setBusy(false); if (error) toast.error(t("No se pudo cambiar la contraseña.")); else { toast.success(t("Contraseña actualizada")); navigate({ to: "/login" }); } }}><Field label={t("Nueva contraseña")}><input className={inputCls} type="password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} /></Field><Btn type="submit" disabled={busy}>{t("Guardar contraseña")}</Btn></form>}</Screen>;
}
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Bell, ChevronsUp, Footprints, MapPin } from "lucide-react";
import { useState } from "react";
import { BackHeader, Btn, Logo, Screen, Switch } from "@/components/app/ui";
import { requestLocation, requestMotion, requestNotifications } from "@/lib/sensors";
import { isNative, nativeStatus, requestNativePermissions } from "@/lib/native";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/permisos")({
  head: () => ({ meta: [{ title: "Permisos · Podómetro B.S" }, { name: "description", content: "Permite lo necesario para contar tus pasos." }, { property: "og:title", content: "Permisos · Podómetro B.S" }, { property: "og:description", content: "Permite lo necesario para contar tus pasos." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Permisos,
});

const items = [
  { k: "act", icon: Footprints, t: "Actividad física", d: "Contar tus pasos · obligatorio", tone: "bg-primary" },
  { k: "not", icon: Bell, t: "Notificaciones", d: "Aviso al cumplir la meta y recordar la racha", tone: "bg-warning" },
  { k: "loc", icon: MapPin, t: "Ubicación", d: "Mapa, puntos experimentales y bicicleta", tone: "bg-success" },
  { k: "mov", icon: ChevronsUp, t: "Sensores de movimiento", d: "Detectar tus saltos", tone: "bg-foreground" },
] as const;

function Permisos() {
  const { set } = useStore();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [on, setOn] = useState<Record<"act"|"not"|"loc"|"mov", boolean>>({ act: true, not: true, loc: true, mov: true });
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true);
    if (isNative()) {
      // Actividad física + notificaciones: Android las pide juntas (el conteo en segundo plano muestra un aviso fijo).
      await requestNativePermissions();
      await nativeStatus();
    } else {
      if (on.act || on.mov) await requestMotion();
      if (on.not) await requestNotifications();
    }
    if (on.loc) await requestLocation();
    set(() => ({ permsDone: true, notifications: on.not }));
    navigate({ to: "/login" });
  };

  return (
    <Screen>
      <BackHeader title="" to="/" right={<Logo size={40} />} />
      <h1 className="text-3xl font-bold leading-tight">{t("Permite lo necesario para contar tus pasos")}</h1>
      <p className="mt-2 text-sm text-muted-foreground">{t("Puedes cambiarlo después en Ajustes. Nada se comparte con otros: tus compañeros solo ven tu nombre y tus pasos.")}</p>
      <div className="surface mt-6 divide-y divide-border">
        {items.map((it) => (
          <div key={it.k} className="flex items-center gap-3 p-4">
            <span className={`grid size-10 place-items-center rounded-xl ${it.tone} text-background`}><it.icon className="size-5" /></span>
            <div className="flex-1">
              <p className="font-semibold">{t(it.t)}</p>
              <p className="text-xs text-muted-foreground">{t(it.d)}</p>
            </div>
            <Switch on={on[it.k]} label={t(it.t)} onChange={(v) => it.k !== "act" && setOn({ ...on, [it.k]: v })} />
          </div>
        ))}
      </div>
      <p className="mt-4 text-sm text-muted-foreground">{isNative() ? t("Con la pantalla apagada también cuenta. Android muestra una notificación fija mientras cuenta tus pasos.") : t("Pantalla apagada: no disponible en esta versión web. El navegador suspende los sensores.")}</p>
      <div className="mt-auto pt-8">
        <Btn onClick={go} disabled={busy}>{t("Permitir y continuar")}</Btn>
        <Btn variant="ghost" onClick={() => { set(() => ({ permsDone: true })); navigate({ to: "/login" }); }}>{t("Ahora no")}</Btn>
      </div>
    </Screen>
  );
}

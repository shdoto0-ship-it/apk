import { createFileRoute, redirect, Outlet } from "@tanstack/react-router";
import { getAuthUser } from "@/lib/offline-auth";
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    // Sin internet se usa la sesión guardada en el teléfono; así la app abre y cuenta pasos sin conexión.
    const user = await getAuthUser();
    if (!user) throw redirect({ to: "/auth" });
  },
  component: Outlet,
});

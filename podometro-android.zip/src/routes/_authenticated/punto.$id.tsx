import { createFileRoute, notFound } from "@tanstack/react-router";
import { ArrowRight, MapPin } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, Screen } from "@/components/app/ui";
import { anchor, POINT_BONUS, pointLatLng, POINTS } from "@/lib/game";
import { haversineKm } from "@/lib/sensors";
import { todayKey, useStore } from "@/lib/store";
import { usePosition } from "./mapa";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/punto/$id")({
  loader: ({ params }) => {
    const p = POINTS.find((x) => x.id === params.id);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Punto"} · Podómetro B.S` },
      { name: "description", content: loaderData?.title ?? "Punto experimental del mapa." },
      { property: "og:title", content: `${loaderData?.name ?? "Punto"} · Podómetro B.S` },
      { property: "og:description", content: loaderData?.title ?? "Punto experimental del mapa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Punto,
});

function Punto() {
  const p = Route.useLoaderData();
  const { s, set, user, addToday } = useStore();
  const { pos } = usePosition();
  const { t, miles, shortDist } = useI18n();
  const [before, setBefore] = useState("");
  const [after, setAfter] = useState("");
  if (!user) return <Screen guard>{null}</Screen>;
  const a = anchor();
  const dist = pos && a ? haversineKm(pos, pointLatLng(p, a)) * 1000 : null;
  const near = dist != null && Math.round(dist) <= 50;
  const doneToday = s.points[user.email]?.[p.id] === todayKey();
  const visitors = (s.users.length + Number(p.id) * 3) % 17;

  const complete = () => {
    addToday({ bonus: POINT_BONUS });
    set((st) => ({ points: { ...st.points, [user.email]: { ...(st.points[user.email] ?? {}), [p.id]: todayKey() } } }));
    toast.success(t("+{n} pasos para tu grado", { n: POINT_BONUS }));
  };

  return (
    <Screen>
      <BackHeader title={t(p.name)} kicker={t("Punto experimental {n}", { n: p.id })} to="/mapa" />
      <div className="surface flex items-center gap-4 p-4">
        <span className="grid size-14 place-items-center rounded-full border-2 border-warning text-warning"><MapPin /></span>
        <div className="flex-1"><p className="text-xs text-muted-foreground">{t("Estás a")}</p><p className="text-3xl font-bold">{dist != null ? shortDist(dist) : `— ${miles ? "ft" : "m"}`}</p></div>
        <p className="text-right text-xs text-muted-foreground">{t("Para activarlo")}<br /><b className="text-foreground">{t("llega a {d}", { d: shortDist(50) })}</b></p>
      </div>
      <div className="surface mt-4 p-4">
        <h2 className="mb-4 font-semibold">{t(p.title)}</h2>
        <ol className="space-y-4">
          {p.steps.map(([title, d], i) => (
            <li key={i} className="flex gap-3">
              <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{i + 1}</span>
              <div><b>{t(title)}</b><p className="text-sm text-muted-foreground">{t(d)}</p></div>
            </li>
          ))}
        </ol>
      </div>
      {p.measure && (
        <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          {[[t("En reposo"), before, setBefore], [t("Después"), after, setAfter]].map(([l, v, fn], i) => (
            <>
              {i === 1 && <ArrowRight key="arr" className="size-5 text-muted-foreground" />}
              <label key={l as string} className="surface p-3 text-center">
                <span className="text-xs text-muted-foreground">{l as string}</span>
                <input inputMode="numeric" value={v as string} onChange={(e) => (fn as (x: string) => void)(e.target.value.replace(/\D/g, "").slice(0, 3))} placeholder="--" className="w-full bg-transparent text-center text-2xl font-bold outline-none" />
                <span className="text-xs text-muted-foreground">{t("lpm")}</span>
              </label>
            </>
          ))}
        </div>
      )}
      {p.measure && before && after && <p className="mt-2 text-center text-sm">{t("Tu pulso subió")} <b className="text-primary">{+after - +before} {t("lpm")}</b>.</p>}
      <div className="mt-4 flex items-center gap-4 rounded-2xl border border-warning p-4">
        <span className="text-3xl font-bold text-warning">+{POINT_BONUS}</span>
        <p className="text-sm text-muted-foreground">{t("pasos extra para tu grado al terminar. Una vez por día en cada punto.")}</p>
      </div>
      <p className="mt-3 flex justify-between text-xs text-muted-foreground"><span>{t("Hoy en este punto")}</span><span><span className="text-foreground">● 9°·{visitors}</span> &nbsp;<span className="text-primary">● 10°·{(visitors + 5) % 13}</span></span></p>
      <div className="mt-auto pt-6">
        {doneToday ? <Btn disabled>{t("Hecho hoy ✓")}</Btn>
          : near ? <Btn onClick={complete}>{t("Terminar experimento")}</Btn>
          : <Btn disabled>{t("Acércate para empezar")}</Btn>}
      </div>
    </Screen>
  );
}

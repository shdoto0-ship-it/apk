import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Crown } from "lucide-react";
import { useEffect } from "react";
import { Btn, GradeDot, LOGO, Screen } from "@/components/app/ui";
import { myRank } from "@/lib/game";
import { seo } from "@/lib/seo";
import { fmt, GRADE_GOAL, useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/celebracion")({ head: seo("¡Meta cumplida!", "Un grado llegó primero a 10 millones de pasos."), component: Celebracion });

const COLORS = ["bg-primary", "bg-warning", "bg-foreground", "bg-success"];

function Celebracion() {
  const { s, set, myTotal, gradeTotals } = useStore();
  const navigate = useNavigate();
  const { t, grade } = useI18n();
  const real = gradeTotals[9] >= GRADE_GOAL || gradeTotals[10] >= GRADE_GOAL;
  useEffect(() => { if (real && !s.celebrated) set(() => ({ celebrated: true })); }, [real, s.celebrated, set]);
  const winner: 9 | 10 = gradeTotals[9] >= gradeTotals[10] ? 9 : 10;
  const loser: 9 | 10 = winner === 9 ? 10 : 9;
  const shown = real ? gradeTotals[winner] : GRADE_GOAL;

  return (
    <Screen className="relative items-center overflow-hidden text-center">
      {Array.from({ length: 28 }).map((_, i) => (
        <span key={i} className={`animate-confetti absolute top-0 h-3 w-1.5 rounded-sm ${COLORS[i % 4]}`}
          style={{ left: `${(i * 37) % 100}%`, animationDuration: `${3 + (i % 5)}s`, animationDelay: `${(i % 7) * 0.4}s` }} />
      ))}
      <div className="animate-pop animate-pulse-ring mt-10 rounded-full border-8 border-primary p-1">
        <img src={LOGO} alt="Podómetro B.S" className="size-44 rounded-full object-cover" />
      </div>
      <span className="mt-6 rounded-full bg-warning px-4 py-1.5 text-sm font-bold text-background">{t("META CUMPLIDA")}</span>
      <p className="animate-pop mt-3 text-5xl font-extrabold">{fmt(shown)}</p>
      <p className="mt-1 text-lg">¡<b className="text-primary">{winner}° {grade(winner)}</b> {t("llegó primero!")}</p>
      {!real && <p className="text-xs text-muted-foreground">{t("(Vista previa: aún ningún grado ha llegado)")}</p>}
      <div className="surface mt-6 w-full divide-y divide-border text-left">
        <div className="flex items-center gap-3 p-4"><GradeDot g={winner} /><b className="flex-1">{grade(winner)}</b><b>{fmt(shown)}</b><Crown className="size-5 text-warning" /></div>
        <div className="flex items-center gap-3 p-4"><GradeDot g={loser} /><b className="flex-1">{grade(loser)}</b><b className="mr-7">{fmt(gradeTotals[loser])}</b></div>
      </div>
      <div className="surface mt-3 flex w-full items-center justify-between p-4 text-left"><span className="text-sm text-muted-foreground">{t("Tu aporte")}<br />{t("al total")}</span><span className="text-right"><b className="text-2xl">{fmt(myTotal)}</b> {t("pasos")}<br /><span className="text-xs text-muted-foreground">{t("Puesto")} {myRank(s) || "—"} {t("en el ranking")}</span></span></div>
      <div className="mt-auto w-full pt-8">
        <Btn onClick={() => navigate({ to: "/ranking" })}>{t("Ver el ranking final")}</Btn>
        <Btn variant="ghost" onClick={() => navigate({ to: "/inicio" })}>{t("Volver al inicio")}</Btn>
      </div>
    </Screen>
  );
}

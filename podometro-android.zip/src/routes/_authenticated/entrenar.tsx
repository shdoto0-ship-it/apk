import { createFileRoute } from "@tanstack/react-router";
import { AlertCircle, Bike, ChevronsUp, Footprints, Pause, Play, Square } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Btn, Screen } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { haversineKm, requestMotion, useStepCounter } from "@/lib/sensors";
import { isNative, nativeStepsReady } from "@/lib/native";
import { dayTotal, fmt, kmFor, STEPS_PER_BIKE_KM, STEPS_PER_JUMP, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/entrenar")({ head: seo("Entrenar", "Camina, salta o anda en bici: todo suma pasos a tu grado."), component: Entrenar });

type M = "walk" | "jump" | "bike";

function Entrenar() {
  const { profile, today, addToday } = useStore();
  const { t, dist: showDist, distNum, distUnit, speedUnit, stepsPerUnit } = useI18n();
  const [mode, setMode] = useState<M>("walk");
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [secs, setSecs] = useState(0);
  const [km, setKm] = useState(0);
  const [path, setPath] = useState<{ lat: number; lng: number }[]>([]);
  const [starting, setStarting] = useState(false);
  const [hasSession, setHasSession] = useState(false);
  const mounted = useRef(false);
  const startDay = useRef({ walk: 0, jumps: 0 });
  useStepCounter(running && !paused && mode !== "bike" ? mode : null);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  useEffect(() => {
    if (!running || paused) return;
    const timer = setInterval(() => setSecs((x) => x + 1), 1000);
    return () => clearInterval(timer);
  }, [running, paused]);
  useEffect(() => {
    if (!running) return;
    // En la app de Android caminar sigue contando con la pantalla apagada; saltos y bici necesitan la pantalla encendida.
    if (mode === "walk" && nativeStepsReady()) return;
    const onHidden = () => {
      if (document.visibilityState === "hidden") {
        setPaused(true);
        toast.warning(isNative() ? t("Sesión pausada: saltos y bici necesitan la pantalla encendida.") : t("Sesión pausada: el navegador no cuenta con la pantalla apagada."));
      }
    };
    document.addEventListener("visibilitychange", onHidden);
    return () => document.removeEventListener("visibilitychange", onHidden);
  }, [running, mode, t]);
  useEffect(() => {
    if (!running || paused || mode !== "bike" || !navigator.geolocation) return;
    let active = true;
    let previous: { lat: number; lng: number } | null = null;
    const id = navigator.geolocation.watchPosition((pos) => {
      if (!active || document.visibilityState === "hidden") return;
      const p = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      if (previous) {
        const d = haversineKm(previous, p);
        if (d <= 0.005) return;
        if (d < 0.5) { setKm((k) => k + d); addToday({ bikeKm: d }); }
      }
      previous = p;
      setPath((prev) => [...prev.slice(-200), p]);
    }, () => { setPaused(true); toast.error(t("Activa la ubicación para medir la bici")); }, { enableHighAccuracy: true });
    return () => { active = false; navigator.geolocation.clearWatch(id); };
  }, [running, paused, mode, addToday, t]);

  if (!profile) return <Screen guard nav>{null}</Screen>;

  const begin = async () => {
    if (starting || running) return;
    if (mode === "bike" && !navigator.geolocation) { toast.error(t("Tu teléfono no tiene ubicación")); return; }
    setStarting(true);
    const allowed = mode === "bike" || (mode === "walk" && nativeStepsReady()) || await requestMotion();
    if (!mounted.current) return;
    setStarting(false);
    if (!allowed) { toast.error(t("Permite el movimiento para contar; este dispositivo debe tener sensores.")); return; }
    startDay.current = { walk: today.walk, jumps: today.jumps };
    setSecs(0); setKm(0); setPath([]); setHasSession(true); setRunning(true); setPaused(false);
  };
  const finish = () => {
    setRunning(false);
    addToday({ activeMin: Math.round(secs / 60) });
    toast.success(t("¡Bien! Sumaste {n} pasos a tu grado", { n: fmt(gained) }));
  };

  const sessionWalk = hasSession ? Math.max(0, today.walk - startDay.current.walk) : 0;
  const sessionJumps = hasSession ? Math.max(0, today.jumps - startDay.current.jumps) : 0;
  const gained = hasSession ? (mode === "walk" ? sessionWalk : mode === "jump" ? sessionJumps * STEPS_PER_JUMP : Math.round(km * STEPS_PER_BIKE_KM)) : 0;
  const dist = mode === "bike" ? km : kmFor(sessionWalk, profile.height);
  const speed = secs ? (dist / (secs / 3600)) : 0;
  const mm = String(Math.floor(secs / 60)).padStart(2, "0"), ss = String(secs % 60).padStart(2, "0");

  // trazo dibujado: normaliza el recorrido real al recuadro
  const pts = (() => {
    if (path.length < 2) return "M20,140 C80,120 120,100 170,115 S260,150 300,90";
    const lats = path.map((p) => p.lat), lngs = path.map((p) => p.lng);
    const [a, b, c, d] = [Math.min(...lats), Math.max(...lats), Math.min(...lngs), Math.max(...lngs)];
    return path.map((p, i) => `${i ? "L" : "M"}${20 + ((p.lng - c) / (d - c || 1)) * 280},${180 - ((p.lat - a) / (b - a || 1)) * 160}`).join(" ");
  })();

  const modes: { k: M; l: string; i: typeof Footprints; off?: boolean }[] = [
    { k: "walk", l: "Caminar", i: Footprints }, { k: "jump", l: "Saltar", i: ChevronsUp }, { k: "bike", l: "Bici", i: Bike },
  ];

  return (
    <Screen guard nav>
      <div className="mb-4 flex items-end justify-between">
        <div><p className="text-xs text-muted-foreground">{t("Opcional · todo suma a tu meta")}</p><h1 className="text-2xl font-bold">{t("Entrenar")}</h1></div>
        {running && <span className="flex items-center gap-1.5 rounded-full border border-success px-3 py-1 text-xs text-success"><span className="size-2 rounded-full bg-success" />{paused ? t("En pausa") : t("En curso")}</span>}
      </div>
      <div className="mb-4 grid grid-cols-3 gap-3">
        {modes.map((m) => (
          <button key={m.k} disabled={running || starting} onClick={() => { setMode(m.k); setHasSession(false); setSecs(0); setKm(0); setPath([]); }}
            className={cn("flex flex-col items-center gap-1 rounded-2xl border py-3 text-sm", mode === m.k ? (m.k === "bike" ? "border-success text-foreground" : "border-primary text-foreground") : "border-border bg-card text-muted-foreground", "disabled:opacity-60")}>
            <m.i className="size-6" />{t(m.l)}
          </button>
        ))}
      </div>
      <div className="surface overflow-hidden">
        <svg viewBox="0 0 320 200" className="h-44 w-full bg-muted/40">
          <path d="M0,60 L320,30 M60,0 L110,200 M200,0 L250,200 M0,170 L320,150" stroke="var(--border)" strokeWidth="10" fill="none" />
          <path d={pts} stroke="var(--primary)" strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="20" cy="140" r="6" fill="var(--foreground)" />
        </svg>
        <div className="p-4">
          <div className="flex items-end justify-between"><span className="text-sm text-muted-foreground">{t("Tiempo")}</span><span className="text-5xl font-bold tabular-nums">{mm}:{ss}</span></div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-muted py-2"><p className="text-lg font-bold">{mode === "jump" ? sessionJumps : showDist(dist)}</p><p className="text-[11px] text-muted-foreground">{mode === "jump" ? t("saltos") : distUnit}</p></div>
            <div className="rounded-xl bg-muted py-2"><p className="text-lg font-bold">{mode === "jump" ? (secs ? Math.round(sessionJumps / (secs / 60)) : 0) : distNum(speed).toFixed(1)}</p><p className="text-[11px] text-muted-foreground">{mode === "jump" ? t("por min") : speedUnit}</p></div>
            <div className="rounded-xl bg-muted py-2"><p className="text-lg font-bold text-warning">+{fmt(gained)}</p><p className="text-[11px] text-muted-foreground">{t("pasos")}</p></div>
          </div>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {!running ? (
          <Btn className="col-span-2" disabled={starting} onClick={begin}><Play className="size-5" fill="currentColor" />{starting ? t("Esperando permiso…") : t("Empezar")}</Btn>
        ) : (
          <>
            <Btn variant="outline" onClick={() => setPaused(!paused)}>{paused ? <><Play className="size-5" />{t("Seguir")}</> : <><Pause className="size-5" />{t("Pausar")}</>}</Btn>
            <Btn onClick={finish}><Square className="size-4" fill="currentColor" />{t("Terminar")}</Btn>
          </>
        )}
      </div>
      <p className="mt-4 flex gap-2 text-xs text-muted-foreground"><AlertCircle className="size-4 shrink-0 text-warning" />{nativeStepsReady()
        ? t("Caminar se cuenta solo, incluso con la pantalla apagada o la app cerrada. Para saltos y bici mantén la pantalla encendida. Bici: {n} pasos por {u}. Saltos: 2 pasos por salto.", { n: stepsPerUnit(STEPS_PER_BIKE_KM), u: t(distUnit === "km" ? "kilómetro" : "milla") })
        : t("El conteo requiere una sesión activa y la pantalla encendida. Al apagarla o salir de la app, la sesión se pausa. Bici: {n} pasos por {u}. Saltos: 2 pasos por salto.", { n: stepsPerUnit(STEPS_PER_BIKE_KM), u: t(distUnit === "km" ? "kilómetro" : "milla") })}</p>
      <p className="mt-2 text-center text-xs text-muted-foreground">{t("Hoy llevas {n} pasos", { n: fmt(dayTotal(today)) })}</p>
    </Screen>
  );
}

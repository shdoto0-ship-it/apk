import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Home } from "lucide-react";
import { useState } from "react";
import { BackHeader, Screen } from "@/components/app/ui";
import { lastNDays, myDays } from "@/lib/game";
import { seo } from "@/lib/seo";
import { dayTotal, fmt, kcalFor, kmFor, STEPS_PER_BIKE_KM, STEPS_PER_JUMP, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/analisis")({ head: seo("Análisis", "Tu actividad por día, semana y mes, todo en pasos."), component: Analisis });

function Analisis() {
  const { s, profile } = useStore();
  const { t, lang, locale, dist, distUnit, dow } = useI18n();
  const [range, setRange] = useState<"Día" | "Semana" | "Mes">("Semana");
  if (!profile) return <Screen guard nav>{null}</Screen>;
  const n = range === "Día" ? 1 : range === "Semana" ? 7 : 30;
  const list = lastNDays(myDays(s), n);
  const goal = profile.goalSteps;
  const total = list.reduce((a, d) => a + d.total, 0);
  const max = Math.max(goal * 1.2, ...list.map((d) => d.total));
  const done = list.filter((d) => d.total >= goal).length;
  const walk = list.reduce((a, d) => a + (d.day?.walk ?? 0) + (d.day?.bonus ?? 0), 0);
  const jumps = list.reduce((a, d) => a + (d.day?.jumps ?? 0) * STEPS_PER_JUMP, 0);
  const bike = list.reduce((a, d) => a + (d.day?.bikeKm ?? 0) * STEPS_PER_BIKE_KM, 0);
  const pct = (x: number) => (total ? Math.round((x / total) * 100) : 0);
  const mins = list.reduce((a, d) => a + (d.day?.activeMin ?? 0), 0);
  const times = list.map((d) => d.day?.goalAt).filter(Boolean) as string[];
  const avgTime = times.length ? (() => { const m = times.reduce((a, t) => a + +t.slice(0, 2) * 60 + +t.slice(3), 0) / times.length; return `${Math.floor(m / 60)}:${String(Math.round(m % 60)).padStart(2, "0")}`; })() : null;
  const first = list[0]!.date.toLocaleDateString(locale, lang === "en" ? { month: "long", day: "numeric" } : { day: "numeric" }), last = list[n - 1]!.date.toLocaleDateString(locale, { day: "numeric", month: "long" });

  return (
    <Screen guard nav>
      <BackHeader title={t("Análisis")} kicker={n > 1 ? t("{first} al {last}", { first, last }) : last} to="" right={<Link to="/inicio" className="grid size-10 place-items-center rounded-full bg-secondary" aria-label={t("Inicio")}><Home className="size-5" /></Link>} />
      <div className="mb-4 grid grid-cols-3 rounded-2xl bg-card p-1">
        {(["Día", "Semana", "Mes"] as const).map((r) => <button key={r} onClick={() => setRange(r)} className={cn("rounded-xl py-2.5 text-sm font-semibold", range === r ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>{t(r)}</button>)}
      </div>
      <div className="surface p-4">
        <div className="mb-4 flex justify-between text-sm"><b>{t("Pasos por día")}</b><span className="text-xs text-muted-foreground">{t("Meta {goal} · {done} de {n} cumplidas", { goal: fmt(goal), done, n })}</span></div>
        <div className="relative flex h-40 items-end gap-1">
          <div className="absolute inset-x-0 border-t border-dashed border-muted-foreground/50" style={{ bottom: `${(goal / max) * 100}%` }} />
          {list.map((d, i) => {
            const isToday = i === n - 1;
            return (
              <div key={d.key} className="flex h-full flex-1 flex-col justify-end" title={t("{n} pasos", { n: fmt(d.total) })}>
                <div className={cn("rounded-t-md", isToday ? "border-2 border-foreground/70 bg-muted" : "bg-primary")} style={{ height: `${Math.max(3, (d.total / max) * 100)}%` }} />
              </div>
            );
          })}
        </div>
        {n <= 7 && (
          <div className="mt-2 flex gap-1 text-center text-[10px] text-muted-foreground">
            {list.map((d, i) => <div key={d.key} className="flex-1"><b className="block text-foreground">{i === n - 1 ? t("Hoy") : dow[d.date.getDay()]}</b>{d.day?.goalAt ?? "--"}</div>)}
          </div>
        )}
        <p className="mt-3 flex gap-2 rounded-xl bg-muted p-3 text-xs text-muted-foreground"><Clock className="size-4 shrink-0 text-warning" />{t("La hora debajo de cada día es cuando llegaste a tu meta.")}{avgTime && <> {t("Sueles lograrla hacia las")} <b className="text-foreground">{avgTime}</b>.</>}</p>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[["Pasos totales", fmt(total), ""], ["Promedio diario", fmt(total / n), ""], ["Calorías", fmt(kcalFor(total, profile.weight)), "kcal"], ["Distancia", dist(kmFor(walk, profile.height)), distUnit], ["Tiempo activo", `${Math.floor(mins / 60)} h ${String(mins % 60).padStart(2, "0")}`, ""], ["Mejor día", fmt(Math.max(...list.map((d) => d.total))), ""]].map(([l, v, u]) => (
          <div key={l} className="surface p-3"><p className="text-[11px] text-muted-foreground">{t(String(l))}</p><p className="text-lg font-bold">{v} <span className="text-xs font-normal">{u}</span></p></div>
        ))}
      </div>
      <div className="surface mt-4 p-4">
        <div className="mb-3 flex justify-between text-sm"><b>{t("De dónde vienen tus pasos")}</b><span className="text-xs text-muted-foreground">{t(range)}</span></div>
        <div className="flex h-2.5 overflow-hidden rounded-full bg-muted">
          <div className="bg-primary" style={{ width: `${pct(walk)}%` }} /><div className="bg-warning" style={{ width: `${pct(jumps)}%` }} /><div className="bg-success" style={{ width: `${pct(bike)}%` }} />
        </div>
        <div className="mt-3 flex justify-between text-xs">
          <span><span className="mr-1 inline-block size-2 rounded-full bg-primary" />{t("Caminando")} {pct(walk)}%</span>
          <span><span className="mr-1 inline-block size-2 rounded-full bg-warning" />{t("Saltos")} {pct(jumps)}%</span>
          <span><span className="mr-1 inline-block size-2 rounded-full bg-success" />{t("Bici")} {pct(bike)}%</span>
        </div>
      </div>
      <p className="mt-3 text-center text-xs text-muted-foreground">{t("Total histórico: {n} pasos", { n: fmt(Object.values(myDays(s)).reduce((a, d) => a + dayTotal(d), 0)) })}</p>
    </Screen>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, Chip, Field, inputCls, Screen } from "@/components/app/ui";
import { CATEGORIES } from "@/lib/events";
import { seo } from "@/lib/seo";
import { todayKey, uid, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/eventos/nuevo")({ head: seo("Nuevo evento", "Registra algo que pasó y cómo te sentiste."), component: Nuevo });

function Nuevo() {
  const { set, user } = useStore();
  const { t } = useI18n();
  const navigate = useNavigate();
  const now = new Date();
  const [f, setF] = useState({ text: "", date: todayKey(now), time: now.toTimeString().slice(0, 5), category: "Ejercicios", feel: "Bien" as "Bien" | "Normal" | "Mal", details: "" });
  if (!user) return <Screen guard>{null}</Screen>;
  const save = () => {
    if (!f.text.trim()) return toast.error(t("Cuéntanos qué pasó"));
    const at = new Date(`${f.date}T${f.time}`).toISOString();
    set((s) => ({ events: { ...s.events, [user.email]: [{ id: uid(), at, text: f.text.trim(), category: f.category, feel: f.feel, details: f.details }, ...(s.events[user.email] ?? [])].sort((a, b) => b.at.localeCompare(a.at)) } }));
    toast.success(t("Evento guardado"));
    navigate({ to: "/eventos" });
    return undefined;
  };
  return (
    <Screen>
      <BackHeader title={t("Nuevo evento")} to="/eventos" />
      <Field label={t("¿Qué pasó?")}><input className={inputCls} placeholder={t("Ej: Corrí en el recreo y me dio sed")} value={f.text} onChange={(e) => setF({ ...f, text: e.target.value })} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={t("Fecha")}><input type="date" className={inputCls} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
        <Field label={t("Hora")}><input type="time" className={inputCls} value={f.time} onChange={(e) => setF({ ...f, time: e.target.value })} /></Field>
      </div>
      <p className="mb-2 text-sm text-muted-foreground">{t("Categoría")}</p>
      <div className="mb-4 flex flex-wrap gap-2">{CATEGORIES.map((c) => <Chip key={c} on={f.category === c} onClick={() => setF({ ...f, category: c })}>{t(c)}</Chip>)}</div>
      <p className="mb-2 text-sm text-muted-foreground">{t("¿Cómo te sentiste?")}</p>
      <div className="mb-4 grid grid-cols-3 gap-2">
        {(["Bien", "Normal", "Mal"] as const).map((x) => (
          <button key={x} onClick={() => setF({ ...f, feel: x })} className={cn("h-14 rounded-2xl border font-semibold", f.feel === x ? (x === "Mal" ? "border-warning bg-accent" : "border-success bg-accent") : "border-border bg-card text-muted-foreground")}>{t(x)}</button>
        ))}
      </div>
      <Field label={t("Detalles · opcional")}><textarea rows={3} className={cn(inputCls, "h-auto py-3")} placeholder={t("Cuéntalo con tus palabras")} value={f.details} onChange={(e) => setF({ ...f, details: e.target.value })} /></Field>
      <Btn className="mt-auto" onClick={save}>{t("Guardar evento")}</Btn>
    </Screen>
  );
}

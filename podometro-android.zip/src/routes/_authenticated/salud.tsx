import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Heart, Moon, Plus } from "lucide-react";
import { Badge, Screen } from "@/components/app/ui";
import { PulseCamera } from "@/components/app/pulse-camera";
import { EVENT_ICON } from "@/lib/events";
import { seo } from "@/lib/seo";
import { bpVerdict, sleepMinutes, sleepVerdict, useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/salud")({ head: seo("Salud", "Estima tu pulso con la cámara en 30 segundos y consulta tus registros de presión, sueño y eventos."), component: Salud });

function Salud() {
  const { s, user } = useStore();
  const { t, locale } = useI18n();
  if (!user) return <Screen guard nav>{null}</Screen>;
  const bp = (s.bp[user.email] ?? [])[0];
  const sl = (s.sleep[user.email] ?? [])[0];
  const ev = (s.events[user.email] ?? []).slice(0, 2);
  const v = bp && bpVerdict(bp.sys, bp.dia, bp.pulse);
  const mins = sl ? sleepMinutes(sl.bed, sl.wake) : 0;
  const sv = sl && sleepVerdict(mins, sl.feel);

  return (
    <Screen guard nav>
      <div className="mb-4 flex items-end justify-between">
        <div><p className="text-xs text-muted-foreground">{t("Opcional · solo lo ves tú")}</p><h1 className="text-2xl font-bold">{t("Salud")}</h1></div>
        <Link to="/eventos/nuevo" className="grid size-11 place-items-center rounded-full bg-primary text-primary-foreground glow-primary" aria-label={t("Nuevo evento")}><Plus /></Link>
      </div>
      <PulseCamera />
      <Link to="/presion" className="surface mt-4 block p-4">
        <div className="mb-3 flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Heart className="size-5" /></span><b className="flex-1">{t("Pulso y presión")}</b>{v ? <Badge tone={v.level ? "warning" : "success"}>{t(v.overall)}</Badge> : <ChevronRight className="size-4" />}</div>
        {bp ? (
          <>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-muted p-3"><p className="text-xs text-muted-foreground">{t("Pulso")}</p><p className="text-3xl font-bold">{bp.pulse} <span className="text-xs font-normal">{t("lpm")}</span></p></div>
              <div className="rounded-xl bg-muted p-3"><p className="text-xs text-muted-foreground">{t("Presión")}</p><p className="text-3xl font-bold">{bp.sys}/{bp.dia} <span className="text-xs font-normal">mmHg</span></p></div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{new Date(bp.at).toLocaleString(locale, { dateStyle: "short", timeStyle: "short" })} · {t(bp.state).toLowerCase()}</p>
          </>
        ) : <p className="text-sm text-muted-foreground">{t("Toca para registrar tu presión y pulso si conoces los datos.")}</p>}
      </Link>
      <Link to="/sueno" className="surface mt-4 block p-4">
        <div className="mb-3 flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-violet text-background"><Moon className="size-5" /></span><b className="flex-1">{t("Sueño")}</b>{sv ? <Badge tone={sv.label === "Poco descanso" ? "warning" : "success"}>{t(sv.label)}</Badge> : <ChevronRight className="size-4" />}</div>
        {sl ? (
          <p className="text-4xl font-bold">{Math.floor(mins / 60)} h {mins % 60} <span className="text-sm font-normal text-muted-foreground">· {sl.bed} {t("a")} {sl.wake}</span></p>
        ) : <p className="text-sm text-muted-foreground">{t("Toca para registrar a qué hora dormiste y despertaste.")}</p>}
      </Link>
      <div className="surface mt-4 p-4">
        <div className="mb-3 flex justify-between"><b>{t("Mis eventos")}</b><Link to="/eventos" className="text-sm text-primary">{t("Ver todos ›")}</Link></div>
        {ev.length ? ev.map((e) => {
          const I = EVENT_ICON[e.category] ?? Heart;
          return (
            <div key={e.id} className="mb-2 flex items-center gap-3 rounded-xl bg-muted p-3">
              <span className="grid size-9 place-items-center rounded-full bg-warning text-background"><I className="size-4" /></span>
              <div className="min-w-0"><p className="truncate font-semibold">{e.text}</p><p className="text-xs text-muted-foreground">{new Date(e.at).toLocaleString(locale, { dateStyle: "short", timeStyle: "short" })} · {t(e.category)}</p></div>
            </div>
          );
        }) : <p className="text-sm text-muted-foreground">{t("Aún no tienes eventos. Registra si te sentiste mal o algo que hiciste.")}</p>}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">{t("Estos resultados son una guía y no reemplazan la opinión de un médico.")}</p>
    </Screen>
  );
}

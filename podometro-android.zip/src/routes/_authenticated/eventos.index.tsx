import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { BackHeader, Badge, Btn, Chip, Screen } from "@/components/app/ui";
import { CATEGORIES, EVENT_ICON } from "@/lib/events";
import { seo } from "@/lib/seo";
import { todayKey, useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/eventos/")({ head: seo("Mis eventos", "Tu diario: cómo te sentiste, ejercicios, sueño y hábitos."), component: Eventos });

function Eventos() {
  const { s, set, user } = useStore();
  const [cat, setCat] = useState("Reciente");
  const { t, locale } = useI18n();
  if (!user) return <Screen guard>{null}</Screen>;
  const all = (s.events[user.email] ?? []).filter((e) => cat === "Reciente" || e.category === cat);
  const y = new Date(); y.setDate(y.getDate() - 1);
  const group = (at: string) => { const k = todayKey(new Date(at)); return k === todayKey() ? "Hoy" : k === todayKey(y) ? "Ayer" : "Antes"; };
  const groups = ["Hoy", "Ayer", "Antes"].map((g) => [g, all.filter((e) => group(e.at) === g)] as const).filter(([, l]) => l.length);
  const del = (id: string) => set((st) => ({ events: { ...st.events, [user.email]: (st.events[user.email] ?? []).filter((e) => e.id !== id) } }));

  return (
    <Screen>
      <BackHeader title={t("Mis eventos")} kicker={t("Tu diario")} to="/salud" right={<Link to="/eventos/nuevo" className="grid size-11 place-items-center rounded-full bg-primary text-primary-foreground" aria-label={t("Nuevo")}><Plus /></Link>} />
      <div className="-mx-5 mb-4 flex gap-2 overflow-x-auto px-5 pb-1">
        {["Reciente", ...CATEGORIES].map((c) => <Chip key={c} on={cat === c} onClick={() => setCat(c)} className="shrink-0 rounded-full py-2">{t(c)}</Chip>)}
      </div>
      {groups.length === 0 && <p className="py-10 text-center text-muted-foreground">{t("No hay eventos aquí todavía.")}</p>}
      {groups.map(([g, l]) => (
        <div key={g}>
          <p className="mb-2 text-sm text-muted-foreground">{t(g)}</p>
          {l.map((e) => {
            const I = EVENT_ICON[e.category] ?? Heart;
            return (
              <div key={e.id} className="surface mb-2.5 flex items-start gap-3 p-4">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-warning text-background"><I className="size-5" /></span>
                <div className="min-w-0 flex-1"><p className="font-semibold">{e.text}</p><p className="text-xs text-muted-foreground">{new Date(e.at).toLocaleTimeString(locale, { hour: "numeric", minute: "2-digit" })} · {t(e.category)}</p>{e.details && <p className="mt-1 text-sm text-muted-foreground">{e.details}</p>}</div>
                <div className="flex flex-col items-end gap-2">
                  <Badge tone={e.feel === "Mal" ? "warning" : "success"}>{e.feel === "Mal" ? t("Me sentí mal") : e.feel === "Bien" ? t("Buen estado") : t("Normal")}</Badge>
                  <button onClick={() => del(e.id)} aria-label={t("Borrar")} className="text-muted-foreground"><Trash2 className="size-4" /></button>
                </div>
              </div>
            );
          })}
        </div>
      ))}
      <Link to="/eventos/nuevo" className="mt-auto pt-6"><Btn><Plus className="size-5" />{t("Nuevo evento")}</Btn></Link>
    </Screen>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { BatteryFull, BatteryLow, BatteryMedium, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, inputCls, Screen } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { sleepMinutes, sleepVerdict, todayKey, uid, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/sueno")({ head: seo("Registro de sueño", "Registra a qué hora dormiste y cómo te sientes."), component: Sueno });

function Sueno() {
  const { set, user } = useStore();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [bed, setBed] = useState("22:30");
  const [wake, setWake] = useState("06:10");
  const [feel, setFeel] = useState("Buen estado");
  const [q, setQ] = useState({ q1: "", q2: "", q3: "" });
  if (!user) return <Screen guard>{null}</Screen>;
  const mins = sleepMinutes(bed, wake);
  const v = sleepVerdict(mins, feel);
  const save = () => {
    set((s) => ({ sleep: { ...s.sleep, [user.email]: [{ id: uid(), date: todayKey(), bed, wake, feel, ...q }, ...(s.sleep[user.email] ?? [])] } }));
    toast.success(t("Sueño guardado"));
    navigate({ to: "/salud" });
  };
  return (
    <Screen>
      <BackHeader title={t("Registro de sueño")} kicker={t("Anoche")} to="/salud" />
      <div className="grid grid-cols-2 gap-3">
        <label><span className="text-sm text-muted-foreground">{t("Me dormí a las")}</span><input type="time" value={bed} onChange={(e) => setBed(e.target.value)} className={cn(inputCls, "mt-1 text-xl font-bold")} /></label>
        <label><span className="text-sm text-muted-foreground">{t("Me desperté a las")}</span><input type="time" value={wake} onChange={(e) => setWake(e.target.value)} className={cn(inputCls, "mt-1 text-xl font-bold")} /></label>
      </div>
      <div className="surface mt-3 flex items-center justify-between p-4"><span className="text-sm text-muted-foreground">{t("Dormiste")}</span><b className="text-2xl">{Math.floor(mins / 60)} h {mins % 60} min</b></div>
      <p className="mb-2 mt-5 font-semibold">{t("¿Cómo te sientes con este horario?")}</p>
      <div className="grid grid-cols-3 gap-2">
        {([["Poca energía", BatteryLow], ["Buen estado", BatteryMedium], ["Enérgico", BatteryFull]] as const).map(([l, I]) => (
          <button key={l} onClick={() => setFeel(l)} className={cn("flex flex-col items-center gap-2 rounded-2xl border py-4 text-sm", feel === l ? "border-violet bg-accent" : "border-border bg-card text-muted-foreground")}><I />{t(l)}</button>
        ))}
      </div>
      <p className="mb-2 mt-5 font-semibold">{t("Cuéntanos más")} <span className="font-normal text-muted-foreground">{t("· opcional")}</span></p>
      {([["q1", "¿Qué viviste durante el día?"], ["q2", "¿Qué hiciste antes de dormir?"], ["q3", "¿Algo alteró tu sueño?"]] as const).map(([k, p]) => (
        <input key={k} placeholder={t(p)} value={q[k]} onChange={(e) => setQ({ ...q, [k]: e.target.value })} className={cn(inputCls, "mb-2")} />
      ))}
      <div className={cn("mt-3 flex items-center gap-3 rounded-2xl border-2 bg-card p-4", v.label === "Poco descanso" ? "border-warning" : "border-success")}>
        <span className={cn("grid size-11 shrink-0 place-items-center rounded-full text-background", v.label === "Poco descanso" ? "bg-warning" : "bg-success")}><Check /></span>
        <div><b className="text-lg">{t(v.label)}</b><p className="text-xs text-muted-foreground">{t(v.text)}</p></div>
      </div>
      <Btn className="mt-6" onClick={save}>{t("Guardar sueño")}</Btn>
    </Screen>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AlertCircle, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, Chip, Screen } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { bpVerdict, uid, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/presion")({ head: seo("Presión y pulso", "Registra tu presión arterial y pulso y recibe un veredicto."), component: Presion });
const STATES = ["En reposo", "Después de ejercicio", "Nervioso", "Cansado", "Mareado"];

function Presion() {
  const { set, user } = useStore();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [v, setV] = useState({ sys: "112", dia: "72", pulse: "72" });
  const [state, setState] = useState("En reposo");
  if (!user) return <Screen guard>{null}</Screen>;
  const n = { sys: +v.sys, dia: +v.dia, pulse: +v.pulse };
  const valid = n.sys > 50 && n.dia > 30 && n.pulse > 30;
  const r = bpVerdict(n.sys, n.dia, n.pulse);
  const save = () => {
    set((s) => ({ bp: { ...s.bp, [user.email]: [{ id: uid(), at: new Date().toISOString(), ...n, state }, ...(s.bp[user.email] ?? [])] } }));
    toast.success(t("Medida guardada"));
    navigate({ to: "/salud" });
  };
  const tone = (l: string | undefined) => (l === "Normal" ? "text-success" : l === "Elevado" ? "text-warning" : "text-primary");

  return (
    <Screen>
      <BackHeader title={t("Presión y pulso")} kicker={t("Si conoces tus datos")} to="/salud" />
      <div className="grid grid-cols-3 gap-3">
        {([["sys", "Sistólica", "(la alta)"], ["dia", "Diastólica", "(la baja)"], ["pulse", "Pulso", "(lpm)"]] as const).map(([k, l, h]) => (
          <label key={k}><span className="text-xs text-muted-foreground">{t(l)}<br />{t(h)}</span>
            <input inputMode="numeric" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value.replace(/\D/g, "").slice(0, 3) })} className="mt-1 h-16 w-full rounded-2xl border border-input bg-card text-center text-3xl font-bold outline-none focus:border-primary" />
          </label>
        ))}
      </div>
      <p className="mb-2 mt-5 font-semibold">{t("¿Cómo estabas al medirlo?")}</p>
      <div className="flex flex-wrap gap-2">{STATES.map((x) => <Chip key={x} on={state === x} onClick={() => setState(x)} className="rounded-full">{t(x)}</Chip>)}</div>
      {valid && (
        <div className={cn("mt-5 rounded-2xl border-2 bg-card p-4", r.level ? "border-warning" : "border-success")}>
          <div className="flex items-center gap-3"><span className={cn("grid size-12 place-items-center rounded-full text-background", r.level ? "bg-warning" : "bg-success")}><Check /></span><div><p className="text-xs text-muted-foreground">{t("Resultado")}</p><p className="text-2xl font-bold">{t(r.overall)}</p></div></div>
          <div className="mt-3 space-y-1 text-sm">
            <p className="flex justify-between"><span>{t("Presión")} {n.sys}/{n.dia}</span><b className={tone(r.pressure)}>{t(r.pressure)}</b></p>
            <p className="flex justify-between"><span>{t("Pulso")} {n.pulse} {state === "En reposo" ? t("en reposo") : ""}</span><b className={tone(r.pulse)}>{t(r.pulse)}</b></p>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-1">{[0, 1, 2].map((i) => <span key={i} className={cn("h-1.5 rounded-full", i === r.level ? (i ? "bg-warning" : "bg-success") : "bg-muted")} />)}</div>
          <div className="mt-1 grid grid-cols-3 text-[10px] text-muted-foreground"><span>{t("Normal")}</span><span className="text-center">{t("Elevado")}</span><span className="text-right">{t("Revisar con un médico")}</span></div>
        </div>
      )}
      <p className="mt-4 flex gap-2 text-xs text-muted-foreground"><AlertCircle className="size-4 shrink-0 text-warning" />{t("Es una guía, no un diagnóstico. Si te sientes mal o los números te salen muy altos o muy bajos, avisa a un adulto o a un médico.")}</p>
      <Btn className="mt-auto" disabled={!valid} onClick={save}>{t("Guardar medida")}</Btn>
    </Screen>
  );
}

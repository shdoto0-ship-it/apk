import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BarChart3, Check, ChevronRight, Flame, MapPin, Settings } from "lucide-react";
import { useEffect } from "react";
import { Logo, Ring, Screen } from "@/components/app/ui";
import { lastNDays, myDays, POINTS } from "@/lib/game";
import { seo } from "@/lib/seo";
import { dayTotal, fmt, GRADE_GOAL, kcalFor, kmFor, STEPS_PER_BIKE_KM, STEPS_PER_JUMP, streak, useStore } from "@/lib/store";
import { useOnline } from "@/lib/useOnline";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/inicio")({ head: seo("Inicio", "Tus pasos de hoy y la carrera de Noveno contra Décimo."), component: Inicio });

export function GradeRace({ totals }: { totals: Record<9 | 10, number> }) {
  const { grade } = useI18n();
  return (
    <div className="space-y-3">
      {([9, 10] as const).map((g) => (
        <div key={g}>
          <div className="mb-1 flex justify-between text-sm font-semibold">
            <span className={g === 10 ? "text-primary" : ""}>{g}° {grade(g)}</span><span>{fmt(totals[g])}</span>
          </div>
          <div className="h-2 rounded-full bg-muted"><div className={cn("h-2 rounded-full", g === 9 ? "bg-grade9" : "bg-grade10")} style={{ width: `${Math.min(100, (totals[g] / GRADE_GOAL) * 100)}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

function Inicio() {
  const { s, user, profile, today, gradeTotals } = useStore();
  const online = useOnline();
  const navigate = useNavigate();
  const { t, locale, dist, distUnit, dow } = useI18n();
  useEffect(() => {
    if (!s.celebrated && (gradeTotals[9] >= GRADE_GOAL || gradeTotals[10] >= GRADE_GOAL)) navigate({ to: "/celebracion" });
  }, [s.celebrated, gradeTotals, navigate]);
  if (!user || !profile) return <Screen guard nav>{null}</Screen>;

  const total = dayTotal(today);
  const goal = profile.goalSteps;
  const jumpSteps = today.jumps * STEPS_PER_JUMP, bikeSteps = Math.round(today.bikeKm * STEPS_PER_BIKE_KM);
  const walkSteps = today.walk + today.bonus;
  const days = myDays(s);
  const week = lastNDays(days, 7);
  const st = streak(days, goal);
  const date = new Date().toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long" });
  const nextPoint = POINTS.find((p) => !s.points[user.email]?.[p.id]) ?? POINTS[0]!;

  return (
    <Screen guard nav>
      <div className="mb-5 flex items-center gap-3">
        <Logo size={46} />
        <div className="min-w-0 flex-1">
          <p className="text-xs capitalize text-muted-foreground">{date}</p>
          <h1 className="truncate text-xl font-bold leading-tight">{t("Hola, {name}", { name: user.name.split(" ")[0] ?? "" })}</h1>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs">
          <span className={cn("size-2 rounded-full", online ? "bg-success" : "bg-warning")} />{online ? t("Sincronizado") : t("Guardado local")}
        </span>
        <Link to="/ajustes" className="grid size-10 place-items-center rounded-full bg-secondary" aria-label={t("Ajustes")}><Settings className="size-5" /></Link>
      </div>

      <div className="surface p-4">
        <div className="flex items-center gap-4">
          <Ring value={total} max={goal} size={148} segments={[
            { value: walkSteps, color: "var(--primary)" }, { value: jumpSteps, color: "var(--warning)" }, { value: bikeSteps, color: "var(--success)" },
          ]}>
            <div><p className="text-3xl font-bold">{fmt(total)}</p><p className="text-xs text-muted-foreground">{t("de {n} pasos", { n: fmt(goal) })}</p></div>
          </Ring>
          <div className="space-y-3 text-sm">
            <p className="flex gap-2"><span className="mt-1.5 size-2 rounded-full bg-primary" /><span><b>{t("{n} pasos", { n: fmt(walkSteps) })}</b><br /><span className="text-xs text-muted-foreground">{t("caminando")}</span></span></p>
            <p className="flex gap-2"><span className="mt-1.5 size-2 rounded-full bg-warning" /><span><b>{t("{n} saltos", { n: today.jumps })}</b><br /><span className="text-xs text-muted-foreground">{t("= {n} pasos", { n: fmt(jumpSteps) })}</span></span></p>
            <p className="flex gap-2"><span className="mt-1.5 size-2 rounded-full bg-success" /><span><b>{t("{n} {u} en bici", { n: dist(today.bikeKm), u: distUnit })}</b><br /><span className="text-xs text-muted-foreground">{t("= {n} pasos", { n: fmt(bikeSteps) })}</span></span></p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-4 gap-2 text-center">
          {[[kcalFor(total, profile.weight), "kcal"], [dist(kmFor(today.walk, profile.height)), distUnit], [today.activeMin, "min"], [today.goalAt ?? fmt(Math.max(0, goal - total)), today.goalAt ? "meta a las" : "faltan"]].map(([v, l]) => (
            <div key={l} className="rounded-xl bg-muted py-2"><p className="text-lg font-bold">{v}</p><p className="text-[11px] text-muted-foreground">{t(String(l))}</p></div>
          ))}
        </div>
      </div>

      <Link to="/ranking" className="surface mt-4 block p-4">
        <div className="mb-3 flex justify-between"><b>9° vs 10°</b><span className="text-xs text-muted-foreground">{t("Primero en llegar a 10,000,000")}</span></div>
        <GradeRace totals={gradeTotals} />
      </Link>

      <div className="surface mt-4 flex items-center gap-3 p-4">
        <Flame className="size-6 text-warning" />
        <div className="text-center"><p className="text-xl font-bold leading-none">{st}</p><p className="text-[10px] text-muted-foreground">{t("días")}</p></div>
        <div className="flex flex-1 justify-between">
          {week.map((d) => {
            const ok = d.total >= goal;
            const isToday = d.key === week[6]!.key;
            return (
              <div key={d.key} className="flex flex-col items-center gap-1">
                <span className={cn("grid size-7 place-items-center rounded-full border-2", ok ? "border-primary bg-primary text-primary-foreground" : isToday ? "border-primary" : "border-border")}>{ok && <Check className="size-4" />}</span>
                <span className="text-[10px] text-muted-foreground">{dow[d.date.getDay()]}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Link to="/punto/$id" params={{ id: nextPoint.id }} className="surface flex items-center gap-3 p-4">
          <span className="grid size-10 place-items-center rounded-xl bg-success text-background"><MapPin className="size-5" /></span>
          <span className="min-w-0 flex-1"><b className="block text-sm">{t("Punto experimental")}</b><span className="block truncate text-xs text-muted-foreground">{t(nextPoint.name)} · +300</span></span>
        </Link>
        <Link to="/analisis" className="surface flex items-center gap-3 p-4">
          <span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><BarChart3 className="size-5" /></span>
          <span className="flex-1"><b className="block text-sm">{t("Análisis")}</b><span className="text-xs text-muted-foreground">{t("Tu actividad")}</span></span>
          <ChevronRight className="size-4 text-muted-foreground" />
        </Link>
      </div>
    </Screen>
  );
}

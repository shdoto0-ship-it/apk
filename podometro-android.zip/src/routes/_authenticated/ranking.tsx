import { createFileRoute, Link } from "@tanstack/react-router";
import { Crown, Flag, Trophy } from "lucide-react";
import { useState } from "react";
import { GradeDot, Screen } from "@/components/app/ui";
import { achievements } from "@/lib/game";
import { seo } from "@/lib/seo";
import { fmt, GRADE_GOAL, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/ranking")({ head: seo("Ranking", "Noveno contra Décimo: la carrera a 10 millones de pasos y el top del colegio."), component: Ranking });

function Ranking() {
  const { s, user, gradeTotals, ranking } = useStore();
  const [tab, setTab] = useState<"steps" | "streak">("steps");
  const { t, grade } = useI18n();
  if (!user) return <Screen guard nav>{null}</Screen>;
  const list = [...ranking].sort((a, b) => (tab === "steps" ? b.steps - a.steps : b.streak - a.streak || b.steps - a.steps));
  const meIdx = list.findIndex((r) => r.me);
  const ach = achievements(s, ranking.findIndex((r) => r.me) + 1);
  const lead: 9 | 10 = gradeTotals[9] >= gradeTotals[10] ? 9 : 10;
  const diff = Math.abs(gradeTotals[9] - gradeTotals[10]);
  const top = list[0];
  const me = list[meIdx];

  return (
    <Screen guard nav>
      <div className="mb-4 flex items-end justify-between">
        <div><p className="text-xs text-muted-foreground">{t("Noveno contra Décimo")}</p><h1 className="text-2xl font-bold">{t("Ranking")}</h1></div>
        <Link to="/logros" className="flex items-center gap-1.5 rounded-full border border-warning px-3 py-1.5 text-sm text-warning"><Trophy className="size-4" />{t("Logros")} {ach.filter((a) => a.done).length}/{ach.length}</Link>
      </div>
      <div className="surface p-4">
        <div className="mb-3 flex justify-between"><b>{t("La carrera a 10,000,000")}</b><span className="text-xs text-muted-foreground">{t("Gana el primero en llegar")}</span></div>
        {([9, 10] as const).map((g) => {
          const pct = Math.min(100, (gradeTotals[g] / GRADE_GOAL) * 100);
          return (
            <div key={g} className="mb-3">
              <div className="mb-1 flex justify-between text-sm"><b className={g === 10 ? "text-primary" : ""}>{g}° {grade(g)}</b><span className="text-muted-foreground">{fmt(gradeTotals[g])} · {Math.round(pct)}%</span></div>
              <div className="relative flex h-8 items-center rounded-full bg-muted">
                <div className={cn("h-8 rounded-full", g === 9 ? "bg-grade9/70" : "bg-grade10/80")} style={{ width: `${pct}%` }} />
                <span className="absolute" style={{ left: `calc(${Math.max(pct, 8)}% - 16px)` }}><GradeDot g={g} /></span>
                <Flag className="absolute right-3 size-4 text-warning" />
              </div>
            </div>
          );
        })}
        <p className="rounded-xl bg-muted p-3 text-xs text-muted-foreground">{diff === 0 ? t("Noveno y Décimo están empatados.") : <>{t("{g} va adelante por", { g: grade(lead) })} <b className="text-foreground">{fmt(diff)} {t("pasos")}</b>.</>} {t("Le faltan {a} a Noveno; a Décimo, {b}.", { a: fmt(GRADE_GOAL - gradeTotals[9]), b: fmt(GRADE_GOAL - gradeTotals[10]) })}</p>
      </div>
      <div className="my-4 grid grid-cols-2 rounded-2xl bg-card p-1">
        {([["steps", "Pasos"], ["streak", "Racha de días"]] as const).map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={cn("rounded-xl py-3 font-semibold", tab === k ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>{t(l)}</button>)}
      </div>
      {top ? <div className="mb-3 flex items-center gap-3 rounded-2xl border-2 border-warning bg-card p-4">
        <span className="grid size-12 place-items-center rounded-full bg-warning text-background"><Crown /></span>
        <div><p className="text-xs font-bold text-warning">TOP 1 · {tab === "steps" ? t("PASOS") : t("RACHA")}</p><p className="font-bold">{top.name}</p><p className="text-xs text-muted-foreground">{t("{g}° · {n} pasos · racha de {d} días", { g: top.grade, n: fmt(top.steps), d: top.streak })}</p></div>
      </div> : <p className="py-6 text-center text-sm text-muted-foreground">{t("Aún no hay participantes.")}</p>}
      <div className="space-y-2">
        {list.slice(1, 10).map((r, i) => <Row key={r.name + i} n={i + 2} r={r} tab={tab} />)}
        {meIdx >= 10 && me && <Row n={meIdx + 1} r={me} tab={tab} />}
      </div>
    </Screen>
  );
}

function Row({ n, r, tab }: { n: number; r: { name: string; grade: 9 | 10; steps: number; streak: number; me: boolean }; tab: string }) {
  const { t } = useI18n();
  return (
    <div className={cn("flex items-center gap-3 rounded-2xl border p-3.5", r.me ? "border-primary bg-accent" : "border-border bg-card")}>
      <span className="w-6 text-muted-foreground">{n}</span>
      <span className="flex-1 truncate font-medium">{r.me ? t("Tú") : r.name}</span>
      <GradeDot g={r.grade} />
      <span className="w-20 text-right font-semibold">{tab === "steps" ? fmt(r.steps) : t("{n} días", { n: r.streak })}</span>
    </div>
  );
}

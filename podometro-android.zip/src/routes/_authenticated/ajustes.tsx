import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronRight, LogOut, Pencil, Smartphone, Trophy } from "lucide-react";
import { toast } from "sonner";
import { BackHeader, Logo, Screen, Switch } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { ageFrom, useStore, type Theme } from "@/lib/store";
import { useOnline } from "@/lib/useOnline";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { AdminPanel } from "@/components/app/admin-panel";
import { NativeCard } from "@/components/app/native-card";

export const Route = createFileRoute("/_authenticated/ajustes")({ head: seo("Ajustes", "Tu meta, apariencia, idioma, unidades y cuenta."), component: Ajustes });

function Ajustes() {
  const { s, set, user, profile, sync, syncStatus, signOut, setGrade } = useStore();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const online = useOnline();
  const { t } = useI18n();
  if (!user || !profile) return <Screen guard>{null}</Screen>;
  const setP = (patch: Partial<typeof profile>) => set((st) => ({ profiles: { ...st.profiles, [user.email]: { ...profile, ...patch } } }));
  const mins = s.lastSync ? Math.max(0, Math.round((Date.now() - new Date(s.lastSync).getTime()) / 60000)) : null;
  const themes: [Theme, string, string][] = [["vino", "Vino", "theme-vino"], ["negro", "Negro", "theme-negro"], ["blanco", "Blanco", "theme-blanco"], ["rojo", "Rojo", "theme-rojo"]];
  const row = "flex items-center justify-between gap-3 p-4";

  return (
    <Screen>
      <BackHeader title={t("Ajustes")} to="/inicio" />
      <div className="surface flex items-center gap-3 p-4">
        <Logo size={52} />
        <div className="min-w-0 flex-1"><b className="block truncate">{user.name}</b><p className="text-xs text-muted-foreground">{user.grade}° {user.grade === 9 ? t("NOVENO") : t("DECIMO")} · Baltazar Salazar · {ageFrom(user.birth)} {t("años")}</p></div>
        <Link to="/perfil" className="grid size-10 place-items-center rounded-full bg-secondary" aria-label={t("Editar perfil")}><Pencil className="size-4" /></Link>
      </div>
      <p className="mb-2 mt-5 text-sm text-muted-foreground">{t("Mi meta")}</p>
      <div className="surface divide-y divide-border">
        <div className={row}><span>{t("Pasos por día")}</span>
          <select value={profile.goalSteps} onChange={(e) => setP({ goalSteps: +e.target.value })} className="bg-transparent text-right font-bold outline-none">
            {Array.from({ length: 39 }, (_, i) => 1000 + i * 500).map((n) => <option key={n} value={n} className="bg-card">{n.toLocaleString("en-US")}</option>)}
          </select></div>
        <div className={row}><span>{t("Meta de saltos")} <span className="text-xs text-muted-foreground">{t("· opcional")}</span></span><Switch on={profile.jumpsOn} onChange={(v) => setP({ jumpsOn: v })} /></div>
        <div className={row}><span>{t("Meta de bicicleta")} <span className="text-xs text-muted-foreground">{t("· opcional")}</span></span><Switch on={profile.bikeOn} onChange={(v) => setP({ bikeOn: v })} /></div>
      </div>
      <p className="mb-2 mt-5 text-sm text-muted-foreground">{t("Apariencia e idioma")}</p>
      <div className="surface divide-y divide-border">
        <div className="grid grid-cols-4 gap-2 p-3">
          {themes.map(([k, l, cls]) => (
            <button key={k} onClick={() => set(() => ({ theme: k }))} className={cn("rounded-xl border-2 p-2 text-xs", s.theme === k ? "border-foreground" : "border-border")}>
              <span className={cn(cls, "mb-1 block h-8 rounded-lg bg-background p-2")}><span className="block h-1.5 w-1/2 rounded-full bg-primary" /></span>{t(l)}
            </button>
          ))}
        </div>
        <div className={row}><span>{t("Idioma")}</span><select value={s.lang ?? "es"} onChange={(e) => set(() => ({ lang: e.target.value as "es" | "en" }))} className="bg-transparent text-muted-foreground outline-none"><option value="es" className="bg-card">Español</option><option value="en" className="bg-card">English</option></select></div>
        <div className={row}><span>{t("Unidades")}</span><div className="flex rounded-xl bg-muted p-1">{(["km", "mi"] as const).map((u) => <button key={u} onClick={() => set(() => ({ units: u }))} className={cn("rounded-lg px-3 py-1 text-sm", s.units === u && "bg-primary text-primary-foreground")}>{u}</button>)}</div></div>
        <div className={row}><span>{t("Sensibilidad de saltos")}</span><input type="range" min={0} max={100} value={s.jumpSens} onChange={(e) => set(() => ({ jumpSens: +e.target.value }))} className="w-36 accent-primary" aria-label={t("Sensibilidad")} /></div>
      </div>
      <div className="mt-5"><NativeCard /></div>
      <p className="mb-2 mt-5 text-sm text-muted-foreground">{t("Más")}</p>
      <div className="surface divide-y divide-border">
        <Link to="/widget" className={row}><span className="flex items-center gap-2"><Smartphone className="size-4" />{t("Ver widgets")}</span><ChevronRight className="size-4" /></Link>
        <Link to="/celebracion" className={row}><span className="flex items-center gap-2"><Trophy className="size-4" />{t("Ver animación de 10 millones")}</span><ChevronRight className="size-4" /></Link>
      </div>
      <p className="mb-2 mt-5 text-sm text-muted-foreground">{t("Cuenta y datos")}</p>
      <div className="surface divide-y divide-border">
        <div className={row}><span>{t("Grado")}</span><div className="flex rounded-xl bg-muted p-1">{([9, 10] as const).map((g) => <button key={g} onClick={() => setGrade(g)} className={cn("rounded-lg px-3 py-1 text-sm", user.grade === g && "bg-primary text-primary-foreground")}>{g}°</button>)}</div></div>
        <div className={row}><span>{t("Notificaciones")}</span><Switch on={s.notifications} onChange={(v) => set(() => ({ notifications: v }))} /></div>
        <div className={row}>
          <div className="flex gap-2"><span className={cn("mt-1.5 size-2 rounded-full", syncStatus === "saved" ? "bg-success" : "bg-warning")} /><div><p>{syncStatus === "error" ? t("Pendiente: no se pudo guardar en la nube") : syncStatus === "pending" ? t("Guardado en el teléfono · pendiente de subir") : mins == null ? t("Cuenta conectada a la nube") : t("Guardado en la nube hace {n} min", { n: mins })}</p><p className="text-xs text-muted-foreground">{t("Sin internet se guarda y se sube después")}</p></div></div>
          <button onClick={() => { if (!online) { toast.error(t("Sin internet: se subirá cuando vuelva")); return; } void sync(); }} className="rounded-xl border border-border px-3 py-2 text-sm font-semibold">{t("Sincronizar")}</button>
        </div>
        <button onClick={async () => { await queryClient.cancelQueries(); queryClient.clear(); await signOut(); navigate({ to: "/auth", replace: true }); }} className={cn(row, "w-full text-primary")}><span className="font-semibold">{t("Cerrar sesión")}</span><LogOut className="size-4" /></button>
      </div>
      <AdminPanel />
    </Screen>
  );
}

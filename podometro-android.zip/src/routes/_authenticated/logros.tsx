import { createFileRoute } from "@tanstack/react-router";
import { Bike, Check, ChevronsUp, Crown, Flag, Flame, Footprints, Lock, MapPin } from "lucide-react";
import { BackHeader, Screen } from "@/components/app/ui";
import { achievements } from "@/lib/game";
import { seo } from "@/lib/seo";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { KM_TO_MI, useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/logros")({ head: seo("Logros", "Tus medallas: pasos, rachas, saltos, bici y puntos del mapa."), component: Logros });
const ICONS = { foot: Footprints, check: Check, flame: Flame, flag: Flag, jump: ChevronsUp, bike: Bike, pin: MapPin, crown: Crown };

function Logros() {
  const { s, user, ranking } = useStore();
  const { t, miles, distUnit } = useI18n();
  if (!user) return <Screen guard nav>{null}</Screen>;
  const list = achievements(s, ranking.findIndex((r) => r.me) + 1);
  const done = list.filter((a) => a.done).length;
  // Los logros de bici se miden en km guardados; el título se muestra en la unidad elegida.
  const bikeKm: Record<string, number> = { a6: 5, a11: 50 };
  const title = (id: string, es: string) => {
    const km = bikeKm[id];
    if (km === undefined) return t(es);
    const n = miles ? +(km * KM_TO_MI).toFixed(1) : km;
    return t(id === "a6" ? "Primeros {n} {u} en bici" : "{n} {u} en bici", { n, u: distUnit });
  };
  return (
    <Screen guard nav>
      <BackHeader title={t("Logros")} to="/ranking" right={<span className="text-sm"><b className="text-primary">{done}</b> {t("de")} {list.length}</span>} />
      <div className="mb-5 h-2 rounded-full bg-muted"><div className="h-2 rounded-full bg-primary" style={{ width: `${(done / list.length) * 100}%` }} /></div>
      <div className="grid grid-cols-3 gap-2.5">
        {list.map((a) => {
          const I = ICONS[a.icon as keyof typeof ICONS];
          const started = !a.done && (a.pct ?? 0) > 0;
          return (
            <div key={a.id} className="surface flex flex-col items-center gap-2 p-3 text-center">
              {a.done ? (
                <span className={cn("grid size-14 place-items-center rounded-full text-background", a.tone, a.tone === "bg-primary" && "text-primary-foreground")}><I className="size-6" /></span>
              ) : started ? (
                <span className="relative grid size-14 place-items-center rounded-full text-xs font-bold" style={{ background: `conic-gradient(var(--primary) ${(a.pct ?? 0) * 360}deg, var(--muted) 0)` }}>
                  <span className="absolute inset-1 grid place-items-center rounded-full bg-card">{Math.round((a.pct ?? 0) * 100)}%</span>
                </span>
              ) : (
                <span className="grid size-14 place-items-center rounded-full border-2 border-dashed border-border text-muted-foreground"><Lock className="size-5" /></span>
              )}
              <p className={cn("text-xs font-semibold leading-tight", !a.done && !started && "text-muted-foreground")}>{title(a.id, a.t)}</p>
            </div>
          );
        })}
      </div>
    </Screen>
  );
}

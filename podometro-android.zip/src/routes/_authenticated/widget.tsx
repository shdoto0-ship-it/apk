import { createFileRoute } from "@tanstack/react-router";
import { BackHeader, Logo, Ring, Screen } from "@/components/app/ui";
import { seo } from "@/lib/seo";
import { dayTotal, fmt, GRADE_GOAL, kcalFor, kmFor, useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";
import { NativeCard } from "@/components/app/native-card";
import { isNative } from "@/lib/native";

export const Route = createFileRoute("/_authenticated/widget")({ head: seo("Widgets", "Así se ven tus widgets de pasos en la pantalla del teléfono."), component: Widget });

function Widget() {
  const { profile, today, gradeTotals } = useStore();
  const { t, locale, dist, distUnit } = useI18n();
  if (!profile) return <Screen guard>{null}</Screen>;
  const total = dayTotal(today), g = profile.goalSteps, now = new Date();
  return (
    <Screen>
      <BackHeader title={t("Widgets")} to="/ajustes" />
      <NativeCard />
      <p className="text-sm capitalize text-muted-foreground">{now.toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long" })}</p>
      <p className="mb-6 text-6xl font-bold">{now.toTimeString().slice(0, 5)}</p>
      <p className="mb-2 text-sm text-muted-foreground">{t("Widget mediano")}</p>
      <div className="surface flex items-center gap-4 rounded-3xl p-4">
        <Ring value={total} max={g} size={110} stroke={11}><div><p className="text-xl font-bold">{fmt(total)}</p><p className="text-[10px] text-muted-foreground">{t("de {n}", { n: fmt(g) })}</p></div></Ring>
        <div className="flex-1 text-xs">
          <p className="mb-2 text-muted-foreground">{t("Hoy · {left} faltan · {kcal} kcal · {d} {u}", { left: fmt(Math.max(0, g - total)), kcal: kcalFor(total, profile.weight), d: dist(kmFor(today.walk, profile.height)), u: distUnit })}</p>
          {([9, 10] as const).map((k) => (
            <div key={k} className="mb-2"><div className="flex justify-between"><b className={k === 10 ? "text-primary" : ""}>{k}°</b>{fmt(gradeTotals[k])}</div><div className="h-1.5 rounded-full bg-muted"><div className={k === 9 ? "h-1.5 rounded-full bg-grade9" : "h-1.5 rounded-full bg-grade10"} style={{ width: `${(gradeTotals[k] / GRADE_GOAL) * 100}%` }} /></div></div>
          ))}
        </div>
      </div>
      <p className="mb-2 mt-6 text-sm text-muted-foreground">{t("Widgets pequeños")}</p>
      <div className="grid grid-cols-2 gap-3">
        <div className="surface flex flex-col items-center rounded-3xl p-4"><Ring value={total} max={g} size={100} stroke={10}><b className="text-xl">{Math.min(100, Math.round((total / g) * 100))}%</b></Ring><p className="mt-2 text-xs text-muted-foreground">{t("{n} pasos faltan", { n: fmt(Math.max(0, g - total)) })}</p></div>
        <div className="surface flex flex-col rounded-3xl p-4"><b className="mb-2 text-sm">9° vs 10°</b>
          <div className="flex flex-1 items-end gap-2">{([9, 10] as const).map((k) => <div key={k} className="flex flex-1 flex-col items-center gap-1"><div className={k === 9 ? "w-full rounded-md bg-grade9" : "w-full rounded-md bg-grade10"} style={{ height: `${20 + (gradeTotals[k] / GRADE_GOAL) * 140}px` }} /><span className="text-xs font-bold">{k}° {Math.round((gradeTotals[k] / GRADE_GOAL) * 100)}%</span></div>)}</div>
        </div>
      </div>
      <div className="mt-8 flex flex-col items-center gap-1 text-xs"><Logo size={56} />Podómetro B.S</div>
      <p className="mt-4 text-center text-xs text-muted-foreground">{isNative() ? t("Para tenerlos en tu pantalla de inicio: mantén presionado un espacio vacío, elige Widgets y busca Podómetro B.S.") : t("Para tenerla en tu pantalla de inicio: en el navegador elige “Agregar a pantalla de inicio”.")}</p>
    </Screen>
  );
}

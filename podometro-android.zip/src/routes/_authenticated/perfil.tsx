import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Bike, Check, ChevronsUp, Clock, Footprints, Heart, HeartPulse, Minus, MoreHorizontal, Plus, Scale, Users, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { Btn, Chip, Screen, Switch } from "@/components/app/ui";
import { fmt, kcalFor, kmFor, STEPS_PER_BIKE_KM, useStore, type Profile } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useRouter } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({ meta: [{ title: "Cuéntanos de ti · Podómetro B.S" }, { name: "description", content: "Configura tu perfil y tu meta diaria de pasos." }, { property: "og:title", content: "Cuéntanos de ti · Podómetro B.S" }, { property: "og:description", content: "Configura tu perfil y tu meta diaria de pasos." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Perfil,
});

const goals = [
  { t: "Registrar mis pasos", i: Footprints }, { t: "Bajar de peso", i: Scale }, { t: "Caminar más", i: ArrowRight },
  { t: "Entrenar para correr", i: Zap }, { t: "Mejorar mi salud en general", i: Heart },
  { t: "Mantenerme activo junto a mis compañeros", i: Users }, { t: "Otra cosa", i: MoreHorizontal },
];

function Stepper({ label, unit, value, set, min, max }: { label: string; unit: string; value: number; set: (n: number) => void; min: number; max: number }) {
  const { t } = useI18n();
  const ticks = 30;
  return (
    <div className="surface mb-4 p-4">
      <p className="mb-2 text-sm font-semibold">{label}</p>
      <div className="flex items-center justify-between">
        <button onClick={() => set(Math.max(min, value - 1))} className="grid size-11 place-items-center rounded-full bg-secondary" aria-label={t("Menos")}><Minus /></button>
        <p className="text-5xl font-bold">{value}<span className="ml-1 text-base font-normal text-muted-foreground">{unit}</span></p>
        <button onClick={() => set(Math.min(max, value + 1))} className="grid size-11 place-items-center rounded-full bg-secondary" aria-label={t("Más")}><Plus /></button>
      </div>
      <input type="range" min={min} max={max} value={value} onChange={(e) => set(+e.target.value)} className="mt-4 w-full accent-primary" aria-label={label} />
      <div className="flex justify-between">{Array.from({ length: ticks }).map((_, i) => <span key={i} className="h-3 w-px bg-border" />)}</div>
    </div>
  );
}

function Perfil() {
  const { s, set, user, ready, gradeConfirmed, setGrade } = useStore();
  const navigate = useNavigate();
  const router = useRouter();
  const { t, dist, distUnit, stepsPerUnit } = useI18n();
  const [step, setStep] = useState(1);
  const [p, setP] = useState<Profile>({ sex: "Mujer", height: 165, weight: 58, goal: "Caminar más", goalSteps: 6000, jumpsOn: false, bikeOn: false });
  const [custom, setCustom] = useState(12000);
  const [isCustom, setIsCustom] = useState(false);

  useEffect(() => { if (ready && !user) navigate({ to: "/login" }); }, [ready, user, navigate]);
  useEffect(() => { const existing = user ? s.profiles[user.email] : undefined; if (existing) setP(existing); }, [user, s.profiles]);

  const finish = () => {
    if (!user) return;
    const prof = { ...p, goalSteps: isCustom ? custom : p.goalSteps };
    set((st) => ({ profiles: { ...st.profiles, [user.email]: prof } }));
    navigate({ to: "/inicio" });
  };
  const goal = isCustom ? custom : p.goalSteps;

  return (
    <Screen>
      <div className="mb-6 flex items-center gap-3">
        <button onClick={() => (step > 1 ? setStep(step - 1) : router.history.back())} className="grid size-10 place-items-center rounded-full bg-secondary" aria-label={t("Volver")}>‹</button>
        <div className="flex flex-1 gap-2">{[1, 2, 3].map((i) => <span key={i} className={cn("h-1 flex-1 rounded-full", i <= step ? "bg-primary" : "bg-muted")} />)}</div>
        <span className="text-xs text-muted-foreground">{step} {t("de")} 3</span>
      </div>

      {step === 1 && (
        <>
          <h1 className="text-3xl font-bold">{t("Cuéntanos de ti")}</h1>
          <p className="mb-5 mt-2 text-sm text-muted-foreground">{t("Con estos datos calculamos tus calorías y los kilómetros de tus pasos.")}</p>
          {!gradeConfirmed && (
            <>
              <p className="mb-2 text-sm font-semibold">{t("Grado")}</p>
              <div className="mb-4 grid grid-cols-2 gap-3">
                {([9, 10] as const).map((g) => (
                  <button type="button" key={g} onClick={() => setGrade(g)} aria-pressed={user?.grade === g}
                    className={cn("h-14 rounded-2xl border text-lg font-bold", user?.grade === g ? "border-foreground bg-card" : "border-border bg-card text-muted-foreground")}>
                    <span className={g === 10 ? "text-primary" : undefined}>{g}°&nbsp; {g === 9 ? t("NOVENO") : t("DECIMO")}</span>
                  </button>
                ))}
              </div>
            </>
          )}
          <p className="mb-2 text-sm font-semibold">{t("Sexo")}</p>
          <div className="mb-4 grid grid-cols-3 gap-2">
            {(["Mujer", "Hombre", "Prefiero no decirlo"] as const).map((x) => <Chip key={x} on={p.sex === x} onClick={() => setP({ ...p, sex: x })}>{t(x)}</Chip>)}
          </div>
          <Stepper label={t("Estatura")} unit="cm" value={p.height} set={(height) => setP({ ...p, height })} min={120} max={210} />
          <Stepper label={t("Peso")} unit="kg" value={p.weight} set={(weight) => setP({ ...p, weight })} min={25} max={150} />
          <Btn className="mt-auto" disabled={!gradeConfirmed} onClick={() => setStep(2)}>{t("Continuar")}</Btn>
          {!gradeConfirmed && <p className="mt-2 text-center text-xs text-warning">{t("Elige tu grado para continuar.")}</p>}
          <p className="mt-3 text-center text-xs text-muted-foreground">{t("Estos datos son privados. Puedes cambiarlos en Ajustes.")}</p>
        </>
      )}

      {step === 2 && (
        <>
          <h1 className="text-3xl font-bold">{t("¿Cuál es tu objetivo?")}</h1>
          <p className="mb-5 mt-2 text-sm text-muted-foreground">{t("Elige el que más se parezca. Es solo para personalizar tus consejos.")}</p>
          <div className="space-y-2.5">
            {goals.map(({ t: goalName, i: I }) => {
              const on = p.goal === goalName;
              return (
                <button key={goalName} onClick={() => setP({ ...p, goal: goalName })}
                  className={cn("flex w-full items-center gap-3 rounded-2xl border p-3.5 text-left font-semibold", on ? "border-primary bg-accent" : "border-border bg-card")}>
                  <span className={cn("grid size-9 place-items-center rounded-xl", on ? "bg-primary text-primary-foreground" : "bg-secondary")}><I className="size-5" /></span>
                  <span className="flex-1">{t(goalName)}</span>
                  <span className={cn("grid size-6 place-items-center rounded-full border", on ? "border-primary-foreground bg-primary" : "border-muted-foreground")}>{on && <Check className="size-4" />}</span>
                </button>
              );
            })}
          </div>
          <Btn className="mt-6" onClick={() => setStep(3)}>{t("Continuar")}</Btn>
        </>
      )}

      {step === 3 && (
        <>
          <h1 className="text-3xl font-bold">{t("Tu meta de pasos cada día")}</h1>
          <p className="mb-5 mt-2 text-sm text-muted-foreground">{t("Es la meta que verás en tu anillo. Todos los pasos suman al total de tu grado.")}</p>
          <div className="grid grid-cols-2 gap-3">
            {[[4000, "Suave"], [6000, "Recomendada"], [10000, "Retadora"]].map(([n, l]) => {
              const on = !isCustom && p.goalSteps === n;
              return (
                <button key={n} onClick={() => { setIsCustom(false); setP({ ...p, goalSteps: n as number }); }}
                  className={cn("rounded-2xl border py-6", on ? "border-primary bg-accent" : "border-border bg-card")}>
                  <p className="text-3xl font-bold">{fmt(n as number)}</p><p className={cn("text-xs", on ? "text-primary" : "text-muted-foreground")}>{t(l as string)}</p>
                </button>
              );
            })}
            <button onClick={() => setIsCustom(true)} className={cn("rounded-2xl border py-6", isCustom ? "border-primary bg-accent" : "border-border bg-card")}>
              <p className="text-2xl font-bold">{isCustom ? fmt(custom) : t("Otra")}</p><p className="text-xs text-muted-foreground">{t("Tú eliges · hasta 20,000")}</p>
            </button>
          </div>
          {isCustom && <input type="range" min={1000} max={20000} step={500} value={custom} onChange={(e) => setCustom(+e.target.value)} className="mt-4 w-full accent-primary" aria-label={t("Meta personalizada")} />}
          <div className="surface mt-4 flex gap-3 p-4 text-sm text-muted-foreground">
            <Clock className="size-5 shrink-0 text-success" />
            <p>{fmt(goal)} {t("pasos son unos")} <b className="text-foreground">{dist(kmFor(goal, p.height))} {distUnit}</b> {t("y cerca de")} <b className="text-foreground">{kcalFor(goal, p.weight)} kcal</b> {t("(aproximado, según tu estatura y peso).")}</p>
          </div>
          <p className="mb-2 mt-5 text-sm font-semibold">{t("Metas opcionales")} <span className="font-normal text-muted-foreground">{t("· también suman pasos")}</span></p>
          <div className="surface divide-y divide-border">
            <div className="flex items-center gap-3 p-4"><span className="grid size-10 place-items-center rounded-xl bg-warning text-background"><ChevronsUp /></span><div className="flex-1"><p className="font-semibold">{t("Saltos")}</p><p className="text-xs text-muted-foreground">{t("Cada salto = 2 pasos")}</p></div><Switch on={p.jumpsOn} onChange={(v) => setP({ ...p, jumpsOn: v })} label={t("Saltos")} /></div>
            <div className="flex items-center gap-3 p-4"><span className="grid size-10 place-items-center rounded-xl bg-success text-background"><Bike /></span><div className="flex-1"><p className="font-semibold">{t("Bicicleta")}</p><p className="text-xs text-muted-foreground">{t("Cada {u} = {n} pasos", { u: t(distUnit === "km" ? "kilómetro" : "milla"), n: stepsPerUnit(STEPS_PER_BIKE_KM) })}</p></div><Switch on={p.bikeOn} onChange={(v) => setP({ ...p, bikeOn: v })} label={t("Bicicleta")} /></div>
          </div>
          <Btn className="mt-6" onClick={finish}><HeartPulse className="size-5" />{t("Empezar a contar")}</Btn>
        </>
      )}
    </Screen>
  );
}

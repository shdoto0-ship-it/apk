import { ClientOnly, createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Check, ChevronRight, LocateFixed, MapPin } from "lucide-react";
import { Suspense, useEffect, useState } from "react";
import GoogleMap from "@/components/app/google-map";
import { Screen } from "@/components/app/ui";
import { anchor, POINT_BONUS, pointLatLng, POINTS } from "@/lib/game";
import { seo } from "@/lib/seo";
import { haversineKm } from "@/lib/sensors";
import { todayKey, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/mapa")({ head: seo("Mapa", "Puntos experimentales: llega, haz el experimento y gana pasos extra."), component: Mapa });

export function usePosition() {
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    if (!navigator.geolocation) { setErr(true); return; }
    const id = navigator.geolocation.watchPosition((p) => {
      setPos({ lat: p.coords.latitude, lng: p.coords.longitude });
    }, () => setErr(true), { enableHighAccuracy: true });
    return () => navigator.geolocation.clearWatch(id);
  }, []);
  return { pos, err };
}

function Mapa() {
  const { s, user } = useStore();
  const { pos, err } = usePosition();
  const { t, shortDist } = useI18n();
  const a = anchor();
  const navigate = useNavigate();
  if (!user) return <Screen guard nav>{null}</Screen>;
  const done = s.points[user.email] ?? {};
  const doneIds = new Set(Object.keys(done).filter((id) => done[id] === todayKey()));

  return (
    <Screen guard nav>
      <p className="text-xs text-muted-foreground">{t("Experimental · mapa del colegio")}</p>
      <h1 className="mb-4 text-2xl font-bold">{t("Mapa")}</h1>
      <div className="surface overflow-hidden">
        <ClientOnly fallback={<div className="grid h-80 place-items-center text-sm text-muted-foreground">{t("Cargando mapa de Google…")}</div>}>
          <Suspense fallback={<div className="grid h-80 place-items-center text-sm text-muted-foreground">{t("Cargando mapa de Google…")}</div>}>
            <GoogleMap
              points={POINTS}
              doneIds={doneIds}
              userPos={pos}
              onPointClick={(id) => navigate({ to: "/punto/$id", params: { id } })}
            />
          </Suspense>
        </ClientOnly>
        <p className="flex items-center gap-2 p-3 text-xs text-muted-foreground"><LocateFixed className="size-4 text-primary" />{err ? t("Activa la ubicación para ver dónde estás.") : pos ? t("Punto azul: tú · Toca un pin para abrir el punto") : t("Buscando tu ubicación…")}</p>
      </div>
      <h2 className="mb-2 mt-5 font-semibold">{t("Puntos experimentales")} <span className="text-sm font-normal text-muted-foreground">· +{POINT_BONUS} {t("pasos cada uno, una vez al día")}</span></h2>
      <div className="space-y-2.5">
        {POINTS.map((p) => {
          const dist = pos && a ? haversineKm(pos, pointLatLng(p, a)) * 1000 : null;
          const ok = done[p.id] === todayKey();
          return (
            <Link key={p.id} to="/punto/$id" params={{ id: p.id }} className="surface flex items-center gap-3 p-3.5">
              <span className={cn("grid size-10 place-items-center rounded-xl text-background", ok ? "bg-success" : "bg-warning")}>{ok ? <Check className="size-5" /> : <MapPin className="size-5" />}</span>
              <span className="min-w-0 flex-1"><b className="block truncate">{p.id}. {t(p.name)}</b><span className="text-xs text-muted-foreground">{ok ? t("Hecho hoy") : dist != null ? `${shortDist(dist)} · +${POINT_BONUS} ${t("pasos")}` : `+${POINT_BONUS} ${t("pasos")}`}</span></span>
              <ChevronRight className="size-4 text-muted-foreground" />
            </Link>
          );
        })}
      </div>
    </Screen>
  );
}

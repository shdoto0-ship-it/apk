import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, useRef, type ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { StoreProvider, useLang, useStore } from "@/lib/store";
import { translate } from "@/lib/translations";

function NotFoundComponent() {
  const lang = useLang();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">{translate(lang, "Página no encontrada")}</h2>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            {translate(lang, "Volver al inicio")}
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  const lang = useLang();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold text-foreground">{translate(lang, "Esta pantalla no cargó")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">{translate(lang, "Algo salió mal. Intenta de nuevo.")}</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          {translate(lang, "Reintentar")}
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#1c1013" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { title: "Podómetro B.S" },
      { name: "description", content: "Noveno contra Décimo: el primero en llegar a 10 millones de pasos gana." },
      { property: "og:title", content: "Podómetro B.S" },
      { property: "og:description", content: "Noveno contra Décimo: el primero en llegar a 10 millones de pasos gana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/** Mantiene el atributo lang y el título de la pestaña en el idioma elegido. */
function LangSync() {
  const { s } = useStore();
  const lang = s.lang === "en" ? "en" : "es";
  const source = useRef("");   // título en español tal como lo define cada ruta
  const shown = useRef("");    // el último título que dejamos puesto
  useEffect(() => {
    document.documentElement.lang = lang;
    if (!source.current) source.current = document.title;
    const show = () => {
      const next = lang === "en" ? source.current.split(" · ").map((p) => translate("en", p)).join(" · ") : source.current;
      shown.current = next;
      if (document.title !== next) document.title = next;
    };
    show();
    const watch = new MutationObserver(() => {
      if (document.title === shown.current) return;
      source.current = document.title;
      show();
    });
    watch.observe(document.head, { childList: true, characterData: true, subtree: true });
    return () => watch.disconnect();
  }, [lang]);
  return null;
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <StoreProvider>
        <LangSync />
        <Outlet />
        <Toaster position="top-center" />
      </StoreProvider>
    </QueryClientProvider>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AlertCircle, Check, Landmark, Lock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BackHeader, Btn, Field, inputCls, Screen } from "@/components/app/ui";
import { ageFrom, stripAccents, useStore, type Grade } from "@/lib/store";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { appOrigin } from "@/lib/native";

export const Route = createFileRoute("/registro")({
  head: () => ({ meta: [{ title: "Crea tu cuenta · Podómetro B.S" }, { name: "description", content: "Registro para estudiantes de noveno y décimo." }, { property: "og:title", content: "Crea tu cuenta · Podómetro B.S" }, { property: "og:description", content: "Registro para estudiantes de noveno y décimo." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Registro,
});

function Registro() {
  const { user, ready } = useStore();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [f, setF] = useState({ email: "", pw: "", name: "", birth: "", grade: 9 as Grade, ok: true });
  const age = ageFrom(f.birth);
  const [busy, setBusy] = useState(false);
  const [confirmation, setConfirmation] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = f.email.trim().toLowerCase();
    const name = stripAccents(f.name).trim();
    if (f.pw.length < 8) return toast.error(t("La contraseña necesita mínimo 8 caracteres"));
    if (name.split(/\s+/).length < 2) return toast.error(t("Escribe nombre y apellido"));
    if (!f.birth) return toast.error(t("Escribe tu fecha de nacimiento"));
    if (!f.ok) return toast.error(t("Necesitas la autorización de tu acudiente"));
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({ email, password: f.pw, options: { emailRedirectTo: appOrigin(), data: { name, birth: f.birth, grade: f.grade } } });
    setBusy(false);
    if (error) {
      const m = error.message.toLowerCase();
      if (m.includes("weak") || m.includes("pwned") || m.includes("guess")) return toast.error(t("Esa contraseña es muy común y fácil de adivinar. Usa otra, por ejemplo con letras, números y un símbolo."));
      if (m.includes("already") || m.includes("registered")) return toast.error(t("Ese correo ya tiene cuenta. Inicia sesión."));
      if (m.includes("rate") || error.status === 429) return toast.error(t("Demasiados intentos. Espera unos minutos e inténtalo de nuevo."));
      return toast.error(t("No se pudo crear la cuenta:") + " " + error.message);
    }
    if (!data.session) { setConfirmation(true); return; }
    toast.success(t("¡Cuenta creada!"));
    navigate({ to: "/perfil" });
    return undefined;
  };

  return (
    <Screen>
      <BackHeader title={t("Crea tu cuenta")} kicker={t("Solo para estudiantes de noveno y décimo")} to="/login" />
      {confirmation ? <div className="space-y-4"><h1 className="text-2xl font-bold">{t("Confirma tu correo")}</h1><p className="text-muted-foreground">{t("Revisa tu correo y abre el enlace para activar tu cuenta. Si no aparece, revisa spam.")}</p><Btn onClick={() => navigate({ to: "/login" })}>{t("Ir a iniciar sesión")}</Btn></div> : ready && user ? <Btn onClick={() => navigate({ to: "/inicio" })}>{t("Volver a mi cuenta")}</Btn> :
      <form onSubmit={submit} className="flex flex-1 flex-col">
        <Field label={t("Correo electrónico")}><input className={inputCls} type="email" required placeholder={t("tucorreo@ejemplo.com")} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label={t("Contraseña")}><input className={inputCls} type="password" required placeholder={t("Mínimo 8 caracteres")} value={f.pw} onChange={(e) => setF({ ...f, pw: e.target.value })} /></Field>
        <Field label={t("Nombre completo")} hint={<p className="mt-1.5 flex items-center gap-1.5 text-xs text-warning"><AlertCircle className="size-3.5" />{t("Sin tildes ni ñ. Ejemplo: MARIA NUNEZ")}</p>}>
          <input className={cn(inputCls, "uppercase")} required autoComplete="name" autoCapitalize="characters" placeholder={t("NOMBRES Y APELLIDOS")} value={f.name} onChange={(e) => { const name = e.target.value; setF((prev) => ({ ...prev, name })); }} onBlur={() => setF((prev) => ({ ...prev, name: stripAccents(prev.name) }))} />
        </Field>
        <div className="grid grid-cols-[1fr_auto] gap-3">
          <Field label={t("Fecha de nacimiento")}><input className={inputCls} type="date" required value={f.birth} max={new Date().toISOString().slice(0, 10)} onChange={(e) => setF({ ...f, birth: e.target.value })} /></Field>
          <Field label={t("Edad · automática")}><div className="grid h-14 min-w-24 place-items-center rounded-2xl bg-accent font-semibold">{f.birth ? `${age} ${t("años")}` : "—"}</div></Field>
        </div>
        <Field label={t("Colegio")}>
          <div className={cn(inputCls, "flex items-center gap-3 font-semibold")}><Landmark className="size-5 text-primary" /><span className="flex-1">BALTAZAR SALAZAR</span><Lock className="size-4 text-muted-foreground" /></div>
        </Field>
        <span className="mb-1.5 block text-sm text-muted-foreground">{t("Grado")}</span>
        <div className="mb-4 grid grid-cols-2 gap-3">
          {([9, 10] as const).map((g) => (
            <button type="button" key={g} onClick={() => setF({ ...f, grade: g })}
              className={cn("h-14 rounded-2xl border text-lg font-bold", f.grade === g ? "border-foreground bg-card" : "border-border bg-card text-muted-foreground", g === 10 && "text-primary")}>
              {g}°&nbsp; {g === 9 ? t("NOVENO") : t("DECIMO")}
            </button>
          ))}
        </div>
        <button type="button" onClick={() => setF({ ...f, ok: !f.ok })} className="mb-6 flex items-start gap-3 text-left text-sm text-muted-foreground">
          <span className={cn("grid size-6 shrink-0 place-items-center rounded-md border", f.ok ? "border-primary bg-primary text-primary-foreground" : "border-border")}>{f.ok && <Check className="size-4" />}</span>
          {t("Mi acudiente autoriza que mi nombre y mis pasos aparezcan en el ranking del colegio.")}
        </button>
        <Btn type="submit" disabled={busy} className="mt-auto">{busy ? t("Creando cuenta…") : t("Crear cuenta")}</Btn>
      </form>
      }
    </Screen>
  );
}

import { createFileRoute, Navigate } from "@tanstack/react-router";
import { seo } from "@/lib/seo";
export const Route = createFileRoute("/auth")({ head: seo("Acceso", "Entra a tu cuenta de Podómetro B.S."), component: () => <Navigate to="/login" replace /> });